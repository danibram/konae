mod supervisor;
mod containment;
pub mod budget;
pub mod protocol;

pub use budget::{Budget, BudgetError, MutationOutcomeState};
pub use protocol::{Input, Output, WorkerLimits};
pub use supervisor::{Worker, WorkerError, error_code};
pub use containment::MemoryPolicy;
use std::time::Instant;

pub trait ExecutionBudget {
    fn deadline(&self) -> Instant;
    fn is_cancelled(&self) -> bool;
}
