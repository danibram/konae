
use axum::{http::Method, middleware::Next};

use super::*;

pub const MARKER_FILE: &str = "maintenance.json";
/// How long the mail worker puts back a held job before looking again.
pub const MAIL_HOLD_MS: i64 = 60_000;

const MESSAGE: &str = "This app is in maintenance. It accepts no writes, signups, recovery, administrative changes or email until it comes out of maintenance.";
const UNREADABLE: &str = "This app is in maintenance because its maintenance state (maintenance.json) cannot be read. The operator must repair or remove that file.";

#[derive(Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Marker {
    #[serde(default)]
    since: u64,
    #[serde(skip)]
    unreadable: bool,
}

impl Marker {
    fn message(&self) -> &'static str {
        if self.unreadable { UNREADABLE } else { MESSAGE }
    }
}

fn valid_id(id: &str) -> bool {
    !id.is_empty() && !id.contains(['/', '\\', '.'])
}

fn marker_path(data_root: &Path, id: &str) -> PathBuf {
    crate::layout::private(data_root, id).join(MARKER_FILE)
}

fn marker(data_root: &Path, id: &str) -> Option<Marker> {
    if !valid_id(id) {
        return None;
    }
    let unreadable = || Marker { unreadable: true, ..Marker::default() };
    match std::fs::read(marker_path(data_root, id)) {
        Ok(bytes) => Some(serde_json::from_slice::<Marker>(&bytes).unwrap_or_else(|_| unreadable())),
        Err(error_value) if error_value.kind() == std::io::ErrorKind::NotFound => None,
        Err(_) => Some(unreadable()),
    }
}

/// Whether the app is in maintenance, since when, and why the Kernel holds
/// it, as an owner or an operator reads it. `installation` names a hold that
/// the app's own state cannot lift: a restore that was not reconciled.
pub fn read(data_root: &Path, id: &str) -> Value {
    let own = marker(data_root, id);
    json!({
        "maintenance": own.is_some() || super::recovery::hold(data_root).is_some(),
        "since": own.as_ref().filter(|marker| !marker.unreadable).map(|marker| marker.since),
        "unreadable": own.as_ref().is_some_and(|marker| marker.unreadable),
        "installation": super::recovery::hold(data_root),
    })
}

/// Puts the app `id` in maintenance or takes it out, and answers as `read`
/// does. Putting a paused app in again keeps the time it started. Taking it
/// out removes the state even when it cannot be read, since whoever runs the
/// app has decided. A hold of the whole installation stays.
pub fn set(data_root: &Path, id: &str, on: bool) -> Result<Value> {
    anyhow::ensure!(valid_id(id), "Invalid app ID.");
    let path = marker_path(data_root, id);
    if on {
        let since = match std::fs::read(&path).ok().and_then(|bytes| serde_json::from_slice::<Marker>(&bytes).ok()) {
            Some(marker) => marker.since,
            None => now_ms(),
        };
        std::fs::create_dir_all(path.parent().context("The maintenance state has no folder.")?)?;
        let temp = path.with_extension(format!("tmp-{}", Uuid::new_v4().simple()));
        std::fs::write(&temp, serde_json::to_vec(&Marker { since, unreadable: false })?)?;
        std::fs::rename(&temp, &path)?;
    } else {
        match std::fs::remove_file(&path) {
            Err(error_value) if error_value.kind() != std::io::ErrorKind::NotFound => return Err(error_value.into()),
            _ => {}
        }
    }
    Ok(read(data_root, id))
}

#[cfg(any(test, feature = "testing"))]
pub fn pause_for_test(data_root: &Path, id: &str, paused: bool) {
    let path = marker_path(data_root, id);
    if paused {
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(&path, serde_json::to_vec(&Marker { since: now_ms(), unreadable: false }).unwrap()).unwrap();
    } else {
        let _ = std::fs::remove_file(&path);
    }
}

/// Why a Deployment is paused: its own maintenance state, or the
/// installation's when a restore has not reconciled its revocation record.
pub fn pause(data_root: &Path, id: &str) -> Option<String> {
    if let Some(message) = super::recovery::hold(data_root) {
        return Some(message);
    }
    marker(data_root, id).map(|marker| marker.message().to_owned())
}

/// Whether the mail worker must hold a job of this scope.
pub fn holds_mail(data_root: &Path, scope: &str) -> bool {
    super::recovery::hold(data_root).is_some()
        || scope.strip_prefix("deployment:").and_then(|id| marker(data_root, id)).is_some()
}

fn escape(value: &str) -> String {
    value.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;").replace('\'', "&#39;")
}

fn maintenance_page(name: &str, message: &str) -> Response {
    let html = format!(
        "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\
<title>{title} is in maintenance</title><style>{css}</style></head>\
<body><main><h1>{title} is in maintenance</h1><p>{message}</p></main></body></html>",
        css = crate::own_page::CSS,
        title = escape(name),
        message = escape(message),
    );
    let mut response = (StatusCode::SERVICE_UNAVAILABLE, html).into_response();
    let headers = response.headers_mut();
    headers.insert(header::CONTENT_TYPE, HeaderValue::from_static("text/html; charset=utf-8"));
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    headers.insert(header::RETRY_AFTER, HeaderValue::from_static("300"));
    headers.insert("x-robots-tag", HeaderValue::from_static("noindex"));
    response
}

pub(crate) fn refusal(message: &str) -> Response {
    let mut response = (StatusCode::SERVICE_UNAVAILABLE, Json(json!({"error": message, "maintenance": true}))).into_response();
    response.headers_mut().insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response.headers_mut().insert(header::RETRY_AFTER, HeaderValue::from_static("300"));
    response
}

/// Middleware on every route. A request to a paused app's host gets the
/// maintenance page when it asks for a page, and a 503 with the message for
/// anything else: actions, uploads, signups, sign-ins, recovery, invitations
/// and HTTP routes. Nothing is redirected.
pub async fn guard(State(state): State<AppState>, request: Request, next: Next) -> Response {
    let path = request.uri().path();
    if path == "/_konae/health" {
        return next.run(request).await;
    }
    let Some(deployment) = deployment_for(&state, request.headers()).await else {
        if let Some(message) = super::recovery::hold(&state.data_root) {
            return refusal(&message);
        }
        return next.run(request).await;
    };
    let Some(message) = pause(&state.data_root, &deployment.id) else {
        return next.run(request).await;
    };
    let wants_page = request
        .headers()
        .get(header::ACCEPT)
        .and_then(|value| value.to_str().ok())
        .is_some_and(|accept| accept.contains("text/html"));
    if matches!(*request.method(), Method::GET | Method::HEAD) && (!path.starts_with("/_konae/") || wants_page) {
        maintenance_page(&deployment.project_name, &message)
    } else {
        refusal(&message)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn scratch() -> PathBuf {
        let root = std::env::temp_dir().join(format!("konae-maintenance-{}", Uuid::new_v4()));
        std::fs::create_dir_all(crate::layout::data(&root, "app-1")).unwrap();
        std::fs::create_dir_all(crate::layout::data(&root, "app-2")).unwrap();
        root
    }

    #[test]
    fn the_state_survives_a_restart_and_an_unreadable_one_pauses() {
        let root = scratch();
        assert!(pause(&root, "app-1").is_none());
        pause_for_test(&root, "app-1", true);
        assert_eq!(pause(&root, "app-1").as_deref(), Some(MESSAGE));
        std::fs::write(marker_path(&root, "app-1"), "{not json").unwrap();
        assert_eq!(pause(&root, "app-1").as_deref(), Some(UNREADABLE));
        pause_for_test(&root, "app-1", false);
        assert!(pause(&root, "app-1").is_none());
        assert!(marker(&root, "../escape").is_none());
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn an_owner_puts_an_app_in_and_takes_it_out() {
        let root = scratch();
        let on = set(&root, "app-1", true).unwrap();
        assert_eq!(on["maintenance"], true);
        let since = on["since"].as_u64().unwrap();
        assert_eq!(pause(&root, "app-1").as_deref(), Some(MESSAGE));
        assert_eq!(set(&root, "app-1", true).unwrap()["since"], since, "a second pause keeps its start");
        assert_eq!(read(&root, "app-2")["maintenance"], false);
        let off = set(&root, "app-1", false).unwrap();
        assert_eq!((off["maintenance"].clone(), off["since"].clone()), (json!(false), Value::Null));
        assert!(pause(&root, "app-1").is_none());
        std::fs::write(marker_path(&root, "app-1"), "{not json").unwrap();
        assert_eq!(read(&root, "app-1")["unreadable"], true);
        assert_eq!(set(&root, "app-1", false).unwrap()["maintenance"], false);
        assert!(set(&root, "../escape", true).is_err());
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn the_mail_worker_holds_a_paused_apps_email_only() {
        let root = scratch();
        pause_for_test(&root, "app-1", true);
        assert!(holds_mail(&root, "deployment:app-1"));
        assert!(!holds_mail(&root, "deployment:app-2"));
        assert!(!holds_mail(&root, "installation"));
        pause_for_test(&root, "app-1", false);
        assert!(!holds_mail(&root, "deployment:app-1"));
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn the_maintenance_page_escapes_what_it_shows() {
        let response = maintenance_page("<b>Notes</b>", "Paused & waiting");
        assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
        let runtime = tokio::runtime::Builder::new_current_thread().build().unwrap();
        let bytes = runtime.block_on(axum::body::to_bytes(response.into_body(), 1 << 20)).unwrap();
        let body = String::from_utf8(bytes.to_vec()).unwrap();
        assert!(body.contains("&lt;b&gt;Notes&lt;/b&gt;"));
        assert!(body.contains("Paused &amp; waiting"));
        assert!(!body.contains("<script"));
    }
}
