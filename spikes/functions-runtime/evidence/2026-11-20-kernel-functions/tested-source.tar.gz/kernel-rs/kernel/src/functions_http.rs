use crate::{
    AppState, Deployment, Operation,
    function_data::{self, Admission, InvocationConfig},
    functions::Function,
    functions_runtime::RunProgress,
    usage::{FunctionOutcome, FunctionTiming},
};
use axum::{
    Json,
    body::Body,
    extract::Request,
    http::{HeaderName, HeaderValue, StatusCode, header},
    response::{IntoResponse, Response},
};
use konae_functions_executor::{Budget, Input, Output};
use serde_json::{Value, json};
use std::{
    path::PathBuf,
    sync::Arc,
    time::{Duration, Instant},
};

struct Cancel(Budget);
impl Drop for Cancel {
    fn drop(&mut self) {
        self.0.cancel();
    }
}
struct Timed {
    response: Response,
    queue: Duration,
    initialization: Duration,
    execution: Duration,
    cold: bool,
    outcome: FunctionOutcome,
}
impl Timed {
    fn refusal(response: Response, elapsed: Duration) -> Self {
        Self {
            response,
            queue: elapsed,
            initialization: Duration::ZERO,
            execution: Duration::ZERO,
            cold: false,
            outcome: FunctionOutcome::Refused,
        }
    }
}

fn failure(status: u16, code: &str, message: &str) -> Response {
    (
        StatusCode::from_u16(status).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR),
        Json(json!({"error":message,"code":code})),
    )
        .into_response()
}
fn executor_failure(code: &str) -> Response {
    let status = match code {
        "deadline_exceeded" | "cancelled" => 504,
        "mutation_outcome_unknown" => 409,
        "function.runner-unavailable"
        | "containment_unavailable"
        | "function.capacity"
        | "queue_full"
        | "cache_busy" => 503,
        "worker_failed"
        | "worker_initialization_failed"
        | "worker_execution_failed"
        | "worker_protocol_error"
        | "invalid_response"
        | "worker_memory_limit"
        | "response_too_large"
        | "pending_work" => 502,
        _ => 500,
    };
    failure(
        status,
        code,
        match status {
            504 => "The function exceeded its execution budget.",
            503 => "The function executor is unavailable.",
            409 => {
                "The mutation outcome is unknown. Repeat this request with the same Idempotency-Key."
            }
            _ => "The function could not complete.",
        },
    )
}
fn outcome(code: &str) -> FunctionOutcome {
    match code {
        "deadline_exceeded" | "cancelled" => FunctionOutcome::DeadlineExceeded,
        "mutation_outcome_unknown" => FunctionOutcome::MutationOutcomeUnknown,
        _ => FunctionOutcome::Failed,
    }
}

fn interrupted(budget: &Budget, code: &str, started: Instant, progress: &RunProgress) -> Timed {
    let code = if budget.cancel().may_have_committed() {
        "mutation_outcome_unknown"
    } else {
        code
    };
    let now = Instant::now();
    let queue = progress
        .initialization_started
        .or(progress.execution_started)
        .unwrap_or(now)
        .saturating_duration_since(started);
    let initialization = progress
        .initialization_started
        .map(|at| {
            progress
                .execution_started
                .or(progress.finished)
                .unwrap_or(now)
                .saturating_duration_since(at)
        })
        .unwrap_or_default();
    let execution = progress
        .execution_started
        .map(|at| now.saturating_duration_since(at))
        .unwrap_or_default();
    Timed {
        response: executor_failure(code),
        queue,
        initialization,
        execution,
        cold: progress.cold,
        outcome: outcome(code),
    }
}

fn record(
    state: &AppState,
    deployment: &Deployment,
    name: String,
    budget: &Budget,
    started: Instant,
    timed: Timed,
) -> Response {
    let now = Instant::now();
    crate::usage::function_latency(
        &state.data_root,
        &deployment.id,
        FunctionTiming {
            name,
            version: deployment.artifact_version.clone(),
            budget: budget.deadline().duration_since(started),
            total: now.duration_since(started),
            queue: timed.queue,
            initialization: timed.initialization,
            execution: timed.execution,
            cold: timed.cold,
            timed_out: now >= budget.deadline(),
            outcome: timed.outcome,
        },
    );
    timed.response
}
fn declaration(deployment: &Deployment, path: &str) -> Option<(String, Function)> {
    deployment
        .server
        .as_ref()?
        .manifest
        .functions
        .iter()
        .find(|(_, f)| {
            path == f.mount
                || path
                    .strip_prefix(&f.mount)
                    .is_some_and(|rest| rest.starts_with('/'))
        })
        .map(|(name, function)| (name.clone(), function.clone()))
}

/// A function request holds the publication lease until native work and its receipt finish.
pub(crate) async fn dispatch(state: &AppState, request: Request) -> Result<Response, Request> {
    let Some(observed) = crate::deployment_for(state, request.headers()).await else {
        return Err(request);
    };
    let Some((observed_name, _)) = declaration(&observed, request.uri().path()) else {
        return Err(request);
    };
    let started = Instant::now();
    let budget = Budget::until(started + state.functions.deadline);
    let _cancel = Cancel(budget.clone());
    let deadline = tokio::time::Instant::from_std(budget.deadline());
    let admission = match state.functions.admit(&budget) {
        Ok(admission) => admission,
        Err(code) => {
            let timed = Timed::refusal(executor_failure(&code), started.elapsed());
            return Ok(record(
                state,
                &observed,
                observed_name,
                &budget,
                started,
                timed,
            ));
        }
    };
    let (generation, held, deployment) = match tokio::time::timeout_at(deadline, async {
        let generation = state.copies.generations.clone().read_owned().await;
        let held = crate::named_lock(state, &format!("publish:{}", observed.id), false).await;
        let deployment = crate::deployment_by_id(state, &observed.id).await;
        (generation, held, deployment)
    })
    .await
    {
        Ok(held) => held,
        Err(_) => {
            let timed = interrupted(
                &budget,
                "deadline_exceeded",
                started,
                &RunProgress::default(),
            );
            return Ok(record(
                state,
                &observed,
                observed_name,
                &budget,
                started,
                timed,
            ));
        }
    };
    let Some(deployment) = deployment else {
        return Ok(failure(404, "function.not-found", "Function not found."));
    };
    let Some((name, function)) = declaration(&deployment, request.uri().path()) else {
        return Err(request);
    };
    let bundle_hash = deployment.server.as_ref().unwrap().hashes[&name].clone();
    let operation = request
        .extensions()
        .get::<Operation>()
        .map(|operation| operation.0.clone());
    let prepare = async {
        if let Some(message) = crate::maintenance::pause(&state.data_root, &deployment.id) {
            return Err(crate::maintenance::refusal(&message));
        }
        crate::modules::require_on(&deployment.modules, "functions")
            .map_err(|refused| crate::refusal_error(&refused))?;
        if !function
            .methods
            .iter()
            .any(|method| method == request.method().as_str())
        {
            let mut response = failure(
                405,
                "function.method-not-allowed",
                "The function does not declare this HTTP method.",
            );
            response.headers_mut().insert(
                header::ALLOW,
                HeaderValue::from_str(&function.methods.join(", ")).unwrap(),
            );
            return Err(response);
        }
        if !crate::same_origin(request.headers())
            || crate::path::foreign_referer(state, request.headers(), &deployment.id)
        {
            return Err(failure(
                403,
                "function.origin-refused",
                "Cross-origin function request rejected.",
            ));
        }
        if crate::runtime::bearer(request.headers()).is_some_and(|token| token.starts_with("lbk_"))
        {
            return Err(failure(
                403,
                "function.key-refused",
                "Functions do not accept API keys.",
            ));
        }
        let actor = if crate::modules::is_on(&deployment.modules, "auth") {
            crate::authenticate_deployment(state, &deployment, request.headers()).await?
        } else {
            None
        };
        if (crate::is_private(&deployment) || function.access == "authenticated") && actor.is_none()
        {
            return Err(failure(
                401,
                "authentication-required",
                "authentication-required",
            ));
        }
        let peer = request
            .extensions()
            .get::<axum::extract::ConnectInfo<std::net::SocketAddr>>()
            .map(|value| value.0);
        let client = state.guards.client_ip(peer, request.headers());
        let limited = match &actor {
            Some(user) => state
                .guards
                .signed_in_actions
                .check(&format!("runtime:{}:{}", deployment.id, user.user_id)),
            None => state.guards.anonymous_actions.check(&format!(
                "{}|{}",
                deployment.id,
                crate::limits::client_key(client)
            )),
        };
        limited.map_err(crate::http::rate_limited)?;
        let actor_id = actor.map(|user| user.user_id);
        let headers = [header::ACCEPT, header::CONTENT_TYPE]
            .into_iter()
            .filter_map(|name| {
                request
                    .headers()
                    .get(&name)
                    .and_then(|value| value.to_str().ok())
                    .map(|value| (name.as_str().to_owned(), value.trim().to_owned()))
            })
            .collect::<Vec<_>>();
        let key = request
            .headers()
            .get("idempotency-key")
            .and_then(|value| value.to_str().ok())
            .map(str::to_owned);
        let path = request
            .uri()
            .path_and_query()
            .map(|value| value.as_str())
            .unwrap_or("/")
            .to_owned();
        let method = request.method().as_str().to_owned();
        let body = axum::body::to_bytes(request.into_body(), 16 * 1024)
            .await
            .map_err(|_| {
                failure(
                    413,
                    "body_too_large",
                    "The function request exceeds 16384 bytes.",
                )
            })?
            .to_vec();
        let cache_key = format!(
            "{}:{}:{}:{bundle_hash}",
            deployment.id, name, deployment.artifact_version
        );
        let lease = state
            .functions
            .lease_admitted(cache_key, &budget, admission)
            .await
            .map_err(|code| executor_failure(&code))?;
        let has_data = !function.actions.is_empty();
        if has_data {
            crate::modules::require_on(&deployment.modules, "actions")
                .map_err(|refused| crate::refusal_error(&refused))?;
        }
        let sql_slot = if has_data {
            Some(
                state
                    .guards
                    .statement_permit(&deployment.id)
                    .await
                    .map_err(crate::http::rate_limited)?,
            )
        } else {
            None
        };
        let sql_guard = if has_data {
            Some(
                crate::action_lock(
                    state,
                    &deployment.id,
                    if method == "GET" { "query" } else { "mutation" },
                )
                .await,
            )
        } else {
            None
        };
        let program = Arc::new(crate::action_shape::read(&deployment.actions).map_err(|_| {
            failure(
                500,
                "function.program-invalid",
                "The published actions cannot be read.",
            )
        })?);
        let config = InvocationConfig {
            database: has_data.then(|| crate::layout::database(&state.data_root, &deployment.id)),
            program,
            function_name: name.clone(),
            function,
            actor: actor_id.clone(),
            method: method.clone(),
            path: path.clone(),
            body: body.clone(),
            headers: headers.clone(),
            idempotency_key: key,
        };
        let input = Input {
            url: format!("https://function.invalid{path}"),
            method,
            headers,
            body,
            actor: actor_id.unwrap_or_default(),
        };
        Ok((lease, sql_slot, sql_guard, config, input))
    };
    let prepared = tokio::time::timeout_at(deadline, prepare).await;
    let timed = match prepared {
        Err(_) => interrupted(
            &budget,
            "deadline_exceeded",
            started,
            &RunProgress::default(),
        ),
        Ok(Err(_)) if Instant::now() >= budget.deadline() => interrupted(
            &budget,
            "deadline_exceeded",
            started,
            &RunProgress::default(),
        ),
        Ok(Err(response)) => Timed::refusal(response, started.elapsed()),
        Ok(Ok((mut lease, sql_slot, sql_guard, config, input))) => {
            let progress = lease.progress();
            let state = state.clone();
            let deployment = deployment.clone();
            let worker_budget = budget.clone();
            let name = name.clone();
            let task = tokio::task::spawn_blocking(move || {
                let budget = worker_budget;
                let _operation = operation;
                let _generation = generation;
                let _held = held;
                let _slot = sql_slot;
                let _sql = sql_guard;
                let admission = function_data::admit(config, budget.clone());
                let queue = started.elapsed();
                let mut invocation = match admission {
                    Ok(Admission::Replay(output)) => {
                        return Timed {
                            response: respond(output),
                            queue,
                            initialization: Duration::ZERO,
                            execution: Duration::ZERO,
                            cold: false,
                            outcome: FunctionOutcome::Replayed,
                        };
                    }
                    Ok(Admission::Run(invocation)) => invocation,
                    Err(error) => {
                        return Timed {
                            response: failure(error.status, error.code, &error.message),
                            queue,
                            initialization: Duration::ZERO,
                            execution: Duration::ZERO,
                            cold: false,
                            outcome: outcome(error.code),
                        };
                    }
                };
                let bundle = match pinned_bundle(&state, &deployment, &name) {
                    Ok(directory) => directory,
                    Err(_) => {
                        let _ = invocation.abort();
                        return Timed::refusal(
                            failure(
                                503,
                                "function.artifact-changed",
                                "The function bundle does not match its published version.",
                            ),
                            started.elapsed(),
                        );
                    }
                };
                let began = Instant::now();
                let queue = began.duration_since(started);
                let mut native_failure = None;
                let run = lease.run(&name, &bundle.0, input, &budget, &mut |operation, args| {
                    if operation != "action" {
                        return Err("function.operation-forbidden".into());
                    }
                    let Some(action) = args["name"].as_str() else {
                        return Err("function.input-invalid".into());
                    };
                    match invocation.action(action, args.get("input").unwrap_or(&Value::Null)) {
                        Ok(answer) => Ok(answer),
                        Err(error) => {
                            let code = error.code.to_owned();
                            native_failure = Some(error);
                            Err(code)
                        }
                    }
                });
                let (response, result_outcome) = match run.output {
                    Ok(mut output) => {
                        output.headers.retain(|(name, _)| {
                            ["content-type", "location", "retry-after"]
                                .contains(&name.to_ascii_lowercase().as_str())
                        });
                        match invocation.finish(output) {
                            Ok(output) => {
                                let outcome = if output.status >= 500 {
                                    FunctionOutcome::Failed
                                } else if output.status >= 400 {
                                    FunctionOutcome::Refused
                                } else {
                                    FunctionOutcome::Ok
                                };
                                (respond(output), outcome)
                            }
                            Err(error) => (
                                failure(error.status, error.code, &error.message),
                                outcome(error.code),
                            ),
                        }
                    }
                    Err(error) => {
                        let _ = invocation.abort();
                        if let Some(error) = native_failure {
                            (
                                failure(error.status, error.code, &error.message),
                                outcome(error.code),
                            )
                        } else {
                            let code =
                                budget.failure_code().map(str::to_owned).unwrap_or_else(|| {
                                    konae_functions_executor::error_code(&error).to_owned()
                                });
                            (executor_failure(&code), outcome(&code))
                        }
                    }
                };
                Timed {
                    response,
                    queue,
                    initialization: run.initialization,
                    execution: began.elapsed().saturating_sub(run.initialization),
                    cold: run.cold,
                    outcome: result_outcome,
                }
            });
            match tokio::time::timeout_at(deadline, task).await {
                Ok(Ok(timed)) if Instant::now() < budget.deadline() => timed,
                Ok(Err(_)) if Instant::now() < budget.deadline() => {
                    let progress = progress.lock().unwrap_or_else(|error| error.into_inner());
                    interrupted(&budget, "function.executor-failed", started, &progress)
                }
                _ => {
                    let progress = progress.lock().unwrap_or_else(|error| error.into_inner());
                    interrupted(&budget, "deadline_exceeded", started, &progress)
                }
            }
        }
    };
    Ok(record(state, &deployment, name, &budget, started, timed))
}

struct Bundle(PathBuf);
impl Drop for Bundle {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}
fn pinned_bundle(state: &AppState, deployment: &Deployment, name: &str) -> anyhow::Result<Bundle> {
    let artifact =
        crate::functions::read_artifact(&crate::layout::server(&state.data_root, &deployment.id))?
            .ok_or_else(|| anyhow::anyhow!("Missing server artifact"))?;
    let metadata = crate::functions::validate_artifact(Some(&artifact.manifest), Some(&artifact))?;
    anyhow::ensure!(
        metadata == deployment.server,
        "Published server artifact changed"
    );
    let directory = crate::layout::private(&state.data_root, &deployment.id)
        .join(format!("function-input-{}", uuid::Uuid::new_v4().simple()));
    let bundle = Bundle(directory);
    std::fs::create_dir_all(&bundle.0)?;
    std::fs::write(
        bundle.0.join(format!("{name}.mjs")),
        &artifact.bundles[name],
    )?;
    Ok(bundle)
}
fn respond(output: Output) -> Response {
    let mut response = Response::new(Body::from(output.body));
    *response.status_mut() =
        StatusCode::from_u16(output.status).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);
    for (name, value) in output.headers {
        if let (Ok(name), Ok(value)) = (
            HeaderName::from_bytes(name.as_bytes()),
            HeaderValue::from_str(&value),
        ) {
            response.headers_mut().append(name, value);
        }
    }
    response.headers_mut().insert(
        header::CACHE_CONTROL,
        HeaderValue::from_static("private, no-store"),
    );
    response
}

#[cfg(test)]
#[path = "functions_http_tests.rs"]
mod tests;
