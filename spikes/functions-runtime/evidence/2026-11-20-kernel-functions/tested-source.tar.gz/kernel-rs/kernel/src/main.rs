
use kernel::installation::Installation;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let installation = Installation::kernel();
    if kernel::inventory::command("kernel", &installation)? { return Ok(()); }
    if kernel::operator_command(&installation).await? || kernel::operator::command(&installation).await? {
        return Ok(());
    }
    let startup = kernel::Startup::from_env()?;
    let lock = kernel::file_store::hold_kernel_lock(&startup.data_root)?;
    let mail_key = kernel::operator::mail_key(&startup.data_root)?;
    let mut running = kernel::start_locked(&startup, lock, installation, &mail_key, Vec::new(), None).await?;
    let confirmation = std::env::var(kernel::folder::CONFIRM_SCHEMA).ok();
    for (id, opened) in kernel::folder::open_all(&running.state, confirmation.as_deref()).await? {
        match opened {
            Ok(deployment) => println!("Serving {} at {}", deployment.project_name, deployment.url),
            Err(error_value) => eprintln!("Not serving apps/{id}: {error_value:#}"),
        }
    }
    running.start_copies();
    kernel::folder::follow_settings(running.state.clone());
    kernel::listen(&startup, running.state.clone(), axum::Router::new(), "Kernel").await
}
