use std::{
    collections::HashMap,
    path::{Path, PathBuf},
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};

use anyhow::{Context, Result};
use aws_sdk_s3::Client as S3Client;
use axum::{
    Json, Router, ServiceExt,
    body::Body,
    extract::{Path as AxumPath, Request, State},
    http::{HeaderMap, HeaderValue, StatusCode, header},
    response::{IntoResponse, Response},
    routing::{get, post},
};
use tower::ServiceBuilder;
use rusqlite::hooks::{AuthAction, AuthContext, Authorization};
use rusqlite::{Connection, OptionalExtension, params_from_iter, types::Value as SqlValue};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use tokio::sync::{OwnedRwLockReadGuard, OwnedRwLockWriteGuard, RwLock};
use uuid::Uuid;

pub mod accounts;
pub mod action_shape;
pub mod app_db;
pub mod artifact;
pub mod auth;
pub mod calls;
pub mod copies;
pub mod domain;
pub mod execution;
pub mod enter;
pub mod file_store;
pub mod files;
pub mod folder;
pub mod functions;
pub mod function_data;
pub mod functions_runtime;
pub mod functions_http;
pub mod google;
pub mod guard;
pub mod heap;
pub mod hostname;
pub mod hosts;
pub mod import;
pub mod installation;
pub mod inventory;
pub mod http;
pub mod invitations;
pub mod layout;
pub mod limits;
pub mod mail;
pub mod maintenance;
pub mod modules;
pub mod notify;
pub mod operator;
pub mod own_page;
pub mod package;
pub mod page;
pub mod path;
pub mod path_name;
pub mod provider;
pub mod recovery;
pub mod refusal;
pub mod runtime;
pub mod schedule;
pub mod schema_change;
pub mod schema_transform;
pub mod security;
pub mod seo;
pub mod size;
pub mod sources;
pub mod sql_rules;
pub mod transfers;
#[cfg(test)]
pub mod sqlite_bench;
pub mod usage;
use auth::{AuthError, AuthService, AuthUser};
use limits::{Guards, trusted_proxies};

#[derive(Clone)]
pub struct AppState {
    pub execution_mode: execution::ExecutionMode,
    pub deployments: Arc<RwLock<HashMap<String, Deployment>>>,
    pub db_locks: LockMap,
    pub s3: Option<S3Client>,
    pub data_bucket: String,
    pub data_root: PathBuf,
    /// Where file bytes live and how many a Deployment may hold.
    pub files: file_store::Files,
    pub copies: Arc<copies::CopyStatus>,
    pub public_origin: String,
    /// The origins the installation answers on itself besides the public
    /// origin, such as where Konae's MCP answers. The first is where a
    /// client signs in.
    pub own_origins: Vec<String>,
    pub host_suffix: String,
    /// `<scheme>://<domain>` where path addresses answer; `None` without `KONAE_DOMAIN`.
    pub path_origin: Option<String>,
    pub guards: Arc<Guards>,
    pub accounts: accounts::AccountSettings,
    /// The stores at the data root besides the app folders.
    pub installation: Arc<installation::Installation>,
    /// Where an app user's file uploads and deletes are recorded.
    pub audit: Option<runtime::AuditSink>,
    pub functions: Arc<functions_runtime::Runtime>,
}

#[cfg(any(test, feature = "testing"))]
impl AppState {
    /// A Kernel on `root` with no Deployments, local files, no mail and the
    /// `localhost` names. A test changes the fields it needs with `..`.
    pub fn for_test(root: &Path) -> Self {
        Self {
            execution_mode: execution::ExecutionMode::Live,
            deployments: Arc::new(RwLock::new(HashMap::new())),
            db_locks: LockMap::default(),
            s3: None,
            data_bucket: "data".into(),
            files: file_store::Files::local(root),
            data_root: root.into(),
            copies: Default::default(),
            accounts: accounts::AccountSettings::local(),
            public_origin: "http://localhost".into(),
            own_origins: Vec::new(),
            path_origin: None,
            host_suffix: "localhost".into(),
            guards: Arc::new(Guards::new(Vec::new())),
            installation: Arc::new(installation::Installation::for_test()),
            audit: None,
            functions: Arc::new(functions_runtime::Runtime::disabled()),
        }
    }
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Deployment {
    /// The app's ID. It names the app's folder, and the project in Konae.
    pub id: String,
    pub project_id: String,
    pub project_name: String,
    pub slug: String,
    pub url: String,
    pub created_at: u64,


    #[serde(default)]
    pub released_at: u64,



    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub source_digest: Option<String>,
    pub manifest: Value,
    pub hostname: String,
    pub actions: String,
    /// The release whose files `dist/` holds. It tags them for browser caches.
    pub artifact_version: String,
    /// Who may create an account.
    pub signup_policy: SignupPolicy,
    /// How people sign in. Password always; Google when the owner turned it on.
    pub sign_in_methods: Vec<SignInMethod>,
    #[serde(default = "modules::defaults")]
    pub modules: std::collections::BTreeMap<String, Value>,


    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub contact_email: Option<String>,
    #[serde(skip, default)]
    pub released_schema: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub server: Option<functions::Published>,
}



#[derive(Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Settings {
    pub id: String,
    pub name: String,
    pub slug: String,
    pub visibility: String,
    pub signup_policy: SignupPolicy,
    pub sign_in_methods: Vec<SignInMethod>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub contact_email: Option<String>,
    /// The version of the Kernel that wrote the file.
    pub kernel: String,
    /// The Capsule manifest without its visibility: routing, connects and the declared actions.
    pub manifest: Value,
    #[serde(default = "modules::defaults")]
    pub modules: std::collections::BTreeMap<String, Value>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub directories: Vec<String>,
    #[serde(default)]
    pub updated_at: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub released: Option<ReleasedSettings>,
}



#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Installed {
    pub hostname: String,
    pub created_at: u64,


    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub released_at: Option<u64>,

    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub source_digest: Option<String>,
    /// The `actions.json` of the release `dist/` holds.
    pub actions: String,
    pub artifact_version: String,


    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub released: Option<ReleasedSettings>,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ReleasedSettings {
    pub name: String,
    pub slug: String,
    pub visibility: String,
    pub signup_policy: SignupPolicy,
    pub sign_in_methods: Vec<SignInMethod>,
    pub contact_email: Option<String>,
    pub manifest: Value,
    #[serde(default)]
    pub actions: String,
    #[serde(default)]
    pub schema_sql: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub schema_transforms: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub server: Option<functions::Published>,
    #[serde(default)]
    pub source_digest: Option<String>,
    #[serde(default)]
    pub artifact_digest: Option<String>,
    #[serde(default)]
    pub released_at: Option<u64>,
}

fn released_settings(deployment: &Deployment) -> ReleasedSettings {
    let mut manifest = deployment.manifest.clone();
    if let Some(object) = manifest.as_object_mut() { object.remove("visibility"); object.remove("runtime"); }
    ReleasedSettings {
        name: deployment.project_name.clone(), slug: deployment.slug.clone(),
        visibility: deployment.manifest["visibility"].as_str().unwrap_or("private").into(),
        signup_policy: deployment.signup_policy.clone(), sign_in_methods: deployment.sign_in_methods.clone(),
        contact_email: deployment.contact_email.clone(), manifest,
        actions: deployment.actions.clone(), schema_sql: deployment.released_schema.clone(),
        schema_transforms: None,
        server: deployment.server.clone(),
        source_digest: deployment.source_digest.clone(), released_at: Some(deployment.released_at),
        artifact_digest: None,
    }
}

pub const KERNEL_VERSION: &str = env!("CARGO_PKG_VERSION");

impl Settings {
    pub fn new(id: &str, name: &str, slug: &str, manifest: &Value) -> Self {
        let visibility = manifest["visibility"].as_str().unwrap_or("private").to_owned();
        let mut manifest = manifest.clone();
        if let Some(object) = manifest.as_object_mut() {
            object.remove("visibility");
            object.remove("runtime");
            object.remove("fileAccess");
        }
        let mut settings = Self {
            id: id.into(),
            name: name.into(),
            slug: slug.into(),
            signup_policy: SignupPolicy::initial(&visibility),
            visibility,
            sign_in_methods: default_sign_in_methods(),
            contact_email: None,
            kernel: KERNEL_VERSION.into(),
            manifest,
            modules: {
                let mut modules = modules::defaults();
                modules.remove("actions");
                modules.remove("http");
                modules.remove("calls");
                modules
            },
            directories: Vec::new(),
            updated_at: 0,
            released: None,
        };
        settings.sync_auth_options();
        settings
    }

    pub fn of(deployment: &Deployment) -> Self {
        let mut settings = Self {
            signup_policy: deployment.signup_policy.clone(),
            sign_in_methods: deployment.sign_in_methods.clone(),
            contact_email: deployment.contact_email.clone(),
            modules: deployment.modules.clone(),
            ..Self::new(&deployment.id, &deployment.project_name, &deployment.slug, &deployment.manifest)
        };
        settings.released = Some(released_settings(deployment));
        settings.sync_auth_options();
        settings
    }

    fn sync_auth_options(&mut self) {
        let auth = self.modules.get_mut("auth").expect("auth is switchable");
        auth["signupPolicy"] = serde_json::to_value(&self.signup_policy).expect("Signup Policy serializes");
        auth["signInMethods"] = serde_json::to_value(&self.sign_in_methods).expect("sign-in methods serialize");
    }

    pub fn read(root: &Path, id: &str) -> Result<Self> {
        let bytes = std::fs::read(layout::settings(root, id))?;
        let raw: Value = serde_json::from_slice(&bytes)?;
        let mut settings: Self = serde_json::from_slice(&bytes)?;
        if let Some(raw_modules) = raw["modules"].as_object() {
            let raw_modules = raw_modules.iter().map(|(name, state)| (name.clone(), state.clone())).collect();
            if let Err(refusal) = modules::validate_state(&raw_modules) {
                eprintln!("konae: ignoring invalid module state in apps/{id}/konae.json: {}", refusal.message);
                anyhow::bail!("{}", refusal.message);
            }
        }
        modules::complete(&mut settings.modules);
        let nested_policy = settings.modules["auth"]["signupPolicy"].clone();
        let nested_methods = settings.modules["auth"]["signInMethods"].clone();
        settings.signup_policy = match raw.get("signupPolicy").filter(|value| !value.is_null()) {
            Some(value) => serde_json::from_value(value.clone())?,
            None if !nested_policy.is_null() => serde_json::from_value(nested_policy)?,
            None => SignupPolicy::initial(&settings.visibility),
        };
        settings.sign_in_methods = match raw.get("signInMethods").filter(|value| value.is_array()) {
            Some(value) => serde_json::from_value(value.clone())?,
            None if nested_methods.is_array() => serde_json::from_value(nested_methods)?,
            None => default_sign_in_methods(),
        };
        settings.sync_auth_options();
        if let Err(refusal) = modules::validate_state(&settings.modules) {
            eprintln!("konae: ignoring invalid module state in apps/{id}/konae.json: {}", refusal.message);
            anyhow::bail!("{}", refusal.message);
        }
        let old_file_access = raw["manifest"]["fileAccess"] == "app-users" || raw["released"]["manifest"]["fileAccess"] == "app-users";
        if raw["modules"]["files"].is_null() && old_file_access {
            let files = settings.modules.get_mut("files").expect("files is switchable");
            files["on"] = json!(true);
            files["fileAccess"] = json!("app-users");
        }
        if let Some(manifest) = settings.manifest.as_object_mut() { manifest.remove("fileAccess"); }
        if let Some(manifest) = settings.released.as_mut().and_then(|released| released.manifest.as_object_mut()) { manifest.remove("fileAccess"); }
        Ok(settings)
    }

    pub async fn write(&self, root: &Path) -> Result<()> {
        write_atomic(&layout::settings(root, &self.id), &self.folder_bytes()?).await?;
        Ok(())
    }

    fn folder_bytes(&self) -> Result<Vec<u8>> {
        let mut settings = self.clone();
        settings.sync_auth_options();
        let mut value = serde_json::to_value(settings)?;
        if let Some(auth) = value.get_mut("modules").and_then(|modules| modules.get_mut("auth")).and_then(Value::as_object_mut) {
            auth.remove("signupPolicy");
            auth.remove("signInMethods");
        }
        Ok(serde_json::to_vec_pretty(&value)?)
    }

    pub fn deployment(self, installed: Installed, public_origin: &str) -> Deployment {
        let released = installed.released.clone().or_else(|| self.released.clone());
        let mut manifest = released.as_ref().map(|r| r.manifest.clone()).unwrap_or(self.manifest);
        let name = released.as_ref().map(|r| r.name.clone()).unwrap_or(self.name);
        let slug = released.as_ref().map(|r| r.slug.clone()).unwrap_or(self.slug);
        let visibility = released.as_ref().map(|r| r.visibility.clone()).unwrap_or(self.visibility);
        let signup_policy = released.as_ref().map(|r| r.signup_policy.clone()).unwrap_or(self.signup_policy);
        let sign_in_methods = released.as_ref().map(|r| r.sign_in_methods.clone()).unwrap_or(self.sign_in_methods);
        let contact_email = released.as_ref().and_then(|r| r.contact_email.clone()).or(self.contact_email);
        if let Some(object) = manifest.as_object_mut() {
            object.insert("visibility".into(), Value::String(visibility));
        }
        Deployment {
            project_id: self.id.clone(),
            id: self.id,
            project_name: name,
            slug,
            url: deployment_url(public_origin, &installed.hostname),
            created_at: installed.created_at,
            released_at: installed.released_at.or_else(|| released.as_ref().and_then(|r| r.released_at)).unwrap_or(installed.created_at),
            source_digest: installed.source_digest.or_else(|| released.as_ref().and_then(|r| r.source_digest.clone())),
            manifest,
            hostname: installed.hostname,
            actions: installed.actions,
            artifact_version: installed.artifact_version,
            signup_policy,
            sign_in_methods,
            contact_email,
            modules: self.modules,
            released_schema: released.as_ref().map(|r| r.schema_sql.clone()).unwrap_or_default(),
            server: released.as_ref().and_then(|r| r.server.clone()),
        }
    }
}


#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SignInMethod {
    Password,
    Google,
}

pub fn default_sign_in_methods() -> Vec<SignInMethod> {
    vec![SignInMethod::Password]
}

pub const PASSWORD_REQUIRED: &str = "Password sign-in cannot be turned off, so every account keeps a way back in.";

/// Builds the methods from owner input: password first, each method once.
/// Password cannot be turned off in this version.
pub fn sign_in_methods_from_input(methods: &[SignInMethod]) -> std::result::Result<Vec<SignInMethod>, String> {
    if !methods.contains(&SignInMethod::Password) {
        return Err(PASSWORD_REQUIRED.into());
    }
    let mut result = vec![SignInMethod::Password];
    if methods.contains(&SignInMethod::Google) {
        result.push(SignInMethod::Google);
    }
    Ok(result)
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SignupMode {
    #[default]
    Open,

    Invitation,
    Allowlist,
    Closed,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SignupPolicy {
    pub mode: SignupMode,

    #[serde(default)]
    pub allowlist: Vec<String>,
}

pub const MAX_ALLOWLIST_ENTRIES: usize = 100;
pub const SIGNUP_REFUSED: &str = "This app is not accepting new accounts for this email address.";

impl SignupPolicy {
    /// Public apps start open. Private apps start closed until the owner
    /// chooses who may join.
    /// Open only for a Deployment that says it is public; any other value is closed.
    pub fn initial(visibility: &str) -> Self {
        Self {
            mode: if visibility == "public" {
                SignupMode::Open
            } else {
                SignupMode::Closed
            },
            allowlist: Vec::new(),
        }
    }

    /// The policy a redeploy keeps. Turning a public app private closes an
    /// open signup, since strangers who could join the public app should not
    /// get into the private one. Any other choice the owner made carries over.
    pub fn for_republish(&self, was_private: bool, visibility: &str) -> Self {
        if !was_private && visibility == "private" && self.mode == SignupMode::Open {
            Self {
                mode: SignupMode::Closed,
                allowlist: self.allowlist.clone(),
            }
        } else {
            self.clone()
        }
    }

    /// Builds a policy from owner input, normalizing and deduplicating entries.
    pub fn from_input(mode: SignupMode, entries: &[String]) -> std::result::Result<Self, String> {
        if entries.len() > MAX_ALLOWLIST_ENTRIES {
            return Err(format!(
                "The allowlist holds at most {MAX_ALLOWLIST_ENTRIES} entries."
            ));
        }
        let mut allowlist: Vec<String> = Vec::new();
        for entry in entries {
            let entry = entry.trim().to_lowercase();
            if entry.is_empty() {
                continue;
            }
            let valid = match entry.strip_prefix('@') {
                Some(domain) => {
                    domain.len() <= 253
                        && domain.contains('.')
                        && !domain.starts_with('.')
                        && !domain.ends_with('.')
                        && domain
                            .bytes()
                            .all(|b| b.is_ascii_alphanumeric() || b"-.".contains(&b))
                }
                None => auth::normalize_email(&entry).is_ok(),
            };
            if !valid {
                return Err(format!(
                    "{entry} is not an email address or an @domain entry."
                ));
            }
            if !allowlist.contains(&entry) {
                allowlist.push(entry);
            }
        }
        Ok(Self { mode, allowlist })
    }

    /// Decides whether this email may create an account. Domain entries match
    /// the exact domain after the `@`, never a subdomain.
    pub fn allows(&self, email: &str) -> bool {
        match self.mode {
            SignupMode::Open => true,
            SignupMode::Invitation | SignupMode::Closed => false,
            SignupMode::Allowlist => {
                let Ok(email) = auth::normalize_email(email) else {
                    return false;
                };
                let domain = email.rsplit_once('@').map(|(_, domain)| domain);
                self.allowlist.iter().any(|entry| match entry.strip_prefix('@') {
                    Some(allowed) => domain == Some(allowed),
                    None => *entry == email,
                })
            }
        }
    }
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DeployInput {
    pub project: ProjectInput,
    pub visibility: String,
    pub artifact: BuildArtifact,
    #[serde(default)]
    pub server_artifact: Option<functions::ServerArtifact>,
    #[serde(default)]
    pub initial_released: Option<ReleasedSettings>,
    #[serde(default)]
    pub initial_signup_policy: Option<SignupPolicy>,
    #[serde(default)]
    pub initial_sign_in_methods: Option<Vec<SignInMethod>>,
    #[serde(default)]
    pub initial_modules: Option<std::collections::BTreeMap<String, Value>>,

    #[serde(default)]
    pub initial_package: Option<package::InitialPackage>,

    #[serde(default)]
    pub contact_email: Option<String>,


    #[serde(default)]
    pub schema_confirmation: Option<String>,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ProjectInput {
    pub id: String,
    pub name: String,
    pub slug: String,



    #[serde(default)]
    pub files: HashMap<String, String>,
    #[serde(default)]
    pub encodings: HashMap<String, String>,
    #[serde(default)]
    pub directories: Vec<String>,
    pub manifest: Value,
}

impl ProjectInput {
    /// The bytes of each file of `app/` the release carries.
    pub fn sources(&self) -> Result<sources::Files, String> {
        sources::decode(&self.files, &self.encodings)
    }
}

#[derive(Clone, Deserialize)]
pub struct BuildArtifact {
    pub version: u8,
    pub entrypoint: String,
    pub files: HashMap<String, String>,

    #[serde(default)]
    pub encodings: HashMap<String, String>,
}

#[derive(Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DatabaseBackup {
    pub id: String,
    pub label: String,
    pub created_at: u64,
    pub size_bytes: u64,
    pub key: String,



    #[serde(default)]
    pub holds: Vec<String>,
}

impl DatabaseBackup {
    /// The backup as `list-backups` lists it.
    pub fn view(&self) -> Value {
        json!({"id": self.id, "label": self.label, "createdAt": self.created_at, "sizeBytes": self.size_bytes, "holds": self.holds})
    }
}

#[derive(Deserialize)]
pub struct ActionProgram {
    pub version: u8,
    pub actions: HashMap<String, ActionDefinition>,
}

#[derive(Clone, Deserialize)]
pub struct ActionDefinition {
    pub kind: String,
    pub access: String,

    #[serde(default)]
    pub statement: String,
    pub bindings: Vec<ActionBinding>,

    #[serde(default)]
    pub http: Option<Value>,

    #[serde(default)]
    pub page: Option<Value>,

    #[serde(default)]
    pub signal: Option<Value>,

    #[serde(default)]
    pub guard: Option<Value>,

    #[serde(default)]
    pub notify: Option<Value>,

    #[serde(default)]
    pub schedule: Option<Value>,

    #[serde(default)]
    pub subscribe: Option<Value>,


    #[serde(flatten)]
    pub call: calls::CallKeys,


    #[serde(flatten)]
    pub extra: serde_json::Map<String, Value>,
}

#[derive(Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ActionBinding {
    pub source: String,
    pub key: Option<String>,
    #[serde(rename = "type")]
    pub value_type: Option<String>,
    #[serde(default, deserialize_with = "whole_number")]
    pub max_length: Option<usize>,
    #[serde(default)]
    pub nullable: bool,
    pub field: Option<String>,
    pub value: Option<Value>,
}



fn whole_number<'de, D: serde::Deserializer<'de>>(deserializer: D) -> std::result::Result<Option<usize>, D::Error> {
    Option::<f64>::deserialize(deserializer)?
        .map(|number| {
            (number.fract() == 0.0 && (0.0..=u32::MAX as f64).contains(&number))
                .then_some(number as usize)
                .ok_or_else(|| serde::de::Error::custom("expected a whole number"))
        })
        .transpose()
}

/// Runs the operator commands both binaries answer: `restore`, the file
/// store commands and `reconcile`. Returns whether one ran.
pub async fn operator_command(installation: &installation::Installation) -> Result<bool> {
    Ok(copies::history::operator_command().await?
        || copies::operator_command(installation).await?
        || file_store::operator_command().await?
        || recovery::operator_command(installation).await?
        || recovery::drill_check(installation).await?)
}

/// What a Kernel process reads from its environment before it serves.
pub struct Startup {
    pub port: u16,
    pub bind: String,
    pub hosts: hosts::Hosts,
    pub data_root: PathBuf,
    pub execution_mode: execution::ExecutionMode,
}

impl Startup {
    pub fn from_env() -> Result<Self> {
        let bind = env("KONAE_BIND", "127.0.0.1");
        let execution_mode = execution::ExecutionMode::parse(std::env::var("KONAE_EXECUTION_MODE").ok().as_deref(), &bind)?;
        Ok(Self {
            port: env("KONAE_KERNEL_PORT", "8787").parse::<u16>()?,
            bind,
            hosts: hosts::from_env()?,
            data_root: PathBuf::from(env("KONAE_DATA_DIR", "/data")),
            execution_mode,
        })
    }
}

/// A started Kernel: its state, and the lock that makes `files-migrate` and
/// `files-reconcile` refuse while it serves.
pub struct Running {
    pub state: AppState,
    pub _lock: std::fs::File,
    copy_config: Option<copies::CopyConfig>,
}

/// Loads every app folder, builds the state and starts the workers: copies,
/// schedules, email and calls. `mail_key` seals queued links when
/// `KONAE_MAIL_SECRET` is unset. `own_origins` and `audit` are what the
/// starter adds: the origins it answers on and where app users' uploads and
/// deletes are recorded.
pub async fn start(
    startup: &Startup,
    installation: installation::Installation,
    mail_key: &str,
    own_origins: Vec<String>,
    audit: Option<runtime::AuditSink>,
) -> Result<Running> {
    let lock = file_store::hold_kernel_lock(&startup.data_root)?;
    let mut running = start_locked(startup, lock, installation, mail_key, own_origins, audit).await?;
    running.start_copies();
    Ok(running)
}

impl Running {
    pub fn start_copies(&mut self) {
        if let Some(config) = self.copy_config.take() {
            copies::spawn_schedule(self.state.clone(), config);
        }
    }
}

/// The binaries acquire the volume before opening accounts or reading the local mail key.
pub async fn start_locked(
    startup: &Startup,
    lock: std::fs::File,
    installation: installation::Installation,
    mail_key: &str,
    own_origins: Vec<String>,
    audit: Option<runtime::AuditSink>,
) -> Result<Running> {
    tokio::fs::create_dir_all(crate::layout::apps(&startup.data_root)).await?;
    let schedule_clock = schedule::Clock::from_env(&startup.bind)?;
    let (state, copy_config) = state_from_env(startup, installation, mail_key, own_origins, audit).await?;
    path::load(&state);
    let own_hosts = domain::Rules::of(&state).installation_hosts;
    for deployment in state.deployments.read().await.values().filter(|deployment| own_hosts.contains(&deployment.hostname)) {
        eprintln!("Not serving apps/{}: {} is this installation's own host. Move the app with hostname_set.", deployment.id, deployment.hostname);
    }

    schedule::spawn(state.clone(), schedule_clock);
    if let Some(queue) = state.accounts.queue.clone() {


        if let Some(mailbox) = queue.local_mailbox().filter(|_| security::https(&state)) {
            eprintln!(
                "WARNING: {} serves over https with KONAE_MAIL_TRANSPORT=development. No email leaves this server. Invitations, confirmation and recovery links and notices all go to {} instead. Set KONAE_MAIL_TRANSPORT to resend or smtp.",
                state.public_origin,
                mailbox.display()
            );
        }
        mail::spawn_worker(queue, state.copies.clone());
    }
    calls::spawn_worker(state.clone());
    Ok(Running { state, _lock: lock, copy_config })
}

/// The state a Kernel serves with, read from the environment, without its
/// workers. An operator command holds the volume permit beside a running
/// Kernel. Also answers the copy settings the workers need.
pub async fn state_from_env(
    startup: &Startup,
    installation: installation::Installation,
    mail_key: &str,
    own_origins: Vec<String>,
    audit: Option<runtime::AuditSink>,
) -> Result<(AppState, Option<copies::CopyConfig>)> {

    heap::limit_from_env()?;
    let data_root = startup.data_root.clone();
    let public_origin = startup.hosts.public_origin.clone();
    tokio::fs::create_dir_all(crate::layout::apps(&data_root)).await?;
    let account_settings = accounts::AccountSettings::from_env(&data_root, mail_key, &public_origin, &installation, startup.execution_mode)?;
    let (s3, data_bucket, copy_config) = if startup.execution_mode.is_test() {
        (None, String::new(), None)
    } else {
        let (s3, data_bucket) = match copy_bucket_from_env()? {
            Some((client, bucket)) => (Some(client), bucket),
            None => (None, String::new()),
        };
        let copy_config = copies::CopyConfig::from_env(&data_root, s3.is_some())?;
        (s3, data_bucket, copy_config)
    };
    let deployments = load_deployments(&data_root, &public_origin).await?;
    let files = if startup.execution_mode.is_test() {
        file_store::Files::new(Arc::new(file_store::LocalFolder::new(&data_root)), file_store::FileLimits::from_env()?)
    } else {
        file_store::Files::from_env(&data_root).await?
    };
    let copies = copies::CopyStatus::open(copy_config.as_ref(), &copies::status_directory(&data_root),
        &file_store::env_var("KONAE_S3_ENDPOINT").unwrap_or_default(), &data_bucket);
    let state = AppState {
        execution_mode: startup.execution_mode,
        deployments: Arc::new(RwLock::new(deployments)),
        db_locks: LockMap::default(),
        s3,
        data_bucket,
        data_root,
        files,
        copies: Arc::new(copies),
        public_origin,
        own_origins,
        host_suffix: startup.hosts.host_suffix.clone(),
        path_origin: startup.hosts.path_origin.clone(),
        guards: Arc::new(Guards::new(trusted_proxies(
            &std::env::var("KONAE_TRUSTED_PROXIES").unwrap_or_default(),
        )?)),
        accounts: account_settings,
        functions: Arc::new(functions_runtime::Runtime::from_env()?),
        audit,
        installation: Arc::new(installation),
    };
    Ok((state, copy_config))
}

/// Binds the Kernel's port. A port another process holds is refused with its
/// number and the variable that picks another; any other failure keeps the
/// system's text beside the address.
pub async fn bind(startup: &Startup) -> Result<tokio::net::TcpListener> {
    let (host, port) = (startup.bind.as_str(), startup.port);
    tokio::net::TcpListener::bind((host, port)).await.map_err(|error| {
        if error.kind() == std::io::ErrorKind::AddrInUse {
            anyhow::anyhow!("Port {port} on {host} is already in use. Another Konae or Kernel may hold it. Set KONAE_KERNEL_PORT to a free port, or pass --port to konae dev.")
        } else {
            anyhow::anyhow!("Could not listen on {host}:{port}: {error}")
        }
    })
}

#[cfg(test)]
mod bind_tests {
    use super::*;

    #[tokio::test]
    async fn a_taken_port_is_refused_with_its_number_and_how_to_pick_another() {
        let held = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = held.local_addr().unwrap().port();
        let startup = Startup { port, bind: "127.0.0.1".into(), hosts: hosts::resolve(|_| None).unwrap(), data_root: PathBuf::new(), execution_mode: execution::ExecutionMode::Live };
        let message = bind(&startup).await.unwrap_err().to_string();
        assert!(message.contains(&format!("Port {port} on 127.0.0.1 is already in use")), "{message}");
        assert!(message.contains("KONAE_KERNEL_PORT") && message.contains("--port"), "{message}");
    }

    #[tokio::test]
    async fn another_bind_failure_keeps_the_system_text_and_the_address() {
        let startup = Startup { port: 0, bind: "256.0.0.1".into(), hosts: hosts::resolve(|_| None).unwrap(), data_root: PathBuf::new(), execution_mode: execution::ExecutionMode::Live };
        let message = bind(&startup).await.unwrap_err().to_string();
        assert!(message.starts_with("Could not listen on 256.0.0.1:0: "), "{message}");
    }
}

/// Binds the port and serves the Kernel, with `extra` beside its routes.
pub async fn listen(startup: &Startup, state: AppState, extra: Router<AppState>, name: &str) -> Result<()> {
    let listener = bind(startup).await?;
    println!("{name} listening on {}", startup.port);
    serve(listener, state, extra).await?;
    Ok(())
}

/// Serves the Kernel, and `extra` beside its own routes, on a bound listener.
pub async fn serve(listener: tokio::net::TcpListener, state: AppState, extra: Router<AppState>) -> std::io::Result<()> {
    axum::serve(listener, ServiceExt::<Request>::into_make_service_with_connect_info::<std::net::SocketAddr>(stack(state, extra))).await
}

/// The Kernel's whole stack. The isolation headers and the path router wrap
/// the routes, so a path address is rewritten before routing and the headers
/// cover every response, the redirects included.
/// `extra` holds the routes of whoever starts the Kernel; they answer
/// before the Kernel's catch-all and inside the same layers.
pub fn stack(state: AppState, extra: Router<AppState>) -> tower::util::BoxCloneSyncService<Request, axum::response::Response, std::convert::Infallible> {
    let routes = Router::new()
        .route("/_konae/health", get(health))
        .route("/_konae/auth/signup", post(signup))
        .route("/_konae/auth/login", post(login))
        .route("/_konae/login", get(login_page))
        .route("/_konae/fonts/{name}", get(own_page::font))
        .merge(runtime::routes())
        .merge(extra)
        .merge(google::routes())
        .merge(accounts::routes())
        .merge(http::routes())
        .merge(invitations::routes())
        .merge(enter::routes())
        .merge(mail::routes())
        .route("/_konae/{*path}", axum::routing::any(|| async { error(StatusCode::GONE, "Use authenticated MCP for platform operations.") }))
        .route("/{*path}", get(http::get_route).post(http::post_route))
        .route("/", get(serve_root))
        .layer(axum::middleware::from_fn_with_state(state.clone(), logical_route))
        .layer(axum::middleware::from_fn_with_state(state.clone(), maintenance::guard))
        .with_state(state.clone());
    let service = ServiceBuilder::new()
        .layer(axum::middleware::from_fn_with_state(state.clone(), logical_request))
        .layer(axum::middleware::from_fn_with_state(state.clone(), security::headers))
        .layer(axum::middleware::from_fn_with_state(state.clone(), hostname::redirect))
        .layer(axum::middleware::from_fn_with_state(state, path::route))
        .service(routes);
    tower::util::BoxCloneSyncService::new(service)
}

#[derive(Clone)]
struct Operation(Arc<tokio::sync::OwnedRwLockReadGuard<()>>);

async fn logical_request(State(state): State<AppState>, mut request: Request, next: axum::middleware::Next) -> Response {
    let operation = Operation(Arc::new(state.copies.operations.clone().read_owned().await));
    request.extensions_mut().insert(operation);
    next.run(request).await
}

async fn logical_route(State(state): State<AppState>, request: Request, next: axum::middleware::Next) -> Response {
    let request = if request.extensions().get::<axum::extract::MatchedPath>().is_some_and(|path| path.as_str() == "/{*path}") {
        match functions_http::dispatch(&state, request).await {
            Ok(response) => return response,
            Err(request) => request,
        }
    } else {
        request
    };
    // The legacy handlers join their SQLite work before releasing the copy gate.
    let operation = request.extensions().get::<Operation>().map(|operation| operation.0.clone());
    let task = tokio::spawn(async move {
        let _operation = operation;
        next.run(request).await
    });
    task.await.unwrap_or_else(|_| StatusCode::INTERNAL_SERVER_ERROR.into_response())
}

pub async fn health(State(state): State<AppState>) -> impl IntoResponse {
    Json(json!({"ok": true, "kernel": "konae-rust", "version": 1,
        "copies": state.copies.health(),
        "files": {"store": state.files.store.kind(), "quotaBytes": state.files.limits.quota_bytes,
            "maxFileBytes": state.files.limits.max_file_bytes},
        "mail": state.accounts.queue.as_ref().map(|queue| queue.health())}))
}

/// The client and bucket of copies and the revocation record, or `None`
/// when no S3 endpoint is set.
pub fn copy_bucket_from_env() -> Result<Option<(S3Client, String)>> {
    Ok(file_store::S3Settings::copies(&file_store::env_var)?.map(|settings| (file_store::s3_client(&settings), settings.bucket)))
}

pub fn backup_dir(state: &AppState, id: &str) -> PathBuf {
    layout::backups(&state.data_root, id)
}

/// Installs a release from its JSON payload: the project, the build and
/// what a first release imports.
pub async fn deploy(state: &AppState, body: &[u8]) -> Response {
    if body.len() > size::RELEASE_BYTES {
        return error(StatusCode::BAD_REQUEST, &size::release_refused(body.len()));
    }
    let input: DeployInput = match serde_json::from_slice(body).map_err(anyhow::Error::from).and_then(functions::parse_deploy_input) {
        Ok(value) => value,
        Err(error_value) => {
            if let Some(refused) = refusal::of(&error_value) { return refusal_error(refused); }
            return error(
                StatusCode::BAD_REQUEST,
                &format!("Invalid deployment: {error_value}"),
            );
        }
    };
    deploy_input(state, input).await
}

/// Installs a release: the project, the build and what a first release
/// imports. `app/`, `dist/`, the database and the record change together, or
/// none of them does.
pub async fn deploy_input(state: &AppState, input: DeployInput) -> Response {
    deploy_input_in(state, input, false).await
}

/// The owner import door calls this after checking its project permission and package.
pub async fn deploy_import_held(state: &AppState, input: DeployInput) -> Response {
    deploy_input_in(state, input, true).await
}

async fn deploy_input_in(state: &AppState, input: DeployInput, restoring_import: bool) -> Response {
    let _generation = state.copies.generations.read().await;
    let _release_guard = if restoring_import { None } else { Some(named_lock(state, &format!("publish:{}", input.project.id), true).await) };
    let validation = if restoring_import { runtime::validate_import_release(state, &input, None).await }
        else { runtime::validate_release(state, &input, None).await };
    if let Err(error_value) = validation {
        return match refusal::of(&error_value) {
            Some(refused) => refusal_error(refused),
            None => error(StatusCode::BAD_REQUEST, &error_value.to_string()),
        };
    }
    if input.artifact.version != 1
        || input.artifact.entrypoint != "index.html"
        || !input.artifact.files.contains_key("index.html")
    {
        return error(StatusCode::BAD_REQUEST, "Invalid Build Artifact.");
    }
    if input.visibility != "public" && input.visibility != "private" {
        return error(
            StatusCode::BAD_REQUEST,
            "Visibility must be public or private.",
        );
    }
    let server = match functions::validate_artifact(input.server_artifact.as_ref().map(|a| &a.manifest), input.server_artifact.as_ref()) {
        Ok(server) => server,
        Err(refused) => return refusal_error(&refused),
    };
    let release_sources = match input.project.sources() {
        Ok(files) => files,
        Err(message) => return error(StatusCode::BAD_REQUEST, &message),
    };
    let draft = input.project.clone();
    let draft_visibility = input.visibility.clone();
    let imported_snapshot = input.initial_released.clone();
    let input = match input.restored() {
        Ok(input) => input,
        Err(e) => return error(StatusCode::BAD_REQUEST, &e.to_string()),
    };
    let actions = input.project.files.get("actions.json").cloned().unwrap_or_else(|| r#"{"version":1,"actions":{}}"#.to_owned());
    let program = match action_shape::read(&actions) {
        Ok(program) => program,
        Err(error_value) => match refusal::of(&error_value) {
            Some(refused) => return refusal_error(refused),
            None => return error(StatusCode::BAD_REQUEST, &error_value.to_string()),
        },
    };
    for (name, action) in &program.actions {
        let Some(file) = action.page.as_ref().and_then(|page| page.get("file")).and_then(Value::as_str) else { continue };
        if !input.artifact.files.contains_key(file) {
            return refusal_error(&refusal::refuse("page.file-missing", format!("Action {name} names {file} as its page file, but the Build Artifact does not contain it.")));
        }
    }
    if !runtime::valid_app_id(&input.project.id) {
        return error(StatusCode::BAD_REQUEST, "Invalid project ID.");
    }
    if let Err(error_value) = http::read_secrets(&state.data_root, &input.project.id).and_then(|db| {
        calls::check_release(&domain::Rules::of(&state), &db, &program)
    }) {
        return match refusal::of(&error_value) {
            Some(refused) => refusal_error(refused),
            None => error(StatusCode::BAD_REQUEST, &error_value.to_string()),
        };
    }
    if !input.artifact.files.keys().all(|path| safe_relative_path(path)) {
        return error(
            StatusCode::BAD_REQUEST,
            "Artifact contains an invalid path.",
        );
    }
    if let Err(message) = artifact::check_routing(&input.project.manifest) {
        return error(StatusCode::BAD_REQUEST, &message);
    }
    if let Err(refused) = calls::check_connects(&input.project.manifest) {
        return refusal_error(&refused);
    }
    let artifact_files = match artifact::decode(&input.artifact) {
        Ok(files) => files,
        Err(message) => return error(StatusCode::BAD_REQUEST, &message),
    };
    let deployments = state.deployments.read().await;
    let existing = find_project_deployment(&deployments, &input.project.id);
    drop(deployments);
    if existing.is_some()
        && (input.initial_signup_policy.is_some()
            || input.initial_sign_in_methods.is_some()
            || input.initial_modules.is_some()
            || input.initial_package.is_some())
    {
        return error(
            StatusCode::CONFLICT,
            "Portable state can only be imported on the first deployment.",
        );
    }
    let package_policy = input.initial_package.as_ref().and_then(|package| package.manifest.signup_policy.as_ref());
    let initial_signup_policy = match input.initial_signup_policy.as_ref().or(package_policy) {
        Some(policy) => match SignupPolicy::from_input(policy.mode, &policy.allowlist) {
            Ok(policy) => Some(policy),
            Err(message) => return error(StatusCode::BAD_REQUEST, &message),
        },
        None => None,
    };



    let package_methods = input.initial_package.as_ref().and_then(|package| package.manifest.sign_in_methods.as_ref());
    let initial_sign_in_methods = match input.initial_sign_in_methods.as_ref().or(package_methods) {
        Some(methods) => match sign_in_methods_from_input(methods) {
            Ok(methods) => Some(methods),
            Err(message) => return error(StatusCode::BAD_REQUEST, &message),
        },
        None => None,
    };

    let id = input.project.id.clone();
    let release_directories = input.project.directories.clone();


    let (hostname, _taking) = match existing.as_ref() {
        Some(item) => (item.hostname.clone(), None),
        None => {
            let (hostname, taking) = folder::free_hostname(state, &input.project.slug, &input.project.id).await;
            (hostname, Some(taking))
        }
    };
    let url = existing
        .as_ref()
        .map(|item| item.url.clone())
        .unwrap_or_else(|| deployment_url(&state.public_origin, &hostname));
    let released_schema = input.project.files.get("schema.sql").cloned().unwrap_or_default();
    let released_transforms = input.project.files.get("schema-transforms.json").cloned();
    let mut manifest = input.project.manifest;
    let legacy_file_access = manifest["fileAccess"] == "app-users";
    manifest["visibility"] = Value::String(input.visibility.clone());
    let artifact_version = format!("v{}", Uuid::new_v4().simple());
    let deployment = Deployment {
        id: id.clone(),
        project_id: input.project.id,
        project_name: input.project.name,
        slug: input.project.slug.clone(),
        url,
        created_at: existing
            .as_ref()
            .map(|item| item.created_at)
            .unwrap_or_else(now_ms),
        released_at: now_ms(),
        source_digest: imported_snapshot.as_ref().and_then(|s| s.source_digest.clone()).or_else(|| Some(sources::digest(release_sources.iter().map(|(path, bytes)| (path.as_str(), bytes.as_slice()))))),
        manifest,
        hostname: hostname.clone(),
        actions,
        artifact_version: artifact_version.clone(),
        signup_policy: match existing.as_ref() {
            Some(item) => item.signup_policy.for_republish(is_private(item), &input.visibility),
            None => initial_signup_policy.unwrap_or_else(|| SignupPolicy::initial(&input.visibility)),
        },
        sign_in_methods: match existing.as_ref() {
            Some(item) => item.sign_in_methods.clone(),
            None => initial_sign_in_methods.unwrap_or_else(default_sign_in_methods),
        },
        modules: {
            let uses_files = modules::artifact_uses_files(artifact_files.values().map(Vec::as_slice))
                || modules::sources_use_files(input.project.files.values().map(String::as_bytes))
                || legacy_file_access;
            let uses_auth = modules::sources_use_auth(input.project.files.values().map(String::as_bytes))
                || modules::artifact_uses_auth(artifact_files.values().map(Vec::as_slice));
            let action_files = input.project.files.iter().map(|(name, text)| (name.as_str(), text.as_bytes())).collect::<Vec<_>>();
            let uses_actions = modules::named_sources_use_actions(action_files.iter().copied());
            let uses_http = modules::sources_use_http(action_files.iter().copied());
            let uses_calls = modules::sources_use_calls(action_files.iter().copied());
            let package_modules = input.initial_package.as_ref().map(|package| &package.manifest.modules);
            let initial_modules = input.initial_modules.as_ref().or(package_modules);
            let mut modules = existing.as_ref().map(|item| item.modules.clone()).unwrap_or_else(|| modules::initial_for_release(initial_modules, uses_files, uses_auth || input.visibility != "public", uses_http, uses_calls));
            if legacy_file_access {
                let files = modules.get_mut("files").expect("files is switchable");
                files["on"] = json!(true);
                files["fileAccess"] = json!("app-users");
            }
            if existing.is_none() && initial_modules.is_none_or(|state| !state.contains_key("actions")) && uses_actions {
                modules.get_mut("actions").expect("actions is switchable")["on"] = json!(true);
            }
            if existing.is_none() && initial_modules.is_none_or(|state| !state.contains_key("http")) && uses_http { modules.get_mut("http").expect("http is switchable")["on"] = json!(true); }
            if existing.is_none() && initial_modules.is_none_or(|state| !state.contains_key("calls")) && uses_calls { modules.get_mut("calls").expect("calls is switchable")["on"] = json!(true); }
            modules::complete(&mut modules);
            modules
        },
        contact_email: input.contact_email.clone(),
        released_schema,
        server,
    };
    let data = layout::data(&state.data_root, &id);
    if let Err(error_value) = tokio::fs::create_dir_all(&data).await {
        return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string());
    }


    if let Err(error_value) = stage_local_artifact(&state, &id, &artifact_version, &artifact_files)
        .await
        .and_then(|()| release_step(&id, "stage_local_artifact"))
    {
        remove_staged_dist(&state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string());
    }
    if let Err(e) = functions::stage(&staged_server(state, &id, &artifact_version), input.server_artifact.as_ref()).await.and_then(|()| release_step(&id, "stage_server")) {
        remove_staged_dist(state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string());
    }
    let subject = format!("{id} revision {artifact_version}");
    let journal_release = || copies::Pending::begin(&state.data_root, &subject, "installing the database, sources and release record");
    let initializes_stores = input.initial_package.is_some()
        || (modules::is_on(&deployment.modules, "actions") && !layout::database(&state.data_root, &id).exists())
        || (modules::is_on(&deployment.modules, "auth") && !layout::identity(&state.data_root, &id).exists());
    let preparing = if initializes_stores {
        match journal_release() {
            Ok(pending) => Some(pending),
            Err(e) => return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        }
    } else { None };
    let mut notices = Vec::new();
    if let Some(package) = input.initial_package.as_ref() {
        if let Err(error_value) = package::install(&state, package, &id)
            .await
        {
            remove_staged_dist(&state, &id, &artifact_version).await;
            let _ = tokio::fs::remove_dir_all(&data).await;
            file_store::forget_deployment(state.files.store.as_ref(), &id).await;
            return error(StatusCode::BAD_REQUEST, &format!("Package import failed: {error_value:#}"));
        }

        match path::arrive(&state, &deployment, package.manifest.path.as_ref()).await {
            Ok(lines) => notices = lines,
            Err(error_value) => {
                remove_staged_dist(&state, &id, &artifact_version).await;
                let _ = tokio::fs::remove_dir_all(&data).await;
                return error(StatusCode::BAD_REQUEST, &format!("Package import failed: {error_value:#}"));
            }
        }
    }
    let db_path = layout::database(&state.data_root, &id);
    let schema = input
        .project
        .files
        .get("schema.sql")
        .cloned()
        .unwrap_or_default();
    let actions_enabled = modules::is_on(&deployment.modules, "actions");
    if actions_enabled && !db_path.exists() {
        if let Err(error_value) = initialize_database(&db_path) {
            remove_staged_dist(&state, &id, &artifact_version).await;
            return error(
                StatusCode::BAD_REQUEST,
                &format!("Database initialization failed: {error_value}"),
            );
        }
    }
    let identity_path = layout::identity(&state.data_root, &id);
    let identity = if !modules::is_on(&deployment.modules, "auth") || identity_path.exists() {
        Ok(())
    } else {
        open_auth(&state, &deployment).map(drop).map_err(|error_value| anyhow::anyhow!(error_value.to_string()))
    };
    if let Err(error_value) = identity.and_then(|()| if modules::is_on(&deployment.modules, "auth") { release_step(&id, "open_auth") } else { Ok(()) }) {
        remove_staged_dist(&state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string());
    }


    let database_guard = database_lock(&state, &id).await;
    let staged_database = layout::private(&state.data_root, &id).join(format!("release-{artifact_version}.sqlite"));
    let staged = if actions_enabled { stage_database(&db_path, &staged_database, &schema, &program, input.project.files.get("schema-transforms.json").map(String::as_str), input.schema_confirmation.as_deref()) } else { Ok(schema_change::Change::default()) }
        .and_then(|change| release_step(&id, "schema_change").map(|()| change));
    let change = match staged {
        Ok(change) => change,
        Err(error_value) => {
            remove_database_files(&staged_database);
            remove_staged_dist(&state, &id, &artifact_version).await;
            return match refusal::of(&error_value) {
                Some(refused) => refusal_error(refused),
                None => error(StatusCode::BAD_REQUEST, &format!("Schema update failed: {error_value}")),
            };
        }
    };

    let source_metadata = json!({
        "name": deployment.project_name, "slug": deployment.slug, "manifest": deployment.manifest,
        "directories": input.project.directories, "updatedAt": now_ms(),
    });
    let staged_sources = match sources::stage_release(&state.data_root, &id, &release_sources, &source_metadata).await {
        Ok(staged) => staged,
        Err(error_value) => {
            remove_database_files(&staged_database);
            remove_staged_dist(&state, &id, &artifact_version).await;
            return error(StatusCode::INTERNAL_SERVER_ERROR, &format!("The sources of this release could not be written beside app/: {error_value:#}"));
        }
    };
    if let Err(error_value) = release_step(&id, "stage_sources") {
        staged_sources.discard().await;
        remove_database_files(&staged_database);
        remove_staged_dist(&state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string());
    }


    let recorded = Recorded::read(&state.data_root, &id).await;
    let replaced = layout::private(&state.data_root, &id).join(format!("release-{artifact_version}-replaced.sqlite"));
    let has_transformation_changes = change.transformations.as_ref().is_some_and(|items| !items.is_empty());
    let pending = match preparing {
        Some(pending) => pending,
        None => match journal_release() {
            Ok(pending) => pending,
            Err(e) => return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        }
    };
    let swapped = if !actions_enabled || change.statements.is_empty() && !has_transformation_changes {
        remove_database_files(&staged_database);
        false
    } else if let Err(error_value) = swap_database(&db_path, &staged_database, &replaced) {
        staged_sources.discard().await;
        remove_database_files(&staged_database);
        remove_staged_dist(&state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &format!("The changed database could not take the place of the live one: {error_value}"));
    } else {
        true
    };
    let undo_database = || {
        if swapped {
            if let Err(error_value) = restore_database(&db_path, &replaced) {
                eprintln!("Could not put back the database of {id} after a failed release: {error_value}");
            }
        }
    };
    if let Err(error_value) = async {
        persist_release(&state, &deployment, &folder::version_of(&artifact_files), &release_directories, released_transforms.as_deref(), Some(&deployment.modules)).await?;
        if imported_snapshot.is_some() {
            let mut settings = Settings::read(&state.data_root, &id)?;
            settings.name = draft.name.clone(); settings.slug = draft.slug.clone();
            settings.manifest = sources::manifest_without_runtime(&draft.manifest);
            settings.visibility = draft_visibility.clone();
            settings.write(&state.data_root).await?;
        }
        release_step(&id, "persist_deployment")
    }.await
    {
        recorded.put_back().await;
        undo_database();
        staged_sources.discard().await;
        remove_staged_dist(&state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string());
    }


    let swapped_sources = match staged_sources.swap().await {
        Err(error_value) => Err((error_value, false)),
        Ok(()) => release_step(&id, "swap_sources").map_err(|error_value| (error_value, true)),
    };
    if let Err((error_value, swapped_app)) = swapped_sources {
        if swapped_app { staged_sources.put_back().await; } else { staged_sources.discard().await; }
        recorded.put_back().await;
        undo_database();
        remove_staged_dist(&state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &format!("The new sources could not take the place of app/: {error_value:#}"));
    }
    if let Err(error_value) = switch_dist(&state, &id, &artifact_version).await {
        staged_sources.put_back().await;
        recorded.put_back().await;
        undo_database();
        remove_staged_dist(&state, &id, &artifact_version).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &format!("The new files could not take the place of dist/: {error_value}"));
    }
    state
        .deployments
        .write()
        .await
        .insert(hostname, deployment.clone());
    drop(database_guard);
    if swapped {
        remove_database_files(&replaced);
    }
    staged_sources.finish().await;
    if let Err(e) = pending.finish() { return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()); }
    http::routes_published(&deployment);
    state.functions.release_changed(&id, &deployment.artifact_version).await;
    remove_stale_dist(&state, &id).await;
    let mut result = match serde_json::to_value(&deployment) {
        Ok(value) => value,
        Err(error_value) => return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string()),
    };
    if !notices.is_empty() {
        result["notices"] = json!(notices);
    }
    Json(json!({"result": result})).into_response()
}

pub async fn stage_local_artifact(
    state: &AppState,
    id: &str,
    version: &str,
    files: &HashMap<String, Vec<u8>>,
) -> Result<()> {
    let root = staged_dist(state, id, version);
    for (path, contents) in files {
        let local_path = root.join(path);
        if let Some(parent) = local_path.parent() {
            tokio::fs::create_dir_all(parent).await?;
        }
        tokio::fs::write(&local_path, contents).await?;
    }
    Ok(())
}

/// Where a release's files wait until they become `dist/`.
pub fn staged_dist(state: &AppState, id: &str, version: &str) -> PathBuf {
    layout::private(&state.data_root, id).join(format!("dist-{version}"))
}

/// Moves the staged files into `dist/` and the previous ones aside, for
/// `remove_stale_dist` to delete. When the second move fails, the
/// previous files go back to `dist/`.
pub fn staged_server(state: &AppState, id: &str, version: &str) -> PathBuf {
    layout::private(&state.data_root, id).join(format!("server-{version}"))
}

pub async fn switch_dist(state: &AppState, id: &str, version: &str) -> std::io::Result<()> {
    let mut changed: Vec<(PathBuf, PathBuf, bool)> = Vec::new();
    for (live, staged, label, step) in [
        (layout::dist(&state.data_root, id), staged_dist(state, id, version), "dist", "switch_dist"),
        (layout::server(&state.data_root, id), staged_server(state, id, version), "server", "switch_server"),
    ] {
        // Local static-only callers do not stage a server directory.
        if label == "server" && !staged.exists() { continue; }
        let retired = layout::private(&state.data_root, id).join(format!("{label}-retired-{}", Uuid::new_v4().simple()));
        let moved = async {
            let had_live = tokio::fs::try_exists(&live).await?;
            if had_live { tokio::fs::rename(&live, &retired).await?; }
            changed.push((live.clone(), retired.clone(), had_live));
            release_step(id, step).map_err(|e| std::io::Error::other(e.to_string()))?;
            tokio::fs::rename(&staged, &live).await
        }.await;
        if let Err(error) = moved {
            for (live, retired, existed) in changed.into_iter().rev() {
                let _ = tokio::fs::remove_dir_all(&live).await;
                if existed { tokio::fs::rename(retired, live).await?; }
            }
            return Err(error);
        }
    }
    Ok(())
}



fn stage_database(live: &Path, staged: &Path, schema: &str, program: &ActionProgram, transforms: Option<&str>, confirmation: Option<&str>) -> Result<schema_change::Change> {
    remove_database_files(staged);
    copies::vacuum_into(live, staged)?;
    let change = schema_change::apply_with_transforms(staged, schema, program, transforms, schema_change::Mode::Apply(confirmation))?;


    Connection::open(staged)?.query_row("PRAGMA journal_mode=WAL", [], |_| Ok(()))?;
    Ok(change)
}

fn database_sidecar(path: &Path, suffix: &str) -> PathBuf {
    let mut name = path.as_os_str().to_owned();
    name.push(suffix);
    PathBuf::from(name)
}

fn remove_database_files(path: &Path) {
    for file in [path.to_path_buf(), database_sidecar(path, "-wal"), database_sidecar(path, "-shm")] {
        let _ = std::fs::remove_file(file);
    }
}



fn swap_database(live: &Path, staged: &Path, replaced: &Path) -> std::io::Result<()> {
    swap_database_with(live, staged, replaced, || {})
}

fn swap_database_with(live: &Path, staged: &Path, replaced: &Path, between_renames: impl FnOnce()) -> std::io::Result<()> {
    std::fs::rename(live, replaced)?;
    for suffix in ["-wal", "-shm"] {
        let from = database_sidecar(live, suffix);
        if from.exists() {
            if let Err(error_value) = std::fs::rename(&from, database_sidecar(replaced, suffix)) {
                let _ = restore_database(live, replaced);
                return Err(error_value);
            }
        }
    }
    between_renames();
    if let Err(error_value) = std::fs::rename(staged, live) {
        let _ = restore_database(live, replaced);
        return Err(error_value);
    }
    Ok(())
}


fn restore_database(live: &Path, replaced: &Path) -> std::io::Result<()> {
    for suffix in ["-wal", "-shm"] {
        let from = database_sidecar(replaced, suffix);
        if from.exists() {
            std::fs::rename(&from, database_sidecar(live, suffix))?;
        } else {
            let _ = std::fs::remove_file(database_sidecar(live, suffix));
        }
    }
    std::fs::rename(replaced, live)
}



struct Recorded(Vec<(PathBuf, Option<Vec<u8>>)>);

impl Recorded {
    async fn read(root: &Path, id: &str) -> Self {
        let mut files = Vec::new();
        for path in [layout::settings(root, id), layout::record(root, id)] {
            let bytes = tokio::fs::read(&path).await.ok();
            files.push((path, bytes));
        }
        Self(files)
    }

    async fn put_back(&self) {
        for (path, bytes) in &self.0 {
            let restored = match bytes {
                Some(bytes) => write_atomic(path, bytes).await,
                None => tokio::fs::remove_file(path).await,
            };
            if let Err(error_value) = restored {
                eprintln!("Could not put back {} after a failed release: {error_value}", path.display());
            }
        }
    }
}


#[cfg(test)]
static FAILING_RELEASE_STEPS: std::sync::Mutex<Vec<(String, &'static str)>> = std::sync::Mutex::new(Vec::new());

/// Fails a release at `step` when a test asked for it.
#[cfg(test)]
fn release_step(id: &str, step: &'static str) -> Result<()> {
    if FAILING_RELEASE_STEPS.lock().unwrap().iter().any(|(app, failing)| app == id && *failing == step) {
        anyhow::bail!("The test failed this release at {step}.");
    }
    Ok(())
}

#[cfg(not(test))]
fn release_step(_id: &str, _step: &'static str) -> Result<()> {
    Ok(())
}

/// Best-effort removal of a release that never went live.
pub async fn remove_staged_dist(state: &AppState, id: &str, version: &str) {
    let _ = tokio::fs::remove_dir_all(staged_dist(state, id, version)).await;
    let _ = tokio::fs::remove_dir_all(staged_server(state, id, version)).await;
}

/// Deletes the retired or staged release folders beside `dist/`. Failures
/// are logged because the new release is already live.
pub async fn remove_stale_dist(state: &AppState, id: &str) {
    if let Ok(mut entries) = tokio::fs::read_dir(layout::private(&state.data_root, id)).await {
        while let Ok(Some(entry)) = entries.next_entry().await {
            if !entry.file_name().to_str().is_some_and(|name| name.starts_with("dist-") || name.starts_with("server-")) {
                continue;
            }
            let removed = match entry.file_type().await {
                Ok(kind) if kind.is_dir() => tokio::fs::remove_dir_all(entry.path()).await,
                _ => tokio::fs::remove_file(entry.path()).await,
            };
            if let Err(error_value) = removed {
                eprintln!("Could not remove stale artifact {}: {error_value}", entry.path().display());
            }
        }
    }
}

pub fn find_project_deployment(
    deployments: &HashMap<String, Deployment>,
    project_id: &str,
) -> Option<Deployment> {
    deployments
        .values()
        .find(|deployment| deployment.project_id == project_id)
        .cloned()
}

pub async fn invoke_action(
    State(state): State<AppState>,
    AxumPath(name): AxumPath<String>,
    headers: HeaderMap,
    Json(input): Json<Value>,
) -> Response {
    let deployment = match deployment_for(&state, &headers).await {
        Some(value) => value,
        None => return error(StatusCode::NOT_FOUND, "Deployment not found."),
    };
    if let Err(refused) = modules::require_on(&deployment.modules, "actions") {
        return refusal_error(&refused);
    }
    let program: ActionProgram = match serde_json::from_str(&deployment.actions) {
        Ok(value) => value,
        Err(_) => {
            return error(
                StatusCode::INTERNAL_SERVER_ERROR,
                "Stored action program is invalid.",
            );
        }
    };
    let action = match program.actions.get(&name) {
        Some(value) => value,
        None => return error(StatusCode::NOT_FOUND, "Server action not declared."),
    };
    // An action whose route does not answer anyone answers only there.
    if let Some(route) = http::route_only(&name, action, is_private(&deployment)) {
        return error(StatusCode::FORBIDDEN, &format!("Action {name} answers only on its HTTP route, {route}."));
    }
    // A call's then mutation records what the call's answer said, so no one
    // else may write it.
    if let Some(call) = calls::then_of(&program, &name) {
        return error(StatusCode::FORBIDDEN, &format!("Action {name} runs only after the call {call} answers."));
    }
    // A scheduled mutation with no route belongs to the Kernel's timer

    if action.schedule.is_some() && action.http.is_none() {
        return error(StatusCode::FORBIDDEN, &format!("Action {name} runs only on its schedule."));
    }
    let actor = match authenticate_deployment(&state, &deployment, &headers).await {
        Ok(actor) => actor,
        Err(response) => return response,
    };
    if action.access == "granted" {
        return error(StatusCode::FORBIDDEN, "action-grant-required");
    }

    if (action.access != "anonymous" || is_private(&deployment)) && actor.is_none() {
        return error(StatusCode::UNAUTHORIZED, "authentication-required");
    }
    let params = match resolve_bindings(
        action,
        &input,
        actor.as_ref().map(|user| user.user_id.as_str()),
    ) {
        Ok(value) => value,
        Err(message) => return error(StatusCode::BAD_REQUEST, &message),
    };

    if action.kind == "call" {
        let response = calls::enqueue(&state, &deployment, &name, &input).await;
        if response.status().is_success() && !enter::entered(actor.as_ref()) {
            if let Some(user) = actor.as_ref() {
                usage::count_account(&state.data_root, &deployment.id, &user.user_id, usage::AccountKind::Action);
            }
        }
        return response;
    }
    let db_path = crate::layout::database(&state
        .data_root, &deployment.id);


    copies::operation::action(&state, &deployment.id, &name, action, async {
        let result = if action.kind == "signal" {
            Ok(Ran { answer: json!({"recorded": true}), rows: Vec::new() })
        } else {
            let _guard = action_lock(&state, &deployment.id, &action.kind).await;
            match state.guards.statement_permit(&deployment.id).await {
                Ok(permit) => run_action_in_slot(db_path, action, params, permit).await,
                Err(wait) => return http::rate_limited(wait),
            }
        };
        let actor_id = actor.as_ref().map(|user| user.user_id.as_str());

        let counted = !enter::entered(actor.as_ref());
        match result {
            Ok(ran) => match guard::outcome(&name, action, &ran.answer) {
                guard::Outcome::Refused(message) => {
                    if counted {
                        usage::execution(&state.data_root, &deployment.id, &name, "runtime", "refused");
                        usage::count(&state.data_root, &deployment.id, usage::Operation::Refused(name.clone()));
                    }
                    error(StatusCode::FORBIDDEN, &message)
                }
                changed => {
                    if counted {
                        usage::execution(&state.data_root, &deployment.id, &name, "runtime", "ok");
                        usage::count(&state.data_root, &deployment.id, usage::Operation::Action(name.clone()));
                        if let Some(account) = actor_id {
                            usage::count_account(&state.data_root, &deployment.id, account, usage::AccountKind::Action);
                        }
                    }
                    if matches!(changed, guard::Outcome::Changed) {
                        if counted {
                            usage::signal(&state.data_root, &deployment.id, &name, action, &input, actor_id);
                        }
                        let caller = notify::Caller { account: actor_id, actor_id };
                        notify::record(&state, &deployment, &name, action, &input, caller, ran.changed(now_ms())).await;
                    }
                    Json(json!({"result": ran.answer})).into_response()
                }
            },
            Err(error_value) => {
                if counted {
                    usage::execution(&state.data_root, &deployment.id, &name, "runtime", "failed");
                }
                error(StatusCode::BAD_REQUEST, &error_value.to_string())
            },
        }
    }).await
}

pub async fn session(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    if !modules::is_on(&deployment.modules, "auth") {
        return error(StatusCode::NOT_FOUND, "Authentication is not enabled for this app.");
    }
    match authenticate_deployment(&state, &deployment, &headers).await {
        Ok(Some(user)) => Json(json!({"result": user})).into_response(),
        Ok(None) => Json(
            json!({"result": {"userId": "anonymous", "name": "Anonymous", "role": "anonymous"}}),
        )
        .into_response(),
        Err(response) => response,
    }
}

#[derive(Deserialize)]
pub struct AuthInput {
    pub email: String,


    #[serde(default)]
    pub password: String,
}

pub async fn signup(State(state): State<AppState>, headers: HeaderMap, request: Request) -> Response {
    auth_request(&state, &headers, request, true).await
}

pub async fn login(State(state): State<AppState>, headers: HeaderMap, request: Request) -> Response {
    auth_request(&state, &headers, request, false).await
}

pub async fn auth_request(
    state: &AppState,
    headers: &HeaderMap,
    request: Request,
    signup: bool,
) -> Response {
    if !same_origin(headers) {
        return error(StatusCode::FORBIDDEN, "Cross-origin auth request rejected.");
    }
    let Some(deployment) = deployment_for(state, headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    if !modules::is_on(&deployment.modules, "auth") {
        return error(StatusCode::NOT_FOUND, "Authentication is not enabled for this app.");
    }
    let peer = request
        .extensions()
        .get::<axum::extract::ConnectInfo<std::net::SocketAddr>>()
        .map(|info| info.0);
    let bytes = match axum::body::to_bytes(request.into_body(), 4096).await {
        Ok(bytes) => bytes,
        Err(_) => {
            return error(
                StatusCode::BAD_REQUEST,
                "Authentication request is too large.",
            );
        }
    };
    let input: AuthInput = match serde_json::from_slice(&bytes) {
        Ok(value) => value,
        Err(_) => {
            return error(
                StatusCode::BAD_REQUEST,
                "Authentication request must include email and password.",
            );
        }
    };
    let client = state.guards.client_ip(peer, headers);
    if let Err(wait) = state.guards.auth_attempt(&deployment.id, client, &input.email) {
        return too_many_attempts(wait);
    }
    if signup && state.accounts.verification == auth::Verification::Required {
        return match accounts::signup_app(state, &deployment, &input.email, client).await {
            Ok(()) => {
                let mut response = accounts::link_sent();
                if let Some(cookie) = accounts::signup_hint_cookie(state, &deployment, &input.email) {
                    response.headers_mut().insert(header::SET_COOKIE, cookie);
                }
                response
            }
            Err(error_value) => auth_error(error_value),
        };
    }
    if signup {


        if let Err(error_value) = auth::normalize_email(&input.email)
            .and_then(|_| auth::validate_password(&input.password))
        {
            return auth_error(error_value);
        }
        if !deployment.signup_policy.allows(&input.email) {
            return error(StatusCode::FORBIDDEN, SIGNUP_REFUSED);
        }
    }



    let identity = format!("identity:{}", deployment.id);
    let (email, password) = (input.email, input.password);
    let failed_email = email.clone();
    let result = if signup {
        let requested = email.clone();
        match blocking(move || auth::NewAccount::prepare(&email, &password)).await {
            Ok(account) => {
                let _identity_guard = database_lock(state, &identity).await;


                let allowed = state
                    .deployments
                    .read()
                    .await
                    .values()
                    .find(|current| current.id == deployment.id)
                    .map(|current| current.signup_policy.allows(&requested));
                match allowed {
                    None => return error(StatusCode::NOT_FOUND, "Deployment not found."),
                    Some(false) => return error(StatusCode::FORBIDDEN, SIGNUP_REFUSED),
                    Some(true) => {}
                }
                let auth = accounts::app_store(state, &deployment);
                blocking(move || auth?.create_account(account)).await
            }
            Err(error_value) => Err(error_value),
        }
    } else {
        let lookup = {
            let _identity_guard = database_lock(state, &identity).await;
            let (auth, email, password) = (accounts::app_store(state, &deployment), email.clone(), password.clone());
            blocking(move || auth?.find_login(&email, &password)).await
        };
        match lookup {
            Ok(stored) => match blocking(move || auth::check_password(&password, stored)).await {
                Ok(user) => {
                    let _identity_guard = database_lock(state, &identity).await;
                    let auth = accounts::app_store(state, &deployment);
                    blocking(move || auth?.start_session(user)).await
                }
                Err(error_value) => Err(error_value),
            },
            Err(error_value) => Err(error_value),
        }
    };
    if !signup && matches!(result, Err(AuthError::InvalidCredentials)) {
        state.guards.auth_failed(&deployment.id, client, &failed_email);
        if accounts::signup_hint_applies(state, &deployment, headers, &failed_email) {
            return error(StatusCode::UNAUTHORIZED, accounts::signup_hint(state));
        }
    }
    match result {
        Ok(session) => {
            let operation = if signup { usage::Operation::Signup } else { usage::Operation::Login };
            usage::count(&state.data_root, &deployment.id, operation);
            let cookie_name = app_cookie_name(state, &deployment.id, headers);
            accounts::app_session_response(&cookie_name, session)
        }


        Err(AuthError::AccountPending) => {
            let invited = accounts::invitation_pending(state, &deployment, &failed_email).await;
            error(StatusCode::FORBIDDEN, &accounts::pending_message(state, invited))
        }
        Err(error_value) => auth_error(error_value),
    }
}

/// Runs blocking authentication work off the async runtime.
pub async fn blocking<T: Send + 'static>(
    work: impl FnOnce() -> Result<T, AuthError> + Send + 'static,
) -> Result<T, AuthError> {
    tokio::task::spawn_blocking(work)
        .await
        .unwrap_or(Err(AuthError::PasswordHash))
}

/// The answer when a login or signup exceeds its rate limit.
pub fn too_many_attempts(wait: std::time::Duration) -> Response {
    let mut response = error(
        StatusCode::TOO_MANY_REQUESTS,
        "Too many sign-in attempts. Try again later.",
    );
    response
        .headers_mut()
        .insert(header::RETRY_AFTER, HeaderValue::from(wait.as_secs().max(1)));
    response
}

pub async fn logout(State(state): State<AppState>, headers: HeaderMap) -> Response {
    if !same_origin(&headers) {
        return error(StatusCode::FORBIDDEN, "Cross-origin auth request rejected.");
    }
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    let token = headers.get(header::AUTHORIZATION).and_then(|v|v.to_str().ok()).and_then(|v|v.strip_prefix("Bearer ")).map(str::to_owned)
        .or_else(|| cookie_value(&headers, &app_cookie_name(&state, &deployment.id, &headers)));
    let _identity_guard = database_lock(&state, &format!("identity:{}", deployment.id)).await;
    let auth = match open_auth(&state, &deployment) {
        Ok(auth) => auth,
        Err(error_value) => {
            return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string());
        }
    };
    if let Err(error_value) = auth.logout(token.as_deref()) {
        return error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string());
    }
    let mut response = Json(json!({"result": {"ok": true}})).into_response();
    response
        .headers_mut()
        .insert(header::SET_COOKIE, cleared_app_cookie(&state, &deployment.id, &headers));
    response
}

/// The `Set-Cookie` value that removes the app session cookie from the browser.
pub fn cleared_app_cookie(state: &AppState, deployment_id: &str, headers: &HeaderMap) -> HeaderValue {
    let name = app_cookie_name(state, deployment_id, headers);
    HeaderValue::from_str(&format!("{name}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0{}", cookie_secure(&name)))
        .unwrap()
}

/// `; Secure` for a name with a prefix that requires it.
pub fn cookie_secure(name: &str) -> &'static str {
    if name.starts_with("__Host-") || name.starts_with("__Secure-") { "; Secure" } else { "" }
}

pub async fn list_files(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    if let Err(refused) = modules::require_on(&deployment.modules, "files") { return refusal_error(&refused); }
    let actor = match authenticate_deployment(&state, &deployment, &headers).await {
        Ok(actor) => actor,
        Err(response) => return response,
    };
    if is_private(&deployment) && actor.is_none() {
        return error(StatusCode::UNAUTHORIZED, "authentication-required");
    }
    let actor_id = actor.as_ref().map(|user| user.user_id.as_str());
    let path = crate::layout::files(&state
        .data_root, &deployment.id)
        .join("index.json");
    match tokio::fs::read(path).await {
        Ok(bytes) => match serde_json::from_slice::<Value>(&bytes) {
            Ok(Value::Array(files)) => {
                let visible = files
                    .iter()
                    .filter(|file| file_readable(&deployment, file, actor_id))
                    .map(|file| file_view(&deployment, file, actor_id))
                    .collect::<Vec<_>>();
                Json(json!({"result": visible})).into_response()
            }
            Ok(_) | Err(_) => error(StatusCode::INTERNAL_SERVER_ERROR, "File index is invalid."),
        },
        Err(error_value) if error_value.kind() == std::io::ErrorKind::NotFound => {
            Json(json!({"result": []})).into_response()
        }
        Err(error_value) => error(StatusCode::INTERNAL_SERVER_ERROR, &error_value.to_string()),
    }
}

/// The JSON upload, `{ name, type, dataUrl, visibility }`, that tests use.
/// Runtime MCP uploads arrive as transfers and go to [`upload_from_path`].
#[cfg(any(test, feature = "testing"))]
pub async fn upload_file(
    State(state): State<AppState>,
    headers: HeaderMap,
    request: Request,
) -> Response {
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    if let Err(refused) = modules::require_on(&deployment.modules, "files") { return refusal_error(&refused); }
    if let Err(response) = upload_actor(&state, &deployment, &headers).await {
        return response;
    }
    let limits = state.files.limits;
    // Base64 takes four bytes for every three, and the JSON around it a little more.
    let body_limit = (limits.max_file_bytes / 3 * 4 + 64 * 1024).min(usize::MAX as u64) as usize;
    let bytes = match axum::body::to_bytes(request.into_body(), body_limit).await {
        Ok(bytes) => bytes,
        Err(_) => {
            return error(
                StatusCode::PAYLOAD_TOO_LARGE,
                &format!("File upload exceeds the {} limit.", limits.max_file()),
            );
        }
    };
    let input: Value = match serde_json::from_slice(&bytes) {
        Ok(value) => value,
        Err(_) => {
            return error(
                StatusCode::BAD_REQUEST,
                "File upload must be JSON with name, type, and dataUrl.",
            );
        }
    };
    let data = match input
        .get("dataUrl")
        .and_then(Value::as_str)
        .map(decode_base64)
        .transpose()
    {
        Ok(Some(value)) => value,
        _ => {
            return error(
                StatusCode::BAD_REQUEST,
                "File upload dataUrl must contain base64 data.",
            );
        }
    };
    let scratch = state.data_root.join("transfers");
    let source = scratch.join(format!(".upload-{}", Uuid::new_v4()));
    let written = async {
        tokio::fs::create_dir_all(&scratch).await?;
        tokio::fs::write(&source, &data).await
    }
    .await;
    if let Err(e) = written {
        let _ = tokio::fs::remove_file(&source).await;
        return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string());
    }
    let upload = Upload {
        name: input.get("name").and_then(Value::as_str),
        content_type: input.get("type").and_then(Value::as_str),
        visibility: input.get("visibility").and_then(Value::as_str),
    };
    let response = upload_from_path(&state, &headers, upload, &source).await;
    let _ = tokio::fs::remove_file(&source).await;
    response
}

/// What the uploader says about a file besides its bytes.
pub struct Upload<'a> {
    pub name: Option<&'a str>,
    pub content_type: Option<&'a str>,
    pub visibility: Option<&'a str>,
}

pub async fn upload_actor(state: &AppState, deployment: &Deployment, headers: &HeaderMap) -> Result<AuthUser, Response> {
    match authenticate_deployment(state, deployment, headers).await {
        Ok(Some(actor)) => Ok(actor),
        Ok(None) => Err(error(StatusCode::UNAUTHORIZED, "authentication-required")),
        Err(response) => Err(response),
    }
}

/// Reads the index under the Deployment's lock. A missing index is an empty one.
pub async fn read_file_index(directory: &Path) -> Result<Vec<Value>, Response> {
    match tokio::fs::read(directory.join("index.json")).await {
        Ok(bytes) => serde_json::from_slice::<Vec<Value>>(&bytes)
            .map_err(|_| error(StatusCode::INTERNAL_SERVER_ERROR, "File index is invalid.")),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(Vec::new()),
        Err(e) => Err(error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string())),
    }
}

/// The refusal when one more file of `size` bytes would not fit.
pub fn file_room(state: &AppState, files: &[Value], size: u64) -> Option<Response> {
    let used = files
        .iter()
        .filter_map(|file| file["size"].as_u64())
        .sum::<u64>();
    if used.saturating_add(size) > state.files.limits.quota_bytes {
        return Some(error(StatusCode::PAYLOAD_TOO_LARGE, &state.files.limits.quota_reached()));
    }
    if files.len() >= files::MAX_FILES {
        return Some(error(StatusCode::PAYLOAD_TOO_LARGE, files::TOO_MANY_FILES));
    }
    None
}

/// Stores the bytes of `source` as a new file of the signed-in user. The
/// bytes go to the store before the index names them, outside the
/// Deployment's lock, so a slow store holds up no action; the quota is
/// checked before and again when the index changes.
pub async fn upload_from_path(state: &AppState, headers: &HeaderMap, upload: Upload<'_>, source: &Path) -> Response {
    let Some(deployment) = deployment_for(state, headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    if let Err(refused) = modules::require_on(&deployment.modules, "files") { return refusal_error(&refused); }
    let actor = match upload_actor(state, &deployment, headers).await {
        Ok(actor) => actor,
        Err(response) => return response,
    };
    let visibility = match (app_user_files(&deployment), upload.visibility) {
        // The manifest grants shared reads. If it is removed, new files revert to uploader-only.
        (true, None | Some("app-users")) => "private",
        (true, Some("private" | "public")) => return error(StatusCode::BAD_REQUEST, files::FIXED_VISIBILITY),
        (false, None | Some("private")) => "private",
        (false, Some("public")) => "public",
        (_, Some(_)) => {
            return error(
                StatusCode::BAD_REQUEST,
                "File visibility must be private or public.",
            );
        }
    };
    let name = upload
        .name
        .unwrap_or("file")
        .replace(['/', '\\'], "-")
        .chars()
        .filter(|character| !character.is_control())
        .take(180)
        .collect::<String>();
    let content_type = upload
        .content_type
        .filter(|v| {
            v.len() < 128
                && v.bytes()
                    .all(|c| c.is_ascii_alphanumeric() || b"!#$&^_.+-/".contains(&c))
        })
        .unwrap_or("application/octet-stream")
        .to_owned();
    let size = match tokio::fs::metadata(source).await {
        Ok(metadata) => metadata.len(),
        Err(e) => return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    };
    if size == 0 || size > state.files.limits.max_file_bytes {
        return error(StatusCode::PAYLOAD_TOO_LARGE, &state.files.limits.file_size_refused());
    }
    let directory = crate::layout::files(&state.data_root, &deployment.id);
    {
        let _guard = database_lock(state, &deployment.id).await;
        match read_file_index(&directory).await {
            Ok(files) => {
                if let Some(refused) = file_room(state, &files, size) {
                    return refused;
                }
            }
            Err(response) => return response,
        }
    }
    let path = source.to_owned();
    let sha256 = match tokio::task::spawn_blocking(move || copies::checksum_file(&path)).await {
        Ok(Ok((length, digest))) if length == size => digest,
        Ok(Ok(_)) => return error(StatusCode::INTERNAL_SERVER_ERROR, "The upload changed size before storage."),
        Ok(Err(e)) => return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        Err(e) => return error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    };
    let id = Uuid::new_v4().to_string();
    if let Err(e) = state.files.store.put(&deployment.id, &id, source).await {
        return error(StatusCode::INTERNAL_SERVER_ERROR, &format!("The file could not be stored: {e:#}"));
    }
    let metadata = json!({
        "id": id,
        "name": name,
        "type": content_type,
        "size": size,
        "sha256": sha256,
        "visibility": visibility,
        "ownerId": actor.user_id,
        "createdAt": now_ms(),
    });
    let indexed = async {
        let _guard = database_lock(state, &deployment.id).await;
        tokio::fs::create_dir_all(&directory)
            .await
            .map_err(|e| error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()))?;
        let mut files = read_file_index(&directory).await?;
        if let Some(refused) = file_room(state, &files, size) {
            return Err(refused);
        }
        files.insert(0, metadata.clone());
        let index = serde_json::to_vec_pretty(&files)
            .map_err(|e| error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()))?;
        write_atomic(&directory.join("index.json"), &index)
            .await
            .map_err(|e| error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()))
    }
    .await;
    match indexed {
        Ok(()) => Json(json!({"result": file_view(&deployment, &metadata, Some(&actor.user_id))})).into_response(),
        Err(response) => {
            // No index names the bytes, so nothing can read them.
            if let Err(e) = state.files.store.delete(&deployment.id, &id).await {
                eprintln!("konae: could not remove the bytes of refused file {id}: {e:#}");
            }
            response
        }
    }
}

pub async fn serve_file(
    State(state): State<AppState>,
    AxumPath(id): AxumPath<String>,
    headers: HeaderMap,
) -> Response {
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    if let Err(refused) = modules::require_on(&deployment.modules, "files") { return refusal_error(&refused); }
    let actor = match authenticate_deployment(&state, &deployment, &headers).await {
        Ok(actor) => actor,
        Err(response) => return response,
    };
    let private_deployment = is_private(&deployment);
    if private_deployment && actor.is_none() {
        return error(StatusCode::UNAUTHORIZED, "authentication-required");
    }
    let actor_id = actor.as_ref().map(|user| user.user_id.as_str());
    if !valid_file_id(&id) {
        return error(StatusCode::NOT_FOUND, "File not found.");
    }
    let directory = crate::layout::files(&&state.data_root, &deployment.id);
    let index = match tokio::fs::read(directory.join("index.json")).await {
        Ok(bytes) => serde_json::from_slice::<Vec<Value>>(&bytes).unwrap_or_default(),
        Err(_) => return error(StatusCode::NOT_FOUND, "File not found."),
    };
    let Some(metadata) = index
        .iter()
        .find(|file| file["id"].as_str() == Some(id.as_str()))
    else {
        return error(StatusCode::NOT_FOUND, "File not found.");
    };
    if !file_readable(&deployment, metadata, actor_id) {
        return error(StatusCode::NOT_FOUND, "File not found.");
    }
    file_response(&state, &deployment.id, metadata, &headers).await
}

/// The one byte range a `Range` header asks for, as `start..end`. `None`
/// for no header or one this path does not serve, which then gets the whole
/// file; `Err` for a range that starts past the end.
pub fn requested_range(headers: &HeaderMap, size: u64) -> Result<Option<std::ops::Range<u64>>, ()> {
    let Some(value) = headers.get(header::RANGE).and_then(|value| value.to_str().ok()) else {
        return Ok(None);
    };
    let Some(spec) = value.trim().strip_prefix("bytes=") else { return Ok(None) };
    if spec.contains(',') {
        return Ok(None);
    }
    let Some((first, last)) = spec.split_once('-') else { return Ok(None) };
    let (first, last) = (first.trim(), last.trim());
    let range = match (first.parse::<u64>().ok(), last.parse::<u64>().ok()) {
        (Some(start), _) if start >= size => return Err(()),
        (Some(start), Some(end)) if end >= start => start..end.saturating_add(1).min(size),
        (Some(start), None) if last.is_empty() => start..size,
        (None, Some(suffix)) if first.is_empty() && suffix > 0 => size.saturating_sub(suffix)..size,
        _ => return Ok(None),
    };
    Ok(Some(range))
}

/// A stored file's bytes with its own type, streamed from the store. Raster
/// images display inline; everything else downloads, and nothing in it may
/// run. A single `Range` gets 206 with that part.
pub async fn file_response(state: &AppState, deployment: &str, metadata: &Value, headers: &HeaderMap) -> Response {
    let not_found = || error(StatusCode::NOT_FOUND, "File not found.");
    let Some(id) = metadata["id"].as_str() else { return not_found() };
    let size = metadata["size"].as_u64().unwrap_or(0);


    let Ok(etag) = HeaderValue::from_str(&format!("\"{id}-{size}\"")) else { return not_found() };
    if if_none_match(headers, &etag) {
        let mut response = StatusCode::NOT_MODIFIED.into_response();
        response.headers_mut().insert(header::ETAG, etag);
        response.headers_mut().insert(header::CACHE_CONTROL, HeaderValue::from_static(FILE_CACHE_CONTROL));
        return response;
    }
    let range = match requested_range(headers, size) {
        Ok(range) => range,
        Err(()) => {
            let mut response = StatusCode::RANGE_NOT_SATISFIABLE.into_response();
            if let Ok(value) = HeaderValue::from_str(&format!("bytes */{size}")) {
                response.headers_mut().insert(header::CONTENT_RANGE, value);
            }
            return response;
        }
    };
    let blob = match state.files.store.get(deployment, id, range.clone()).await {
        Ok(Some(blob)) => blob,
        Ok(None) => return not_found(),
        Err(e) => {
            eprintln!("konae: could not read file {id}: {e:#}");
            return not_found();
        }
    };
    let content_type = metadata["type"]
        .as_str()
        .unwrap_or("application/octet-stream");
    let inline = [
        "image/png",
        "image/jpeg",
        "image/gif",
        "image/webp",
        "image/avif",
    ]
    .contains(&content_type);
    let length = blob.length;
    let mut response = Response::new(Body::from_stream(tokio_util::io::ReaderStream::with_capacity(blob.reader, 64 * 1024)));
    let headers = response.headers_mut();
    headers.insert(header::CONTENT_LENGTH, HeaderValue::from(length));
    headers.insert(header::ACCEPT_RANGES, HeaderValue::from_static("bytes"));
    if let Some(range) = range {
        *response.status_mut() = StatusCode::PARTIAL_CONTENT;
        if let Ok(value) = HeaderValue::from_str(&format!("bytes {}-{}/{size}", range.start, range.end.saturating_sub(1))) {
            response.headers_mut().insert(header::CONTENT_RANGE, value);
        }
    }
    let headers = response.headers_mut();
    headers.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_str(files::served_type(content_type))
            .unwrap_or(HeaderValue::from_static("application/octet-stream")),
    );
    headers.insert(
        header::CONTENT_DISPOSITION,
        HeaderValue::from_static(if inline { "inline" } else { "attachment" }),
    );
    headers.insert(
        header::X_CONTENT_TYPE_OPTIONS,
        HeaderValue::from_static("nosniff"),
    );
    headers.insert(
        header::CONTENT_SECURITY_POLICY,
        HeaderValue::from_static("default-src 'none'; sandbox"),
    );
    headers.insert(header::ETAG, etag);
    headers.insert(header::CACHE_CONTROL, HeaderValue::from_static(FILE_CACHE_CONTROL));
    response
}

/// A browser may keep a file's bytes but asks the Kernel before each use,
/// so a read still passes the caller's check and a deleted file or a lost
/// right answers 404 at once. No shared cache keeps them.
pub const FILE_CACHE_CONTROL: &str = "private, no-cache";


fn if_none_match(headers: &HeaderMap, etag: &HeaderValue) -> bool {
    let Some(value) = headers.get(header::IF_NONE_MATCH).and_then(|value| value.to_str().ok()) else { return false };
    let Ok(etag) = etag.to_str() else { return false };
    value.split(',').map(str::trim).any(|tag| tag == "*" || tag.trim_start_matches("W/") == etag)
}

pub async fn serve_root(State(state): State<AppState>, headers: HeaderMap) -> Response {
    serve_key(state, headers, "index.html".into()).await
}

pub async fn login_page(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Konae deployment not found.");
    };
    if !modules::is_on(&deployment.modules, "auth") {
        return error(StatusCode::NOT_FOUND, "Authentication is not enabled for this app.");
    }
    match authenticate_deployment(&state, &deployment, &headers).await {
        Ok(Some(_)) => (StatusCode::SEE_OTHER, [(header::LOCATION, "/")]).into_response(),
        Ok(None) => private_login_page(&deployment.project_name, &deployment.signup_policy, state.accounts.verification, google::offered_here(&state, &deployment, &headers)),
        Err(response) => response,
    }
}

pub async fn serve_artifact(
    State(state): State<AppState>,
    AxumPath(path): AxumPath<String>,
    headers: HeaderMap,
) -> Response {
    serve_key(
        state,
        headers,
        if path.is_empty() {
            "index.html".into()
        } else {
            path
        },
    )
    .await
}

pub async fn serve_key(state: AppState, headers: HeaderMap, path: String) -> Response {
    serve_key_with_routes(state, headers, path, None).await
}

pub(crate) async fn serve_key_with_routes(
    state: AppState,
    headers: HeaderMap,
    path: String,
    routes: Option<Arc<http::RouteTable>>,
) -> Response {
    let deployment = match deployment_for(&state, &headers).await {
        Some(value) => value,
        None => return error(StatusCode::NOT_FOUND, "Konae deployment not found."),
    };
    if is_private(&deployment) && path == "robots.txt" {
        return ([(header::CONTENT_TYPE, "text/plain; charset=utf-8")], "User-agent: *\nAllow: /\n").into_response();
    }
    if is_private(&deployment) {
        match authenticate_deployment(&state, &deployment, &headers).await {
            Ok(Some(_)) => {}
            Ok(None) => return private_login_page(&deployment.project_name, &deployment.signup_policy, state.accounts.verification, google::offered_here(&state, &deployment, &headers)),
            Err(response) => return response,
        }
    }
    if artifact::kernel_path(&path) {
        return artifact::not_found_page();
    }
    let seo_on = modules::is_on(&deployment.modules, "seo");
    let address = seo_on.then(|| seo::address(&state, &deployment));
    let cache = ArtifactCache::of(&deployment);




    let navigation = headers
        .get("sec-fetch-dest")
        .and_then(|value| value.to_str().ok())
        .is_some_and(|value| value.eq_ignore_ascii_case("document"));
    let routing = artifact::routing(&deployment.manifest);
    let html_candidate = artifact::candidates(&path, routing).iter().any(|candidate| {
        candidate.to_ascii_lowercase().ends_with(".html") || candidate.to_ascii_lowercase().ends_with(".htm")
    });
    let spa_fallback = seo_on && routing == artifact::Routing::Spa
        && (!safe_relative_path(&path) || tokio::fs::metadata(crate::layout::dist(&state.data_root, &deployment.id).join(&path)).await.is_err());
    let may_be_page = seo_on && (html_candidate || spa_fallback || path == "robots.txt" || path == "sitemap.xml");
    if !navigation && etag_matches(&headers, &cache.version_tag()) && (!seo_on || !may_be_page) {
        return cache.not_modified(cache.version_tag());
    }
    if seo_on && path == "robots.txt" {
        return seo::robots_response(&deployment, &path, read_artifact(&state, &deployment, &path).await.ok(), address.as_ref().unwrap(), &headers, &cache, navigation).unwrap();
    }
    if seo_on && path == "sitemap.xml" {
        return seo::sitemap_response(&state, &deployment, &path, read_artifact(&state, &deployment, &path).await.ok(), address.as_ref().unwrap(), &headers, &cache).await.unwrap();
    }
    for candidate in artifact::candidates(&path, routing) {
        if let Ok(bytes) = read_artifact(&state, &deployment, &candidate).await {
            count_page_view(&state, &deployment, &headers, &candidate).await;
            if seo_on {
                if let Some(response) = seo::html_response(&deployment, &candidate, &bytes, address.as_ref().unwrap(), &headers, &cache) {
                    return response;
                }
            }
            return cache.respond(&headers, bytes, &candidate);
        }
    }

    if let Some(routes) = routes.as_ref() {
        let page_path = format!("/{}", path.trim_start_matches('/'));
        if let Some(response) = http::serve_page_path(&state, &deployment, routes, &page_path, &headers).await {
            return response;
        }
    }


    if path == "favicon.ico" {
        return StatusCode::NO_CONTENT.into_response();
    }
    match routing {
        artifact::Routing::Spa => match read_artifact(&state, &deployment, "index.html").await {
            Ok(bytes) => {
                count_page_view(&state, &deployment, &headers, "index.html").await;
                let mut response = cache.respond(&headers, bytes, "index.html");
                if seo_on { response.headers_mut().insert("x-robots-tag", HeaderValue::from_static("noindex")); }
                response
            }
            Err(_) => error(StatusCode::NOT_FOUND, "Artifact not found."),
        },
        artifact::Routing::Pages => match read_artifact(&state, &deployment, "404.html").await {
            Ok(bytes) => {
                let mut response = artifact_response(bytes, "404.html");
                *response.status_mut() = StatusCode::NOT_FOUND;
                response
            }
            Err(_) => artifact::not_found_page(),
        },
    }
}

/// Counts a page view when a browser navigates to one of the artifact's HTML
/// pages. Only a navigation carries `Sec-Fetch-Dest: document`, so assets, a
/// script's fetch, a HEAD request, curl and most crawlers count nothing, and a
/// prefetch is skipped. The name is the file served, never the address asked
/// for: the artifact bounds the names, so no visitor can grow the store by
/// inventing paths. A single-page app's client-side navigation is invisible
/// here, and a view is a load, not a person (ADR-0010, page views).
pub async fn count_page_view(state: &AppState, deployment: &Deployment, headers: &HeaderMap, file: &str) {
    let lower = file.to_ascii_lowercase();
    if !(lower.ends_with(".html") || lower.ends_with(".htm")) {
        return;
    }
    let header = |name: &str| headers.get(name).and_then(|value| value.to_str().ok()).unwrap_or("");
    if !header("sec-fetch-dest").eq_ignore_ascii_case("document") {
        return;
    }
    if header("sec-purpose").contains("prefetch") || header("purpose").contains("prefetch") {
        return;
    }
    if headers.contains_key(header::COOKIE) && enter::entered_request(state, deployment, headers).await {
        return;
    }
    usage::count(&state.data_root, &deployment.id, usage::Operation::PageView(file.to_owned()));
}

pub async fn read_artifact(state: &AppState, deployment: &Deployment, path: &str) -> Result<Vec<u8>> {
    if !safe_relative_path(path) {
        anyhow::bail!("invalid artifact path");
    }
    let local = layout::dist(&state.data_root, &deployment.id).join(path);
    Ok(tokio::fs::read(local).await?)
}

pub fn private_login_page(app: &str, policy: &SignupPolicy, verification: auth::Verification, google: bool) -> Response {
    let verified = verification == auth::Verification::Required;
    let (note, create) = match policy.mode {
        SignupMode::Open if verified => (
            "New here? Enter your email and create an account. We send a link to choose your password.",
            true,
        ),
        SignupMode::Open => (
            "New here? Enter an email and password, then create an account.",
            true,
        ),
        SignupMode::Allowlist => (
            "Only invited email addresses can create an account.",
            true,
        ),
        SignupMode::Invitation => (
            "Only invited people can create an account. Open the link in your invitation email.",
            false,
        ),
        SignupMode::Closed => (
            "This app is not accepting new accounts. Sign in with an existing account.",
            false,
        ),
    };
    let app = own_page::escape(app);
    let body = [
        r#"<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sign in · "#,
        &app,
        r#"</title><style>"#,
        own_page::CSS,
        r#"</style><link rel="icon" href="data:,"><main><p class="kicker">"#,
        &app,
        r#"</p><h1>Sign in</h1><p>"#,
        note,
        "</p>",
        if google { google::BUTTON } else { "" },
        r#"<form id="auth"><label>Email <input name="email" type="email" required autocomplete="email"></label><label>Password <input name="password" type="password" minlength="8" required autocomplete="current-password"></label><button formaction="/_konae/auth/login">Sign in</button>"#,
        if create && verified {
            r#"<button formaction="/_konae/auth/signup" formnovalidate>Create account</button>"#
        } else if create {
            r#"<button formaction="/_konae/auth/signup">Create account</button>"#
        } else {
            ""
        },
        r#"<p id="error" role="alert"></p><a id="forgot" href="/_konae/account">Forgot your password?</a></form></main><script>{const m=/^\/p\/([^\/]+)(\/|$)/.exec(location.pathname);const prefix=m?'/p/'+m[1]:'';document.querySelector('#forgot').href=prefix+'/_konae/account';document.querySelector('#auth').addEventListener('submit',async e=>{e.preventDefault();const path=prefix+new URL(e.submitter?.formAction||'/_konae/auth/login',location.href).pathname;const form=new FormData(e.currentTarget);const response=await fetch(path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({email:form.get('email'),password:form.get('password')})});const body=await response.json().catch(()=>({}));if(response.status===202){document.querySelector('#error').textContent=body.result.message;return}if(response.ok){location.replace(prefix+'/');return}document.querySelector('#error').textContent=body.error||'Sign in failed.'})}</script></html>"#,
    ]
    .concat();
    let mut response = Response::new(Body::from(body));
    response.headers_mut().insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("text/html; charset=utf-8"),
    );
    response
        .headers_mut()
        .insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response.headers_mut().insert("x-robots-tag", HeaderValue::from_static("noindex"));
    response
}

/// How a browser may keep a Deployment's files. Every file is stored but
/// checked on each use (`no-cache`), so a publish shows at once and an
/// unchanged file costs a 304. A private app's files are `private` so no shared
/// cache holds a page that sits behind its login. File names are not
/// guaranteed to carry a content hash, so nothing is marked `immutable`.
pub struct ArtifactCache {
    pub version: String,
    pub private: bool,
}

impl ArtifactCache {
    pub fn of(deployment: &Deployment) -> Self {
        Self { version: deployment.artifact_version.clone(), private: is_private(deployment) }
    }

    pub fn version_tag(&self) -> String {
        format!("\"{}\"", self.version)
    }

    pub fn control(&self) -> HeaderValue {
        HeaderValue::from_static(if self.private { "private, no-cache" } else { "public, no-cache" })
    }

    pub fn not_modified(&self, tag: String) -> Response {
        let mut response = StatusCode::NOT_MODIFIED.into_response();
        if let Ok(value) = HeaderValue::from_str(&tag) {
            response.headers_mut().insert(header::ETAG, value);
        }
        response.headers_mut().insert(header::CACHE_CONTROL, self.control());
        response
    }

    pub fn respond(&self, headers: &HeaderMap, bytes: Vec<u8>, path: &str) -> Response {
        let tag = self.version_tag();
        if etag_matches(headers, &tag) {
            return self.not_modified(tag);
        }
        let mut response = artifact_response(bytes, path);
        if let Ok(value) = HeaderValue::from_str(&tag) {
            response.headers_mut().insert(header::ETAG, value);
        }
        response.headers_mut().insert(header::CACHE_CONTROL, self.control());
        response
    }
}

/// `If-None-Match` holds a list of tags, possibly weak. A browser never sends
/// `*` on a GET, so it matches nothing here.
pub fn etag_matches(headers: &HeaderMap, tag: &str) -> bool {
    headers
        .get_all(header::IF_NONE_MATCH)
        .iter()
        .filter_map(|value| value.to_str().ok())
        .flat_map(|value| value.split(','))
        .map(|candidate| candidate.trim())
        .any(|candidate| candidate.strip_prefix("W/").unwrap_or(candidate) == tag)
}

pub fn artifact_response(bytes: Vec<u8>, path: &str) -> Response {
    let mut response = Response::new(Body::from(bytes));
    response.headers_mut().insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static(content_type(path)),
    );
    response.headers_mut().insert(
        header::X_CONTENT_TYPE_OPTIONS,
        HeaderValue::from_static("nosniff"),
    );
    response
}

/// The small export's whole budget: databases plus the base64 file bundle.

/// Runs one operation of the owner's database door on a Deployment: inspect,
/// browse, SQL, row edits and backups. `body` is its JSON input.
pub async fn admin_database(state: &AppState, id: &str, body: &[u8]) -> Response {
    let Some(deployment) = state
        .deployments
        .read()
        .await
        .values()
        .find(|d| d.id == id)
        .cloned()
    else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    if body.len() > 200_000 {
        return error(StatusCode::PAYLOAD_TOO_LARGE, "Database request is too large.");
    }
    let body: Value = match serde_json::from_slice(body) {
        Ok(value) => value,
        Err(_) => {
            return error(
                StatusCode::BAD_REQUEST,
                "Database request must be valid JSON.",
            );
        }
    };
    let operation = body.get("operation").and_then(Value::as_str).unwrap_or("");
    if !matches!(operation, "list-backups" | "restore-backup") {
        if let Err(refused) = modules::require_on(&deployment.modules, "actions") { return refusal_error(&refused); }
    }
    let _project_guard = database_lock(&state, &format!("project:{}", deployment.project_id)).await;
    let _release_guard = named_lock(state, &format!("publish:{}", deployment.id), operation == "restore-backup").await;
    let path = database_path(&state, &deployment.id);
    let _guard = database_lock(&state, &deployment.id).await;
    match operation {
        "inspect" => match inspect_database(&path) {
            Ok(result) => Json(json!({"result": result})).into_response(),
            Err(e) => error(StatusCode::BAD_REQUEST, &e.to_string()),
        },
        "browse" => match browse_table(&path, &body) {
            Ok(result) => Json(json!({"result": result})).into_response(),
            Err(e) => error(StatusCode::BAD_REQUEST, &e.to_string()),
        },
        "sql" => {
            match run_admin_sql(&path, body.get("sql").and_then(Value::as_str).unwrap_or("")) {
                Ok(result) => Json(json!({"result": result})).into_response(),
                Err(e) => error(StatusCode::BAD_REQUEST, &e.to_string()),
            }
        }
        "update-cell" => admin_update_cell(&path, &body),
        "insert-row" => admin_insert_row(&path, &body),
        "delete-row" => admin_delete_row(&path, &body),
        "list-backups" => match list_backups(&state, &deployment.id).await {
            Ok(result) => Json(json!({"result": result})).into_response(),
            Err(e) => error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        "create-backup" => match create_backup(
            &state,
            &deployment.id,
            body.get("label")
                .and_then(Value::as_str)
                .unwrap_or("Manual backup"),
        )
        .await
        {
            Ok(result) => Json(json!({"result": result})).into_response(),
            Err(e) => error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        "restore-backup" => match restore_backup(
            &state,
            &deployment.id,
            body.get("backupId").and_then(Value::as_str).unwrap_or(""),
        )
        .await
        {
            Ok(result) => Json(json!({"result": result})).into_response(),
            Err(e) => error(StatusCode::BAD_REQUEST, &e.to_string()),
        },
        _ => error(StatusCode::BAD_REQUEST, "Unknown database operation."),
    }
}

pub fn database_path(state: &AppState, id: &str) -> PathBuf {
    crate::layout::database(&state
        .data_root, &id)
}

/// Named locks on one database or transfer. Each is a read-write lock: a
/// Server Action shares its Database's lock, and work that reads or replaces
/// the whole file (a copy, a restore, an import, the owner's console) holds
/// it alone. An entry lives only while someone holds or waits for it, so
/// callers that pass many distinct names cannot grow the map.
pub type LockMap = Arc<std::sync::Mutex<HashMap<String, Arc<RwLock<()>>>>>;


#[allow(dead_code)]
pub enum Held {
    Shared(OwnedRwLockReadGuard<()>),
    Alone(OwnedRwLockWriteGuard<()>),
}

/// Holds one named lock. Dropping it releases the lock and removes the map
/// entry when no other task holds or waits for the same name.
pub struct NamedLockGuard {
    pub guard: Option<Held>,
    pub entry: Option<Arc<RwLock<()>>>,
    pub name: String,
    pub locks: LockMap,
}

impl Drop for NamedLockGuard {
    fn drop(&mut self) {
        let mut locks = self.locks.lock().unwrap_or_else(|poisoned| poisoned.into_inner());


        self.guard.take();
        let entry = self.entry.take();


        if entry.is_some_and(|entry| Arc::strong_count(&entry) == 2) {
            locks.remove(&self.name);
        }
    }
}

pub async fn named_lock(state: &AppState, name: &str, alone: bool) -> NamedLockGuard {
    let entry = {
        let mut locks = state.db_locks.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
        locks
            .entry(name.to_owned())
            .or_insert_with(|| Arc::new(RwLock::new(())))
            .clone()
    };


    let mut held = NamedLockGuard {
        guard: None,
        entry: Some(entry.clone()),
        name: name.to_owned(),
        locks: state.db_locks.clone(),
    };
    held.guard = Some(if alone {
        Held::Alone(entry.write_owned().await)
    } else {
        Held::Shared(entry.read_owned().await)
    });
    held
}

/// Holds the named lock alone: no Server Action runs on that Database, and
/// no one else holds the name, until the guard drops.
pub async fn database_lock(state: &AppState, id: &str) -> NamedLockGuard {
    let held = named_lock(state, id, true).await;


    app_db::forget(&database_path(state, id));
    held
}

/// What one Server Action holds on its Database while it runs. Queries share
/// the Database's lock, so they run side by side and beside a write: the
/// Database is in WAL mode, where a reader sees the last commit and never
/// waits for the writer. Mutations also take the Database's write lock, so
/// they reach SQLite one at a time instead of meeting `SQLITE_BUSY`.
pub struct ActionLock {
    pub _write: Option<NamedLockGuard>,
    pub _database: NamedLockGuard,
}

pub async fn action_lock(state: &AppState, id: &str, kind: &str) -> ActionLock {
    let database = named_lock(state, id, false).await;
    let write = if kind == "query" { None } else { Some(named_lock(state, &format!("write:{id}"), true).await) };
    ActionLock { _write: write, _database: database }
}

pub fn inspect_database(path: &Path) -> Result<Vec<Value>> {
    let db = Connection::open(path)?;
    let mut statement = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND lower(name) NOT IN ('__konae_schema_state','__konae_schema_history','__konae_function_receipts') ORDER BY name")?;
    let names = statement
        .query_map([], |row| row.get::<_, String>(0))?
        .collect::<rusqlite::Result<Vec<_>>>()?;
    names.into_iter().map(|name| {
        let columns = table_columns(&db, &name)?;
        let count_sql = format!("SELECT COUNT(*) FROM {}", quote_identifier(&name));
        let count: i64 = db.query_row(&count_sql, [], |row| row.get(0))?;
        Ok(json!({"name": name, "columns": columns.iter().map(|column| column["name"].clone()).collect::<Vec<_>>(), "totalRows": count}))
    }).collect()
}

pub fn table_columns(db: &Connection, table: &str) -> Result<Vec<Value>> {
    anyhow::ensure!(!schema_transform::is_internal_table(table), "Reserved Kernel table.");
    if !table_exists(db, table)? {
        anyhow::bail!("Table not found: {table}");
    }
    let sql = format!("PRAGMA table_info({})", quote_identifier(table));
    let mut statement = db.prepare(&sql)?;
    let rows = statement.query_map([], |row| Ok(json!({
        "name": row.get::<_, String>(1)?, "type": row.get::<_, String>(2)?,
        "notNull": row.get::<_, i64>(3)? != 0, "defaultValue": row.get::<_, Option<String>>(4)?,
        "primaryKey": row.get::<_, i64>(5)? != 0,
    })))?.collect::<rusqlite::Result<Vec<_>>>()?;
    Ok(rows)
}

pub fn table_exists(db: &Connection, table: &str) -> Result<bool> {
    Ok(db
        .query_row(
            "SELECT 1 FROM sqlite_master WHERE lower(type)='table' AND lower(name)=lower(?1)",
            [table],
            |_| Ok(()),
        )
        .optional()?
        .is_some())
}

pub fn quote_identifier(value: &str) -> String {
    format!("\"{}\"", value.replace('"', "\"\""))
}

pub fn browse_table(path: &Path, body: &Value) -> Result<Value> {
    let db = Connection::open(path)?;
    restrict_database(&db)?;
    let table = body.get("tableName").and_then(Value::as_str).unwrap_or("");
    let columns = table_columns(&db, table)?;
    let names = columns
        .iter()
        .filter_map(|v| v["name"].as_str())
        .collect::<Vec<_>>();
    let page_size = body
        .get("pageSize")
        .and_then(Value::as_u64)
        .unwrap_or(50)
        .clamp(1, 100) as i64;
    let page = body
        .get("page")
        .and_then(Value::as_u64)
        .unwrap_or(0)
        .min(i64::MAX as u64) as i64;
    let sort = body
        .get("sortColumn")
        .and_then(Value::as_str)
        .filter(|s| names.contains(s))
        .map(quote_identifier)
        .unwrap_or_else(|| "rowid".into());
    let direction = if body.get("sortDirection").and_then(Value::as_str) == Some("DESC") {
        "DESC"
    } else {
        "ASC"
    };
    let sql = format!(
        "SELECT rowid AS __konae_rowid, * FROM {} ORDER BY {sort} {direction} LIMIT ?1 OFFSET ?2",
        quote_identifier(table)
    );
    let mut statement = db.prepare(&sql)?;
    let col_names = statement
        .column_names()
        .iter()
        .map(|s| s.to_string())
        .collect::<Vec<_>>();
    let mut budget = ResultBudget::default();
    let metadata_bytes = columns.iter().fold(128usize, |bytes, column| {
        bytes.saturating_add(browse_column_json_cost(column))
    });
    anyhow::ensure!(budget.reserve(metadata_bytes), "{QUERY_RESULT_TOO_LARGE}");
    let rows = bounded_rows(statement
        .query_map([page_size, page.saturating_mul(page_size)], |row| {
            let mut values = serde_json::Map::new();
            let mut row_id = Value::Null;
            let mut first_value = true;
            if !budget.begin_row(22) {
                return Err(rusqlite::Error::ToSqlConversionFailure(Box::new(ResultTooLarge)));
            }
            for (i, name) in col_names.iter().enumerate() {
                if name == "__konae_rowid" {
                    let value = row.get_ref(i)?;
                    if !budget.spend_value(value) {
                        return Err(rusqlite::Error::ToSqlConversionFailure(Box::new(ResultTooLarge)));
                    }
                    row_id = sql_json(value);
                } else {
                    let value = row.get_ref(i)?;
                    if !budget.spend_column(name, value, first_value) {
                        return Err(rusqlite::Error::ToSqlConversionFailure(Box::new(ResultTooLarge)));
                    }
                    first_value = false;
                    values.insert(name.clone(), sql_json(value));
                }
            }
            Ok(json!({"rowId": row_id, "values": values}))
        })?)?;
    let count_sql = format!("SELECT COUNT(*) FROM {}", quote_identifier(table));
    let total: i64 = db.query_row(&count_sql, [], |row| row.get(0))?;
    Ok(
        json!({"columns": columns, "rows": rows, "totalRows": total, "page": page, "pageSize": page_size}),
    )
}

pub fn run_admin_sql(path: &Path, sql: &str) -> Result<Value> {
    if sql.trim().is_empty() {
        anyhow::bail!("Write a SQL statement first.");
    }
    if sql.len() > 100_000 {
        anyhow::bail!("SQL script is too large.");
    }
    let tokens = sql_tokens(sql);
    if tokens.windows(3).any(|tokens| tokens[0].is_word("RENAME") && tokens[1].is_word("TO") && matches!(tokens[2].kind, SqlTokKind::Word | SqlTokKind::Ident) && schema_transform::is_internal_table(&tokens[2].text)) {
        anyhow::bail!("SQL cannot rename a table to a reserved Kernel table.");
    }
    let db = Connection::open(path)?;
    restrict_database(&db)?;
    let started = std::time::Instant::now();
    let first = sql
        .trim()
        .split_whitespace()
        .next()
        .unwrap_or("SQL")
        .to_ascii_uppercase();
    if ["SELECT", "PRAGMA", "EXPLAIN", "WITH"].contains(&first.as_str()) {
        let mut statement = db.prepare(sql)?;
        let names = statement
            .column_names()
            .iter()
            .map(|s| s.to_string())
            .collect::<Vec<_>>();
        let mut rows = statement.query([])?;
        let mut values = Vec::new();
        let mut result_bytes = 0;
        let mut budget = ResultBudget::default();
        while let Some(row) = rows.next()? {
            let Some(record) = bounded_row(row, &names, &mut budget)? else {
                anyhow::bail!("SQL result exceeds 2 MiB.");
            };
            values.push(record);
            result_bytes += serde_json::to_vec(values.last().unwrap())?.len();
            if result_bytes > 2 * 1024 * 1024 {
                anyhow::bail!("SQL result exceeds 2 MiB.");
            }
            if values.len() > 1000 {
                anyhow::bail!("SQL returned more than 1000 rows.");
            }
        }
        Ok(
            json!({"columns": names, "rows": values, "changes": 0, "elapsedMs": started.elapsed().as_millis(), "statement": first}),
        )
    } else {
        let mut db = db;
        let tx = db.transaction()?;
        tx.execute_batch(sql)?;
        let changes = tx.changes();
        tx.commit()?;
        Ok(
            json!({"columns": [], "rows": [], "changes": changes, "elapsedMs": started.elapsed().as_millis(), "statement": first}),
        )
    }
}

pub fn admin_update_cell(path: &Path, body: &Value) -> Response {
    let result = (|| -> Result<()> {
        let db = Connection::open(path)?;
        limit_database_size(&db, MAX_APP_DATABASE_BYTES)?;
        let table = body.get("tableName").and_then(Value::as_str).unwrap_or("");
        let column = body.get("columnName").and_then(Value::as_str).unwrap_or("");
        let names = table_columns(&db, table)?;
        if !names.iter().any(|c| c["name"].as_str() == Some(column)) {
            anyhow::bail!("Unknown column.");
        }
        let sql = format!(
            "UPDATE {} SET {}=?1 WHERE rowid=?2",
            quote_identifier(table),
            quote_identifier(column)
        );
        db.execute(
            &sql,
            (
                value_to_sql(body.get("value"))?,
                value_to_sql(body.get("rowId"))?,
            ),
        )?;
        Ok(())
    })();
    match result {
        Ok(()) => Json(json!({"result":{"ok":true}})).into_response(),
        Err(e) => error(StatusCode::BAD_REQUEST, &e.to_string()),
    }
}

pub fn admin_insert_row(path: &Path, body: &Value) -> Response {
    let result = (|| -> Result<()> {
        let db = Connection::open(path)?;
        limit_database_size(&db, MAX_APP_DATABASE_BYTES)?;
        let table = body.get("tableName").and_then(Value::as_str).unwrap_or("");
        let columns = table_columns(&db, table)?;
        let values = body
            .get("values")
            .and_then(Value::as_object)
            .cloned()
            .unwrap_or_default();
        let names = values.keys().cloned().collect::<Vec<_>>();
        if names
            .iter()
            .any(|n| !columns.iter().any(|c| c["name"].as_str() == Some(n)))
        {
            anyhow::bail!("Unknown column.");
        }
        if names.is_empty() {
            db.execute(
                &format!("INSERT INTO {} DEFAULT VALUES", quote_identifier(table)),
                [],
            )?;
        } else {
            let sql = format!(
                "INSERT INTO {} ({}) VALUES ({})",
                quote_identifier(table),
                names
                    .iter()
                    .map(|n| quote_identifier(n))
                    .collect::<Vec<_>>()
                    .join(","),
                (1..=names.len())
                    .map(|i| format!("?{i}"))
                    .collect::<Vec<_>>()
                    .join(",")
            );
            let params = names
                .iter()
                .map(|n| value_to_sql(values.get(n)))
                .collect::<Result<Vec<_>>>()?;
            db.execute(&sql, params_from_iter(params))?;
        }
        Ok(())
    })();
    match result {
        Ok(()) => Json(json!({"result":{"ok":true}})).into_response(),
        Err(e) => error(StatusCode::BAD_REQUEST, &e.to_string()),
    }
}

pub fn admin_delete_row(path: &Path, body: &Value) -> Response {
    let result = (|| -> Result<()> {
        let db = Connection::open(path)?;
        limit_database_size(&db, MAX_APP_DATABASE_BYTES)?;
        let table = body.get("tableName").and_then(Value::as_str).unwrap_or("");
        table_columns(&db, table)?;
        db.execute(
            &format!("DELETE FROM {} WHERE rowid=?1", quote_identifier(table)),
            [value_to_sql(body.get("rowId"))?],
        )?;
        Ok(())
    })();
    match result {
        Ok(()) => Json(json!({"result":{"ok":true}})).into_response(),
        Err(e) => error(StatusCode::BAD_REQUEST, &e.to_string()),
    }
}

pub fn value_to_sql(value: Option<&Value>) -> Result<SqlValue> {
    let Some(value) = value else {
        return Ok(SqlValue::Null);
    };
    match value {
        Value::Null => Ok(SqlValue::Null),
        Value::String(v) => Ok(SqlValue::Text(v.clone())),
        Value::Bool(v) => Ok(SqlValue::Integer(*v as i64)),
        Value::Number(v) => v
            .as_i64()
            .map(SqlValue::Integer)
            .or_else(|| v.as_f64().map(SqlValue::Real))
            .ok_or_else(|| anyhow::anyhow!("Invalid number.")),
        _ => anyhow::bail!("Unsupported SQLite value."),
    }
}

pub async fn list_backups(state: &AppState, id: &str) -> Result<Vec<Value>> {
    let dir = backup_dir(state, id);
    let mut entries = match tokio::fs::read_dir(&dir).await {
        Ok(v) => v,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(e) => return Err(e.into()),
    };
    let mut backups = Vec::new();
    while let Some(entry) = entries.next_entry().await? {
        if entry.path().extension().and_then(|s| s.to_str()) != Some("json") {
            continue;
        }
        let backup: DatabaseBackup = serde_json::from_slice(&tokio::fs::read(entry.path()).await?)?;
        backups.push(backup.view());
    }
    backups.sort_by(|a, b| b["createdAt"].as_u64().cmp(&a["createdAt"].as_u64()));
    Ok(backups)
}

pub async fn create_backup(state: &AppState, id: &str, label: &str) -> Result<Value> {
    let db_path = database_path(state, id);
    let dir = backup_dir(state, id);
    tokio::fs::create_dir_all(&dir).await?;
    let backup_id = Uuid::new_v4().to_string();
    let snapshot_path = dir.join(format!("{backup_id}.sqlite"));
    copies::vacuum_into(&db_path, &snapshot_path)?;
    let size = tokio::fs::metadata(&snapshot_path).await?.len();
    let backup = DatabaseBackup {
        id: backup_id.clone(),
        label: label.chars().take(120).collect(),
        created_at: now_ms(),
        size_bytes: size,
        key: format!("{backup_id}.sqlite"),
        holds: Vec::new(),
    };
    tokio::fs::write(
        dir.join(format!("{backup_id}.json")),
        serde_json::to_vec(&backup)?,
    )
    .await?;
    Ok(backup.view())
}

pub async fn restore_backup(state: &AppState, id: &str, backup_id: &str) -> Result<Value> {
    if backup_id.is_empty() || backup_id.contains('/') || backup_id.contains("..") {
        anyhow::bail!("Invalid backup ID.");
    }

    let directory = backup_dir(state, id);
    let record = copies::history::checked_record(&directory, backup_id)?;
    if !record.holds.is_empty() {
        let deployment = state.deployments.read().await.values().find(|d| d.id == id).cloned().context("Deployment not found.")?;
        return import::restore_held(state, &deployment, &record).await;
    }
    let backup_path = backup_dir(state, id).join(format!("{backup_id}.sqlite"));
    let bytes = tokio::fs::read(&backup_path).await?;
    create_backup(state, id, "Before restore").await?;
    let temp_path = database_path(state, id).with_extension("restore.sqlite");
    tokio::fs::write(&temp_path, &bytes).await?;
    let check = Connection::open(&temp_path)?;
    let integrity: String = check.query_row("PRAGMA integrity_check", [], |row| row.get(0))?;
    drop(check);
    if integrity != "ok" {
        let _ = tokio::fs::remove_file(&temp_path).await;
        anyhow::bail!("The backup failed SQLite's integrity check.");
    }
    let _generation = state.copies.generations.read().await;
    replace_database_file(&temp_path, &database_path(state, id))?;
    Ok(json!({"id":backup_id,"sizeBytes":bytes.len()}))
}

/// Runs an action's statement on a blocking thread while the caller holds
/// the Deployment's database lock. The statement deadline is checked between
/// SQLite steps, and one step, such as `instr` or `replace` over two large
/// values, can run past it. On a blocking thread that delays only this
/// Deployment, never the async workers every other app shares.
/// What a statement did. `answer` is what the caller reads. `rows` are the
/// changed rows a mutation's notice reads back through the Kernel's own
/// RETURNING clause (ADR-0012); they never reach the answer.
pub struct Ran {
    pub answer: Value,
    pub rows: Vec<serde_json::Map<String, Value>>,
}

impl Ran {
    /// What a notice reads of this run, at `now` in milliseconds.
    pub fn changed(&self, now: u64) -> notify::Changed<'_> {
        notify::Changed { count: self.answer["changes"].as_u64().unwrap_or(0), rows: &self.rows, now }
    }
}

pub async fn run_action(path: PathBuf, action: &ActionDefinition, params: Vec<SqlValue>) -> Result<Ran> {
    run_action_holding(path, action, params, None).await
}

/// Like `run_action`, for a statement that holds one of the Deployment's
/// slots (`Guards::statement_permit`). The permit moves into the blocking
/// thread, so the slot stays held until the statement ends, whether or not
/// the caller still waits for it.
pub async fn run_action_in_slot(path: PathBuf, action: &ActionDefinition, params: Vec<SqlValue>, permit: tokio::sync::OwnedSemaphorePermit) -> Result<Ran> {
    run_action_holding(path, action, params, Some(permit)).await
}

async fn run_action_holding(path: PathBuf, action: &ActionDefinition, params: Vec<SqlValue>, permit: Option<tokio::sync::OwnedSemaphorePermit>) -> Result<Ran> {
    let action = action.clone();
    tokio::task::spawn_blocking(move || {
        let _permit = permit;
        if action.kind == "query" {
            run_query(&path, &action, params).map(|rows| Ran { answer: Value::from(rows), rows: Vec::new() })
        } else {
            run_mutation(&path, &action, params)
        }
    })
    .await
    .map_err(anyhow::Error::from)?
}

pub fn run_query(path: &Path, action: &ActionDefinition, params: Vec<SqlValue>) -> Result<Vec<Value>> {
    let connection = app_db::open(path)?;
    run_query_on_connection(&connection, action, params)
}

pub fn run_query_on_connection(connection: &Connection, action: &ActionDefinition, params: Vec<SqlValue>) -> Result<Vec<Value>> {
    let mut statement = connection.prepare_cached(&action.statement)?;
    let names = statement
        .column_names()
        .into_iter()
        .map(str::to_owned)
        .collect::<Vec<_>>();
    let mut budget = ResultBudget::default();
    let rows = bounded_rows(statement
        .query_map(params_from_iter(params), |row| {
            bounded_row(row, &names, &mut budget)?
                .ok_or_else(|| rusqlite::Error::ToSqlConversionFailure(Box::new(ResultTooLarge)))
        })?)?;
    if rows.len() > 1000 {
        anyhow::bail!("Action returned more than 1000 rows.");
    }
    Ok(rows)
}

pub fn run_mutation(path: &Path, action: &ActionDefinition, params: Vec<SqlValue>) -> Result<Ran> {
    let mut connection = app_db::open(path)?;
    let transaction = connection.transaction()?;
    let ran = run_mutation_on_connection(&transaction, action, params)?;
    transaction.commit()?;
    Ok(ran)
}

pub fn run_mutation_on_connection(connection: &Connection, action: &ActionDefinition, params: Vec<SqlValue>) -> Result<Ran> {
    let columns = action.notify.as_ref().map(|_| notify::returning("", action)).unwrap_or_default();
    let mut rows = Vec::new();
    let mut budget = ResultBudget::default();
    let changes = if columns.is_empty() {
        connection.prepare_cached(&action.statement)?.execute(params_from_iter(params))? as u64
    } else {
        let mut statement = connection.prepare_cached(&notify::with_returning(&action.statement, &columns))?;
        let mut cursor = statement.query(params_from_iter(params))?;
        let mut serialized_bytes = 2usize;


        while let Some(row) = cursor.next()? {
            if rows.len() < notify::MAX_RETURNED_ROWS {
                let mut object = serde_json::Map::new();
                if !budget.begin_row(2) {
                    anyhow::bail!("{QUERY_RESULT_TOO_LARGE}");
                }
                for (index, column) in columns.iter().enumerate() {
                    let value = row.get_ref(index)?;
                    if !budget.spend_column(column, value, index == 0) {
                        anyhow::bail!("{QUERY_RESULT_TOO_LARGE}");
                    }
                    object.insert(column.clone(), sql_json(value));
                }
                serialized_bytes = serialized_bytes
                    .saturating_add(usize::from(!rows.is_empty()))
                    .saturating_add(serde_json::to_vec(&object)?.len());
                if serialized_bytes > 2 * 1024 * 1024 {
                    anyhow::bail!("{QUERY_RESULT_TOO_LARGE}");
                }
                rows.push(object);
            }
        }
        drop(cursor);
        drop(statement);
        connection.changes()
    };
    let last_insert_id = connection.last_insert_rowid();
    Ok(Ran { answer: json!({"changes": changes, "lastInsertId": last_insert_id}), rows })
}

/// Binds an action's parameters. `actor_id` is the caller's ID: a person's
/// or an API key's.
pub fn resolve_bindings(
    action: &ActionDefinition,
    input: &Value,
    actor_id: Option<&str>,
) -> std::result::Result<Vec<SqlValue>, String> {
    let object = input
        .as_object()
        .ok_or_else(|| "Action input must be an object.".to_string())?;
    let accepted = action
        .bindings
        .iter()
        .filter_map(|binding| {
            if binding.source == "input" {
                binding.key.as_ref()
            } else {
                None
            }
        })
        .collect::<Vec<_>>();
    if let Some(key) = object.keys().find(|key| !accepted.contains(key)) {
        return Err(format!("Unexpected action input: {key}"));
    }
    action
        .bindings
        .iter()
        .map(|binding| match binding.source.as_str() {
            "actor" if binding.field.as_deref() == Some("id") => actor_id
                .map(|id| SqlValue::Text(id.to_owned()))
                .ok_or_else(|| "This action requires an authenticated actor.".to_string()),
            "kernel" if binding.field.as_deref() == Some("now") => {
                Ok(SqlValue::Integer(now_ms() as i64))
            }
            "literal" => json_sql(binding.value.as_ref().unwrap_or(&Value::Null)),
            "input" => {
                let key = binding
                    .key
                    .as_ref()
                    .ok_or_else(|| "Input binding has no key.".to_string())?;
                if binding.nullable && object.get(key).is_none_or(Value::is_null) {
                    return Ok(SqlValue::Null);
                }
                let value = object
                    .get(key)
                    .ok_or_else(|| format!("Missing action input: {key}"))?;
                if binding.value_type.as_deref() == Some("string") {
                    let text = value
                        .as_str()
                        .filter(|value| !value.trim().is_empty())
                        .ok_or_else(|| format!("{key} must be a non-empty string."))?;

                    if text.encode_utf16().count() > binding.max_length.unwrap_or(10_000) {
                        return Err(format!("{key} is too long."));
                    }
                    Ok(SqlValue::Text(text.to_owned()))
                } else if binding.value_type.as_deref() == Some("number") {

                    value
                        .as_i64()
                        .map(SqlValue::Integer)
                        .or_else(|| value.as_f64().map(SqlValue::Real))
                        .ok_or_else(|| format!("{key} must be a number."))
                } else if binding.value_type.as_deref() == Some("boolean") {
                    value
                        .as_bool()
                        .map(|value| SqlValue::Integer(value as i64))
                        .ok_or_else(|| format!("{key} must be a boolean."))
                } else {
                    Err(format!("Unsupported input type for {key}."))
                }
            }
            _ => Err(format!("Unsupported binding source: {}", binding.source)),
        })
        .collect()
}

pub fn validate_action(name: &str, action: &ActionDefinition) -> std::result::Result<(), refusal::Refusal> {
    validate_declarations(name, action)?;
    page::validate_action(name, action)?;
    action_shape::check_keys(name, action)
}

pub fn validate_declarations(name: &str, action: &ActionDefinition) -> std::result::Result<(), refusal::Refusal> {
    action_shape::check_action(name, action)?;
    let tokens = sql_tokens(&action.statement);
    if tokens.iter().enumerate().any(|(index, token)| {
        let after_modifier = if token.is_word("UPDATE") && tokens.get(index + 1).is_some_and(|next| next.is_word("OR")) { index + 3 } else { index + 1 };
        let target = if tokens.get(after_modifier + 1).is_some_and(|dot| dot.is_symbol(".")) { tokens.get(after_modifier + 2) } else { tokens.get(after_modifier) };
        token.is_any(&["FROM", "JOIN", "UPDATE", "INTO", "TABLE", "REFERENCES"])
            && target.is_some_and(|target| matches!(target.kind, SqlTokKind::Word | SqlTokKind::Ident) && schema_transform::is_internal_table(&target.text))
    }) {
        return Err(refusal::refuse("schema-transform.statement-refused", format!("Action {name} cannot read or write a reserved Kernel table.")));
    }
    if calls::check_kind(name, action)?.is_some() {
        return Ok(());
    }
    usage::check_signal_action(name, action)?;
    if action.kind == "signal" {
        usage::declaration(name, action)?;
        http::binding(name, action)?;
        guard::declaration(name, action)?;
        notify::declaration(name, action)?;
        schedule::check_subscribe(name, action)?;
        schedule::declaration(name, action)?;
        return Ok(());
    }
    sql_rules::check_statement(name, action)?;
    if action.kind == "query" {
        if let Some(reason) = unbounded_query_reason(&action.statement) {
            return Err(refusal::refuse(
                "query.limit-missing",
                format!("Action {name} {reason} Add a LIMIT. A total (count, sum, avg, min or max) with no GROUP BY does not need one."),
            ));
        }
    }
    usage::declaration(name, action)?;
    http::binding(name, action)?;
    guard::declaration(name, action)?;
    notify::declaration(name, action)?;
    schedule::check_subscribe(name, action)?;
    schedule::declaration(name, action)?;
    Ok(())
}

/// Same rule as `src/lib/query-bound.ts`. A LIMIT counts only outside
/// parentheses, strings and comments. The editor and an exported Kernel refuse
/// the same query.
pub fn unbounded_query_reason(sql: &str) -> Option<&'static str> {
    let tokens = sql_tokens(sql);
    let top: Vec<&SqlTok> = tokens.iter().filter(|token| token.depth == 0).collect();
    if limit_index(&top).is_some() {
        return None;
    }
    if top.iter().any(|token| token.is_any(&["EXCEPT", "INTERSECT", "UNION"])) {
        return Some("combines more than one query and has no LIMIT on the whole result.");
    }
    if tokens.iter().any(|token| token.is_word("OVER")) {
        return Some("uses OVER, which keeps one result row per stored row, and has no LIMIT.");
    }
    let Some(from) = top.iter().position(|token| token.is_word("FROM")) else {
        return None;
    };
    for pair in top.windows(2) {
        if pair[0].is_word("GROUP") && pair[1].is_word("BY") {
            return Some("groups rows and has no LIMIT, so the result can grow with the data.");
        }
    }
    let Some(select) = top.iter().position(|token| token.is_word("SELECT")) else {
        return Some("reads rows and has no LIMIT.");
    };
    if select >= from || !aggregate_select_list(&tokens.iter().filter(|token| token.start > top[select].start && token.start < top[from].start).collect::<Vec<_>>()) {
        return Some("reads rows and has no LIMIT.");
    }
    None
}

/// Where the LIMIT clause starts among the top-level tokens. `:limit`,
/// `@limit` and `$limit` are named parameters, not the clause, as
/// `limitIndex` in src/lib/query-bound.ts reads them.
pub fn limit_index(top: &[&SqlTok]) -> Option<usize> {
    top.iter().enumerate().position(|(index, token)| {
        let parameter = index > 0 && [":", "@", "$"].iter().any(|symbol| top[index - 1].is_symbol(symbol));
        token.is_word("LIMIT") && !parameter
    })
}

pub fn aggregate_select_list(mut list: &[&SqlTok]) -> bool {
    if list.first().is_some_and(|token| token.is_any(&["ALL", "DISTINCT"])) { list = &list[1..]; }
    !list.is_empty() && split_expressions(list, 0).iter().all(|expression| {
        let mut expression = *expression;
        if let Some(alias) = expression.iter().position(|token| token.depth == 0 && token.is_word("AS")) {
            expression = &expression[..alias];
        } else if expression.last().is_some_and(|token| matches!(token.kind, SqlTokKind::Word | SqlTokKind::Ident))
            && expression.len() > 1 && expression[expression.len() - 2].is_symbol(")") {
            expression = &expression[..expression.len() - 1];
        }
        total_expression(expression)
    })
}

fn split_expressions<'a>(list: &'a [&'a SqlTok], depth: i32) -> Vec<&'a [&'a SqlTok]> {
    let mut parts = Vec::new();
    let mut start = 0;
    for (index, token) in list.iter().enumerate() {
        if token.depth == depth && token.is_symbol(",") { parts.push(&list[start..index]); start = index + 1; }
    }
    parts.push(&list[start..]);
    parts
}

fn total_expression(list: &[&SqlTok]) -> bool {
    if list.len() < 3 { return false; }
    let name = list[0];
    if name.kind != SqlTokKind::Word || !list[1].is_symbol("(") || !list[list.len()-1].is_symbol(")") || list[list.len()-1].depth != name.depth { return false; }
    if list.iter().enumerate().position(|(index, token)| index > 1 && token.is_symbol(")") && token.depth == name.depth) != Some(list.len()-1) { return false; }
    let args = split_expressions(&list[2..list.len()-1], name.depth + 1);
    if name.is_any(&["AVG", "COUNT", "GROUP_CONCAT", "MAX", "MIN", "SUM", "TOTAL"]) {
        return args.iter().all(|arg| !arg.is_empty()) && (args.len() == 1 || name.is_word("GROUP_CONCAT") && args.len() == 2);
    }
    if !name.is_any(&["COALESCE", "IFNULL"]) || args.len() < 2 || name.is_word("IFNULL") && args.len() != 2 { return false; }
    args.iter().any(|arg| total_expression(arg)) && args.iter().all(|arg| total_expression(arg) || constant_expression(arg))
}

fn constant_expression(mut list: &[&SqlTok]) -> bool {
    if list.len() == 2 && (list[0].is_symbol("+") || list[0].is_symbol("-")) { list = &list[1..]; }
    if list.len() != 1 { return false; }
    let token = list[0];
    token.kind == SqlTokKind::String || token.is_word("NULL") || token.kind == SqlTokKind::Symbol && {
        let parts = token.text.split('.').collect::<Vec<_>>();
        parts.len() <= 2 && parts.iter().all(|part| !part.is_empty() && part.bytes().all(|b| b.is_ascii_digit()))
    }
}

#[derive(Clone, Copy, PartialEq)]
pub enum SqlTokKind { Word, Ident, String, Symbol }

pub struct SqlTok {
    pub kind: SqlTokKind,
    pub text: String,
    pub depth: i32,
    /// Offset in chars into the statement, so a reader can quote the token as written.
    pub start: usize,
}

impl SqlTok {
    pub fn is_word(&self, word: &str) -> bool {
        self.kind == SqlTokKind::Word && self.text.eq_ignore_ascii_case(word)
    }

    pub fn is_any(&self, words: &[&str]) -> bool {
        self.kind == SqlTokKind::Word && words.iter().any(|word| self.text.eq_ignore_ascii_case(word))
    }

    pub fn is_symbol(&self, text: &str) -> bool {
        self.kind == SqlTokKind::Symbol && self.text == text
    }
}

pub fn sql_tokens(sql: &str) -> Vec<SqlTok> {
    let chars: Vec<char> = sql.chars().collect();
    let mut tokens = Vec::new();
    let mut depth = 0i32;
    let mut index = 0;
    while index < chars.len() {
        let char = chars[index];
        let next = chars.get(index + 1).copied();
        if char == '-' && next == Some('-') {
            index += 2;
            while index < chars.len() && chars[index] != '\n' { index += 1; }
            if index < chars.len() { index += 1; }
            continue;
        }
        if char == '/' && next == Some('*') {
            index += 2;
            while index + 1 < chars.len() && !(chars[index] == '*' && chars[index + 1] == '/') { index += 1; }
            index = (index + 2).min(chars.len());
            continue;
        }
        if char == '\'' || char == '"' || char == '`' || char == '[' {
            let close = if char == '[' { ']' } else { char };
            let mut end = index + 1;
            let mut text = String::new();
            while end < chars.len() {
                if chars[end] == close {
                    if close != ']' && chars.get(end + 1) == Some(&close) {
                        text.push(close);
                        end += 2;
                        continue;
                    }
                    break;
                }
                text.push(chars[end]);
                end += 1;
            }
            let span_end = (end + 1).min(chars.len());
            tokens.push(if char == '\'' {
                SqlTok { kind: SqlTokKind::String, text: String::new(), depth, start: index }
            } else {
                SqlTok { kind: SqlTokKind::Ident, text, depth, start: index }
            });
            index = span_end;
            continue;
        }
        if is_sql_word_start(char) {
            let mut end = index + 1;
            while end < chars.len() && is_sql_word_cont(chars[end]) { end += 1; }
            tokens.push(SqlTok { kind: SqlTokKind::Word, text: chars[index..end].iter().collect(), depth, start: index });
            index = end;
            continue;
        }
        if char.is_ascii_digit() {
            let mut end = index + 1;
            while end < chars.len() && (chars[end].is_ascii_alphanumeric() || chars[end] == '.' || chars[end] == '_') {
                end += 1;
            }
            tokens.push(SqlTok { kind: SqlTokKind::Symbol, text: chars[index..end].iter().collect(), depth, start: index });
            index = end;
            continue;
        }
        if char.is_whitespace() {
            index += 1;
            continue;
        }
        if char == ')' { depth = (depth - 1).max(0); }
        tokens.push(SqlTok { kind: SqlTokKind::Symbol, text: char.to_string(), depth, start: index });
        if char == '(' { depth += 1; }
        index += 1;
    }
    tokens
}

pub fn is_sql_word_start(char: char) -> bool {
    char.is_ascii_alphabetic() || char == '_' || (char as u32) >= 0x80
}

pub fn is_sql_word_cont(char: char) -> bool {
    char.is_ascii_alphanumeric() || char == '_' || char == '$' || (char as u32) >= 0x80
}

pub fn initialize_database(path: &Path) -> Result<()> {
    let connection = Connection::open(path)?;
    connection.execute_batch("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;")?;
    Ok(())
}

/// Moves a Database written before WAL mode, or arrived from a snapshot or a
/// backup, into it. The mode is stored in the file, so this runs once. A
/// switch that meets another connection is left for the next one: the
/// Database still answers in its old mode meanwhile.
pub fn use_wal(db: &Connection) {
    let mode = db.query_row("PRAGMA journal_mode", [], |row| row.get::<_, String>(0));
    if !mode.is_ok_and(|mode| mode.eq_ignore_ascii_case("wal")) {
        let _ = db.query_row("PRAGMA journal_mode=WAL", [], |_| Ok(()));
    }
}

/// Puts `replacement` where the Database at `path` was. The old file's WAL
/// and shared-memory index go first: left beside the new file, SQLite would
/// read the old file's pages into it. The caller holds the Database's lock
/// alone, so no connection has them open.
pub fn replace_database_file(replacement: &Path, path: &Path) -> std::io::Result<()> {
    for suffix in ["-wal", "-shm"] {
        let mut sidecar = path.as_os_str().to_owned();
        sidecar.push(suffix);
        match std::fs::remove_file(&sidecar) {
            Err(error) if error.kind() != std::io::ErrorKind::NotFound => return Err(error),
            _ => {}
        }
    }
    std::fs::rename(replacement, path)
}

/// Writes a sibling temp file and renames it over `path`, so readers never see
/// a truncated file.
pub async fn write_atomic(path: &Path, bytes: &[u8]) -> std::io::Result<()> {
    if let Some(parent) = path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    let name = path.file_name().and_then(|name| name.to_str()).unwrap_or("file");
    let temp = path.with_file_name(format!(".{name}.tmp-{}", Uuid::new_v4()));
    if let Err(error_value) = tokio::fs::write(&temp, bytes).await {
        let _ = tokio::fs::remove_file(&temp).await;
        return Err(error_value);
    }
    if let Err(error_value) = tokio::fs::rename(&temp, path).await {
        let _ = tokio::fs::remove_file(&temp).await;
        return Err(error_value);
    }
    Ok(())
}

pub fn valid_file_id(id: &str) -> bool {
    id.len() == 36
        && id
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit() || byte == b'-')
}

pub fn file_visibility(file: &Value) -> &'static str {
    if file.get("visibility").and_then(Value::as_str) == Some("public") {
        "public"
    } else {
        "private"
    }
}

pub fn file_owner(file: &Value) -> Option<&str> {
    file.get("ownerId").and_then(Value::as_str)
}

pub fn accepted_owner_id(value: &str) -> bool {
    (1..=80).contains(&value.len())
        && value
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'_' || byte == b'-')
}

pub fn app_user_files(deployment: &Deployment) -> bool {
    deployment.modules.get("files").is_some_and(|state| state["fileAccess"] == "app-users")
}

pub fn file_readable(deployment: &Deployment, file: &Value, actor_id: Option<&str>) -> bool {
    if app_user_files(deployment) {
        return actor_id.is_some();
    }
    if file_visibility(file) == "public" {
        return !is_private(deployment) || actor_id.is_some();
    }
    actor_id.is_some() && file_owner(file) == actor_id
}

pub fn file_view(deployment: &Deployment, file: &Value, actor_id: Option<&str>) -> Value {
    let mut view = file.clone();
    if let Some(object) = view.as_object_mut() {
        object.remove("url");
        object.remove("sha256");
        if app_user_files(deployment) {
            object.insert("visibility".into(), json!("app-users"));
        }
        if file_owner(file) != actor_id {
            object.remove("ownerId");
        }
    }
    view
}

pub fn encode_base64(bytes: &[u8]) -> String {
    const ALPHABET: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut output = String::with_capacity(bytes.len().div_ceil(3) * 4);
    for chunk in bytes.chunks(3) {
        let a = chunk[0] as usize;
        let b = chunk.get(1).copied().unwrap_or(0) as usize;
        let c = chunk.get(2).copied().unwrap_or(0) as usize;
        output.push(ALPHABET[a >> 2] as char);
        output.push(ALPHABET[((a & 3) << 4) | (b >> 4)] as char);
        output.push(if chunk.len() > 1 {
            ALPHABET[((b & 15) << 2) | (c >> 6)] as char
        } else {
            '='
        });
        output.push(if chunk.len() > 2 {
            ALPHABET[c & 63] as char
        } else {
            '='
        });
    }
    output
}

pub fn decode_base64(value: &str) -> Result<Vec<u8>> {
    let normalized = value
        .trim()
        .trim_start_matches("data:")
        .split_once(',')
        .map(|(_, encoded)| encoded)
        .unwrap_or(value);
    let mut output = Vec::with_capacity(normalized.len() * 3 / 4);
    let mut accumulator = 0u32;
    let mut bits = 0;
    for byte in normalized
        .bytes()
        .filter(|byte| *byte != b'=' && !byte.is_ascii_whitespace())
    {
        let value = match byte {
            b'A'..=b'Z' => byte - b'A',
            b'a'..=b'z' => byte - b'a' + 26,
            b'0'..=b'9' => byte - b'0' + 52,
            b'+' | b'-' => 62,
            b'/' | b'_' => 63,
            _ => anyhow::bail!("Initial database must be base64."),
        };
        accumulator = (accumulator << 6) | value as u32;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            output.push((accumulator >> bits) as u8);
        }
    }
    Ok(output)
}

pub use konae_backup::safe_relative_path;

/// Persists changes made to the applied Deployment while keeping editable settings intact.
pub async fn persist_deployment(state: &AppState, deployment: &Deployment) -> Result<()> {
    persist_applied(state, deployment, None, None).await
}

/// Records the artifact currently in a folder without replacing its saved draft.
pub async fn persist_folder_snapshot(state: &AppState, deployment: &Deployment, artifact_digest: &str) -> Result<()> {
    persist_applied(state, deployment, Some(artifact_digest), None).await
}

pub async fn persist_folder_snapshot_with_transforms(state: &AppState, deployment: &Deployment, artifact_digest: &str, schema_transforms: Option<&str>) -> Result<()> {
    persist_applied(state, deployment, Some(artifact_digest), Some(schema_transforms)).await
}

async fn persist_applied(state: &AppState, deployment: &Deployment, artifact_digest: Option<&str>, schema_transforms: Option<Option<&str>>) -> Result<()> {
    let mut settings = match Settings::read(&state.data_root, &deployment.id) {
        Ok(settings) => settings,
        Err(_) if !layout::settings(&state.data_root, &deployment.id).exists() => Settings::of(deployment),
        Err(error) => return Err(error),
    };
    let record_path = layout::record(&state.data_root, &deployment.id);
    let installed = match tokio::fs::read(&record_path).await {
        Ok(bytes) => serde_json::from_slice::<Installed>(&bytes).context("The installed Deployment record is malformed.")?,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Installed {
            hostname: deployment.hostname.clone(), created_at: deployment.created_at,
            released_at: Some(deployment.released_at), source_digest: deployment.source_digest.clone(),
            actions: deployment.actions.clone(), artifact_version: deployment.artifact_version.clone(), released: None,
        },
        Err(error) => return Err(error.into()),
    };
    let recovered = crate::sources::capture_released_state(&state.data_root, &deployment.id, &settings, &installed)?;
    settings.signup_policy = deployment.signup_policy.clone();
    settings.sign_in_methods = deployment.sign_in_methods.clone();
    settings.contact_email = deployment.contact_email.clone();
    settings.manifest = crate::sources::manifest_without_runtime(&settings.manifest);
    let mut released = released_settings(deployment);
    if released.schema_sql.trim().is_empty() { released.schema_sql = recovered.schema_sql; }
    if let Some(schema_transforms) = schema_transforms {
        released.schema_transforms = schema_transforms.map(str::to_owned);
    } else if released.schema_transforms.is_none() {
        released.schema_transforms = recovered.schema_transforms;
    }
    if released.source_digest.is_none() { released.source_digest = recovered.source_digest; }
    released.artifact_digest = artifact_digest.map(str::to_owned).or(recovered.artifact_digest);
    settings.released = Some(released.clone());
    persist_settings_and_record(state, deployment, settings, released).await
}

/// Persists the new source and artifact state after a successful release.
pub async fn persist_release(state: &AppState, deployment: &Deployment, artifact_digest: &str, directories: &[String], schema_transforms: Option<&str>, initial_modules: Option<&std::collections::BTreeMap<String, Value>>) -> Result<()> {
    let mut settings = Settings::of(deployment);
    modules::preserve_release_state(&mut settings, Settings::read(&state.data_root, &deployment.id).ok(), initial_modules);
    settings.directories = directories.to_vec();
    let mut released = settings.released.clone().expect("Settings::of records released settings");
    released.artifact_digest = Some(artifact_digest.to_owned());
    released.schema_transforms = schema_transforms.map(str::to_owned);
    settings.released = Some(released.clone());
    persist_settings_and_record(state, deployment, settings, released).await
}

async fn persist_settings_and_record(state: &AppState, deployment: &Deployment, settings: Settings, released: ReleasedSettings) -> Result<()> {
    let settings_path = layout::settings(&state.data_root, &deployment.id);
    let record_path = layout::record(&state.data_root, &deployment.id);
    let settings_before = match tokio::fs::read(&settings_path).await {
        Ok(bytes) => Some(bytes),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
        Err(error) => return Err(error.into()),
    };
    let record_before = match tokio::fs::read(&record_path).await {
        Ok(bytes) => Some(bytes),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
        Err(error) => return Err(error.into()),
    };
    let settings_bytes = settings.folder_bytes()?;
    let installed = Installed {
        hostname: deployment.hostname.clone(), created_at: deployment.created_at,
        released_at: Some(deployment.released_at), source_digest: deployment.source_digest.clone(),
        actions: deployment.actions.clone(), artifact_version: deployment.artifact_version.clone(), released: Some(released),
    };
    let record_bytes = serde_json::to_vec_pretty(&installed)?;
    tokio::fs::create_dir_all(layout::private(&state.data_root, &deployment.id)).await?;
    write_atomic(&settings_path, &settings_bytes).await?;
    if let Err(error) = write_atomic(&record_path, &record_bytes).await {
        let settings_restore = restore_optional(&settings_path, settings_before.as_deref()).await;
        let record_restore = restore_optional(&record_path, record_before.as_deref()).await;
        if let Err(restore) = settings_restore { anyhow::bail!("Writing the Deployment record failed: {error}. Restoring konae.json failed: {restore:#}"); }
        if let Err(restore) = record_restore { anyhow::bail!("Writing the Deployment record failed: {error}. Restoring the previous record failed: {restore:#}"); }
        return Err(error.into());
    }
    Ok(())
}

async fn restore_optional(path: &Path, bytes: Option<&[u8]>) -> Result<()> {
    match bytes {
        Some(bytes) => write_atomic(path, bytes).await?,
        None => match tokio::fs::remove_file(path).await {
            Ok(()) => {},
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {},
            Err(error) => return Err(error.into()),
        },
    }
    Ok(())
}

/// Writes the Deployment's two files without a runtime, for tests that seed a volume.
#[cfg(any(test, feature = "testing"))]
pub fn write_record_for_test(root: &Path, deployment: &Deployment) {
    let installed = Installed {
        hostname: deployment.hostname.clone(),
        created_at: deployment.created_at,
        released_at: Some(deployment.released_at),
        source_digest: deployment.source_digest.clone(),
        actions: deployment.actions.clone(),
        artifact_version: deployment.artifact_version.clone(),
        released: Some(released_settings(deployment)),
    };
    std::fs::create_dir_all(layout::private(root, &deployment.id)).unwrap();
    std::fs::write(layout::settings(root, &deployment.id), Settings::of(deployment).folder_bytes().unwrap()).unwrap();
    std::fs::write(layout::record(root, &deployment.id), serde_json::to_vec(&installed).unwrap()).unwrap();
}

/// Reads every published app on the volume. A folder without a Deployment
/// record is an app that was never published. A Kernel on a fresh volume
/// starts empty; the `restore` command installs copied folders first.
pub async fn load_deployments(root: &Path, public_origin: &str) -> Result<HashMap<String, Deployment>> {
    let mut result = HashMap::new();
    let mut entries = tokio::fs::read_dir(layout::apps(root)).await?;
    while let Some(entry) = entries.next_entry().await? {
        let Some(id) = entry.file_name().to_str().map(str::to_owned) else { continue };
        let Ok(bytes) = tokio::fs::read(layout::record(root, &id)).await else { continue };
        let installed: Installed = serde_json::from_slice(&bytes).with_context(|| format!("{} is not a Deployment record.", layout::record(root, &id).display()))?;
        if let Err(error) = crate::folder::decide_app_modules(root, &id, crate::folder::ModuleSource::Installed).await {
            eprintln!("konae: skipping apps/{id}: {error:#}");
            continue;
        }
        let settings = match Settings::read(root, &id) {
            Ok(settings) => settings,
            Err(error) => {
                eprintln!("konae: skipping apps/{id}: {} is not readable: {error:#}", layout::settings(root, &id).display());
                continue;
            }
        };
        let deployment = settings.deployment(installed, public_origin);
        result.insert(deployment.hostname.clone(), deployment);
    }
    Ok(result)
}

pub use konae_backup::read_s3_bytes;

pub use konae_backup::list_s3_keys;

/// The Deployment a request is for. A generated hostname and a verified
/// alias answer first, as before. Otherwise the request is on the path host,
/// and `path::route` has put the Deployment it resolved in `RESOLVED_HEADER`,
/// which the client cannot set because the route removes it first.
pub async fn deployment_for(state: &AppState, headers: &HeaderMap) -> Option<Deployment> {
    if let Some(deployment) = deployment_for_host(state, headers).await {
        return Some(deployment);
    }
    let id = headers.get(path::RESOLVED_HEADER)?.to_str().ok()?;
    deployment_by_id(state, id).await
}

/// The Deployment for a generated hostname or a verified alias. The
/// installation's own hosts answer as no app, whatever the map holds, so a
/// stored record on one of them cannot take the owner door.
pub async fn deployment_for_host(state: &AppState, headers: &HeaderMap) -> Option<Deployment> {
    let host = headers
        .get(header::HOST)?
        .to_str()
        .ok()?
        .split(':')
        .next()?;
    if domain::Rules::of(state).installation_hosts.iter().any(|own| own.eq_ignore_ascii_case(host.trim_end_matches('.'))) {
        return None;
    }
    let deployments = state.deployments.read().await;
    if let Some(deployment) = deployments.get(host) {
        return Some(deployment.clone());
    }

    let id = domain::serving(state, host)?;
    deployments.values().find(|deployment| deployment.id == id).cloned()
}

/// The Deployment a request answers, before `path::route` strips its prefix.
/// The security headers layer runs outside the router and reads the path itself.
pub async fn deployment_for_request(state: &AppState, headers: &HeaderMap, path: &str) -> Option<Deployment> {
    if let Some(deployment) = deployment_for_host(state, headers).await {
        return Some(deployment);
    }
    let id = path::resolve(state, headers, path).await?.deployment_id?;
    deployment_by_id(state, &id).await
}

pub async fn deployment_by_id(state: &AppState, id: &str) -> Option<Deployment> {
    state.deployments.read().await.values().find(|deployment| deployment.id == id).cloned()
}

/// Fails closed: a Deployment is public only when its manifest says "public",
/// so a record with no visibility or an unknown one needs a login.
    /// The Signup Policy as `project_inspect.deployment.signupPolicy` returns it.
pub fn signup_policy_value(deployment: &Deployment) -> Value {
    json!({"deploymentId":deployment.id,"visibility":if is_private(deployment) { "private" } else { "public" },"mode":deployment.signup_policy.mode,"allowlist":deployment.signup_policy.allowlist})
}

/// Sets who may create an account in the app `id`, as Konae's
/// `module_set` on auth and the `kernel` binary's `signup-policy` both do.
/// The entries stay as they are when `entries` is `None`. The change lands
/// in `konae.json`, which a running `kernel` binary follows, and the answer
/// is `signup_policy_value` with `previousMode`.
pub async fn set_signup_policy(state: &AppState, id: &str, mode: SignupMode, entries: Option<Vec<String>>) -> Result<Value> {
    let served = |deployments: &HashMap<String, Deployment>| {
        find_project_deployment(deployments, id).ok_or_else(|| anyhow::anyhow!("The app {id} is not published."))
    };
    let current = served(&*state.deployments.read().await)?;
    let entries = entries.unwrap_or_else(|| current.signup_policy.allowlist.clone());
    let policy = SignupPolicy::from_input(mode, &entries).map_err(anyhow::Error::msg)?;


    let _guard = database_lock(state, &format!("project:{}", current.project_id)).await;
    let mut updated = served(&*state.deployments.read().await)?;
    let previous = updated.signup_policy.mode;
    updated.signup_policy = policy;
    persist_deployment(state, &updated).await?;
    state.deployments.write().await.insert(updated.hostname.clone(), updated.clone());
    let mut value = signup_policy_value(&updated);
    value["previousMode"] = json!(previous);
    Ok(value)
}

pub fn is_private(deployment: &Deployment) -> bool {
    deployment
        .manifest
        .get("visibility")
        .and_then(Value::as_str)
        != Some("public")
}


pub fn open_auth(
    state: &AppState,
    deployment: &Deployment,
) -> std::result::Result<AuthService, AuthError> {
    accounts::app_store(state, deployment)
}

pub async fn authenticate_deployment(
    state: &AppState,
    deployment: &Deployment,
    headers: &HeaderMap,
) -> std::result::Result<Option<AuthUser>, Response> {
    let token = headers.get(header::AUTHORIZATION).and_then(|value| value.to_str().ok()).and_then(|value| value.strip_prefix("Bearer ")).map(str::to_owned)
        .or_else(|| cookie_value(headers, &app_cookie_name(state, &deployment.id, headers)));
    let Some(token) = token.filter(|token| !token.is_empty() && token.len() <= 128) else {
        return Ok(None);
    };
    let path = layout::identity(&state.data_root, &deployment.id);
    let scope = auth::deployment_scope(&deployment.id);
    let verification = state.accounts.verification;
    runtime_identity(state, &deployment.id, move || auth::runtime_session(&path, &scope, verification, &token))
        .await?
        .map_err(|e| error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()))
}

/// The blocking task owns the lock until SQLite closes or returns its connection.
async fn runtime_identity<T: Send + 'static>(
    state: &AppState,
    deployment: &str,
    work: impl FnOnce() -> T + Send + 'static,
) -> std::result::Result<T, Response> {
    let guard = named_lock(state, &format!("identity:{deployment}"), false).await;
    let permit = state.guards.statement_permit(deployment).await.map_err(http::rate_limited)?;
    tokio::task::spawn_blocking(move || {
        let _guard = guard;
        let _permit = permit;
        work()
    })
    .await
    .map_err(|e| error(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()))
}

/// The app session cookie's name for a request to a Deployment.
///
/// A generated hostname and a verified alias keep their own origin, so the
/// name is the one they always had, with `__Host-` under HTTPS. A path address
/// shares `<domain>` with every other app and the home, so the name carries
/// the Deployment id. The cookie is `Path=/` because one app answers on two
/// addresses, `/p/<id>` and `/p/<name>`, and a `Path=/p/<segment>/` cookie set
/// on one would not reach the other. A `__Host-` name also needs `Path=/`. The
/// per-app name keeps two apps' sessions from overwriting each other; it does
/// not keep a hostile app out, since every path shares one origin (ADR-0014).
pub fn app_cookie_name(state: &AppState, deployment_id: &str, headers: &HeaderMap) -> String {
    let https = state.public_origin.starts_with("https://");
    if path::on_path_host(state, headers) {
        return format!("{}konae_app_session_{deployment_id}", if https { "__Secure-" } else { "" });
    }
    if https { "__Host-konae_app_session" } else { "konae_app_session" }.to_owned()
}

pub fn cookie_value(headers: &HeaderMap, name: &str) -> Option<String> {
    headers
        .get(header::COOKIE)?
        .to_str()
        .ok()?
        .split(';')
        .map(str::trim)
        .find_map(|part| part.strip_prefix(&format!("{name}=")).map(str::to_owned))
}

pub fn same_origin(headers: &HeaderMap) -> bool {
    let host = headers
        .get(header::HOST)
        .and_then(|v| v.to_str().ok());
    if let Some(site) = headers.get("sec-fetch-site").and_then(|v| v.to_str().ok()) {
        if site == "cross-site" {
            return false;
        }
    }
    match (
        headers.get(header::ORIGIN).and_then(|v| v.to_str().ok()),
        host,
    ) {
        (Some(origin), Some(host)) => url::Url::parse(origin).ok().is_some_and(|origin| {
            let expected = url::Url::parse(&format!("{}://{host}", origin.scheme())).ok();
            expected.is_some_and(|expected| origin.origin() == expected.origin())
        }),
        (Some(_), None) => false,
        (None, _) => true,
    }
}

/// The longest LIKE or GLOB pattern an action may compare.
pub const MAX_LIKE_PATTERN_BYTES: i32 = 500;

/// Each app database may grow to this size. Writes past it fail with
/// "database or disk is full".
pub const MAX_APP_DATABASE_BYTES: u64 = 256 * 1024 * 1024;

/// Caps the database file behind this connection. SQLite keeps the setting per
/// connection, so every connection that may write needs it.
pub fn limit_database_size(db: &Connection, max_bytes: u64) -> Result<()> {
    let page_size: u64 = db.query_row("PRAGMA page_size", [], |row| row.get(0))?;
    let pages = (max_bytes / page_size.max(1)).max(1);
    db.query_row(&format!("PRAGMA max_page_count = {pages}"), [], |_| Ok(()))?;
    Ok(())
}

/// SQL functions no app statement or schema may call. They reach the file
/// system, load native code, or swap full-text tokenizers by pointer.
pub const DENIED_FUNCTIONS: &[&str] = &[
    "load_extension",
    "readfile",
    "writefile",
    "edit",
    "fts3_tokenizer",
];

pub fn denied_function(name: &str) -> bool {
    DENIED_FUNCTIONS.contains(&name.to_ascii_lowercase().as_str())
}

pub fn restrict_database(db: &Connection) -> Result<()> {
    db.busy_timeout(std::time::Duration::from_secs(5))?;
    configure_database_limits(db)?;
    arm_deadline(db)?;
    install_database_authorizer(db, None)
}

pub(crate) fn restrict_function_database(db: &Connection, receipts: Arc<std::sync::atomic::AtomicBool>) -> Result<()> {
    db.busy_timeout(std::time::Duration::ZERO)?;
    db.pragma_update(None, "foreign_keys", true)?;
    configure_database_limits(db)?;
    install_database_authorizer(db, Some(receipts))
}

fn configure_database_limits(db: &Connection) -> Result<()> {
    db.pragma_update(None, "synchronous", "NORMAL")?;
    use_wal(db);

    limit_database_size(db, MAX_APP_DATABASE_BYTES)?;
    db.set_limit(rusqlite::limits::Limit::SQLITE_LIMIT_LENGTH, 2 * 1024 * 1024)?;
    db.set_limit(rusqlite::limits::Limit::SQLITE_LIMIT_SQL_LENGTH, 100_000)?;
    db.set_limit(rusqlite::limits::Limit::SQLITE_LIMIT_ATTACHED, 0)?;



    db.set_limit(rusqlite::limits::Limit::SQLITE_LIMIT_LIKE_PATTERN_LENGTH, MAX_LIKE_PATTERN_BYTES)?;
    Ok(())
}

fn install_database_authorizer(db: &Connection, receipts: Option<Arc<std::sync::atomic::AtomicBool>>) -> Result<()> {
    let function_connection = receipts.is_some();
    let reserved = move |name: &str, accessor: Option<&str>| {
        schema_transform::is_internal_table(name)
            && !(name.eq_ignore_ascii_case("__konae_function_receipts")
                && accessor.is_none()
                && receipts.as_ref().is_some_and(|allowed| allowed.load(std::sync::atomic::Ordering::SeqCst)))
    };
    db.authorizer(Some(move |context: AuthContext<'_>| {
        if function_connection && context.accessor.is_some() { return Authorization::Deny; }
        match context.action {
        AuthAction::Attach { .. } | AuthAction::Detach { .. } => Authorization::Deny,
        AuthAction::CreateTable { table_name, .. } if reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::CreateIndex { index_name, table_name } if reserved(index_name, context.accessor) || reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::AlterTable { table_name, .. } if reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::DropTable { table_name } if reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::DropIndex { index_name, table_name } if reserved(index_name, context.accessor) || reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::Read { table_name, .. } if reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::Insert { table_name } if reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::Update { table_name, .. } if reserved(table_name, context.accessor) => Authorization::Deny,
        AuthAction::Delete { table_name } if reserved(table_name, context.accessor) => Authorization::Deny,
        // Konae runs no triggers or views, and Studio and the schema change
        // use this connection too, so neither can add one the Gate never saw.
        AuthAction::CreateTrigger { .. } | AuthAction::CreateTempTrigger { .. } => Authorization::Deny,
        AuthAction::CreateView { .. } | AuthAction::CreateTempView { .. } => Authorization::Deny,
        AuthAction::Pragma { pragma_name, .. } if !["table_info", "table_xinfo", "index_list", "index_info", "foreign_key_list", "foreign_key_check", "integrity_check", "quick_check"].contains(&pragma_name.to_ascii_lowercase().as_str()) => Authorization::Deny,
        AuthAction::Function { function_name } if denied_function(function_name) => Authorization::Deny,
        _ => Authorization::Allow,
        }
    }))?;
    Ok(())
}

/// Interrupts any statement on `db` that runs past 2 seconds from now.
pub fn arm_deadline(db: &Connection) -> rusqlite::Result<()> {
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
    db.progress_handler(10_000, Some(move || std::time::Instant::now() > deadline))
}

const QUERY_RESULT_TOO_LARGE: &str = "Query result exceeds 2 MiB or 1000 rows.";

/// What an oversized action result answers when a column is read.
#[derive(Debug)]
struct ResultTooLarge;

impl std::fmt::Display for ResultTooLarge {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(QUERY_RESULT_TOO_LARGE)
    }
}

impl std::error::Error for ResultTooLarge {}

/// What a result has cost as JSON so far, counted as its columns are read.
pub struct ResultBudget {
    bytes: usize,
    rows: usize,
}

impl ResultBudget {
    fn reserve(&mut self, bytes: usize) -> bool {
        self.bytes = self.bytes.saturating_add(bytes);
        self.within_limit()
    }

    fn begin_row(&mut self, row_overhead: usize) -> bool {
        self.bytes = self.bytes
            .saturating_add(usize::from(self.rows > 0))
            .saturating_add(row_overhead);
        self.rows = self.rows.saturating_add(1);
        self.within_limit()
    }

    fn spend_column(&mut self, name: &str, value: rusqlite::types::ValueRef<'_>, first: bool) -> bool {
        self.bytes = self.bytes
            .saturating_add(usize::from(!first))
            .saturating_add(json_string_cost(name.as_bytes()))
            .saturating_add(1)
            .saturating_add(sql_json_cost(value));
        self.within_limit()
    }

    fn spend_value(&mut self, value: rusqlite::types::ValueRef<'_>) -> bool {
        self.bytes = self.bytes.saturating_add(sql_json_cost(value));
        self.within_limit()
    }

    fn within_limit(&self) -> bool {
        self.bytes <= 2 * 1024 * 1024
    }

    /// Adds the serialized cost of a value without an object key.
    pub fn spend(&mut self, value: rusqlite::types::ValueRef<'_>) -> bool {
        self.spend_value(value)
    }
}

fn json_string_cost(bytes: &[u8]) -> usize {
    let mut cost = 2usize;
    let mut remaining = bytes;
    while !remaining.is_empty() {
        match std::str::from_utf8(remaining) {
            Ok(valid) => {
                cost = cost.saturating_add(valid.chars().map(json_char_cost).sum::<usize>());
                break;
            }
            Err(error_value) => {
                let valid = &remaining[..error_value.valid_up_to()];
                cost = cost.saturating_add(
                    std::str::from_utf8(valid)
                        .expect("Utf8Error marks the prefix as valid")
                        .chars()
                        .map(json_char_cost)
                        .sum::<usize>(),
                );
                remaining = &remaining[error_value.valid_up_to()..];
                let invalid_bytes = error_value.error_len().unwrap_or(remaining.len()).max(1);
                cost = cost.saturating_add(invalid_bytes.saturating_mul(3));
                remaining = &remaining[invalid_bytes..];
            }
        }
    }
    cost
}

fn json_char_cost(character: char) -> usize {
    match character {
        '"' | '\\' | '\u{8}' | '\u{c}' | '\n' | '\r' | '\t' => 2,
        '\u{0}'..='\u{1f}' => 6,
        _ => character.len_utf8(),
    }
}

fn sql_json_cost(value: rusqlite::types::ValueRef<'_>) -> usize {
    use rusqlite::types::ValueRef;
    match value {
        ValueRef::Null => 4,
        ValueRef::Integer(value) => value.to_string().len(),
        ValueRef::Real(value) => serde_json::Number::from_f64(value)
            .map(|number| number.to_string().len())
            .unwrap_or(4),
        ValueRef::Text(text) => json_string_cost(text),
        ValueRef::Blob(blob) => blob.len().saturating_mul(2).saturating_add(2),
    }
}

fn browse_column_json_cost(column: &Value) -> usize {
    let name = column["name"].as_str().unwrap_or_default();
    let column_type = column["type"].as_str().unwrap_or_default();
    json_string_cost(name.as_bytes())
        .saturating_add(json_string_cost(column_type.as_bytes()))
        .saturating_add(column["defaultValue"].as_str().map(|value| json_string_cost(value.as_bytes())).unwrap_or(4))
        .saturating_add(69)
}

/// A row as a JSON object, or `None` once `budget` is spent. The columns
/// after the one that spent it are not read: SQLite expands a `zeroblob`
/// only when its column is read.
pub fn bounded_row(row: &rusqlite::Row<'_>, names: &[String], budget: &mut ResultBudget) -> rusqlite::Result<Option<Value>> {
    let mut object = serde_json::Map::new();
    if !budget.begin_row(2) {
        return Ok(None);
    }
    for (index, name) in names.iter().enumerate() {
        let value = row.get_ref(index)?;
        if !budget.spend_column(name, value, index == 0) {
            return Ok(None);
        }
        object.insert(name.clone(), sql_json(value));
    }
    Ok(Some(Value::Object(object)))
}

impl Default for ResultBudget {
    fn default() -> Self {
        Self { bytes: 2, rows: 0 }
    }
}

pub fn bounded_rows(rows: impl Iterator<Item = rusqlite::Result<Value>>) -> Result<Vec<Value>> {
    let mut values = Vec::new();
    let mut bytes = 0;
    for row in rows.take(1001) {
        let row = row?;
        bytes += serde_json::to_vec(&row)?.len();
        anyhow::ensure!(bytes <= 2 * 1024 * 1024 && values.len() < 1000, "{QUERY_RESULT_TOO_LARGE}");
        values.push(row);
    }
    Ok(values)
}

pub fn auth_error(error_value: AuthError) -> Response {
    let status = match error_value {
        AuthError::InvalidEmail | AuthError::WeakPassword => StatusCode::BAD_REQUEST,
        AuthError::EmailTaken | AuthError::AccountExists => StatusCode::CONFLICT,
        AuthError::InvitedEmailDiffers => StatusCode::FORBIDDEN,
        AuthError::InvalidCredentials => StatusCode::UNAUTHORIZED,
        AuthError::AccountPending
        | AuthError::AccountSuspended
        | AuthError::SignupClosed
        | AuthError::AdmissionRefused(_) => {
            StatusCode::FORBIDDEN
        }
        AuthError::InvalidChallenge => StatusCode::GONE,
        AuthError::MailUnavailable | AuthError::MailBlocked(_) => StatusCode::SERVICE_UNAVAILABLE,
        AuthError::MailLimit(_) => StatusCode::TOO_MANY_REQUESTS,
        AuthError::VerificationRequired
        | AuthError::Storage(_)
        | AuthError::PasswordHash => StatusCode::INTERNAL_SERVER_ERROR,
    };
    error(status, &error_value.to_string())
}

pub fn json_sql(value: &Value) -> std::result::Result<SqlValue, String> {
    match value {
        Value::Null => Ok(SqlValue::Null),
        Value::String(value) => Ok(SqlValue::Text(value.clone())),
        Value::Bool(value) => Ok(SqlValue::Integer(*value as i64)),
        Value::Number(value) => value
            .as_i64()
            .map(SqlValue::Integer)
            .or_else(|| value.as_f64().map(SqlValue::Real))
            .ok_or_else(|| "Invalid number.".into()),
        _ => Err("Literal values must be scalar.".into()),
    }
}

#[cfg(any(test, feature = "testing"))]
thread_local! {
    /// Columns this thread has turned into JSON, so a test can see where a
    /// result stopped being read.
    pub static COLUMNS_CONVERTED: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

pub fn sql_json(value: rusqlite::types::ValueRef<'_>) -> Value {
    #[cfg(any(test, feature = "testing"))]
    COLUMNS_CONVERTED.with(|count| count.set(count.get() + 1));
    match value {
        rusqlite::types::ValueRef::Null => Value::Null,
        rusqlite::types::ValueRef::Integer(value) => json!(value),
        rusqlite::types::ValueRef::Real(value) => json!(value),
        rusqlite::types::ValueRef::Text(value) => {
            Value::String(String::from_utf8_lossy(value).into_owned())
        }
        rusqlite::types::ValueRef::Blob(value) => Value::String(hex::encode(value)),
    }
}

pub fn deployment_url(origin: &str, hostname: &str) -> String {
    let scheme = origin.split("://").next().unwrap_or("http");
    let port = origin
        .split("://")
        .nth(1)
        .and_then(|rest| rest.rsplit_once(':').map(|(_, port)| port));
    format!(
        "{scheme}://{hostname}{}",
        port.map(|value| format!(":{value}")).unwrap_or_default()
    )
}

pub fn safe_slug(value: &str) -> String {
    value
        .chars()
        .map(|character| {
            if character.is_ascii_alphanumeric() {
                character.to_ascii_lowercase()
            } else {
                '-'
            }
        })
        .collect::<String>()
        .trim_matches('-')
        .to_string()
}
pub fn content_type(path: &str) -> &'static str {
    let name = path.rsplit('/').next().unwrap_or(path);
    let extension = name
        .rsplit_once('.')
        .map(|(_, extension)| extension.to_ascii_lowercase())
        .unwrap_or_default();
    match extension.as_str() {
        "html" | "htm" => "text/html; charset=utf-8",
        "js" | "mjs" => "text/javascript; charset=utf-8",
        "css" => "text/css; charset=utf-8",
        "json" | "map" => "application/json",
        "webmanifest" => "application/manifest+json",
        "txt" => "text/plain; charset=utf-8",
        "md" => "text/markdown; charset=utf-8",
        "csv" => "text/csv; charset=utf-8",
        "xml" => "application/xml; charset=utf-8",
        "rss" => "application/rss+xml; charset=utf-8",
        "atom" => "application/atom+xml; charset=utf-8",
        "svg" => "image/svg+xml",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "avif" => "image/avif",
        "ico" => "image/x-icon",
        "pdf" => "application/pdf",
        "mp4" => "video/mp4",
        "webm" => "video/webm",
        "mp3" => "audio/mpeg",
        "wasm" => "application/wasm",
        "woff2" => "font/woff2",
        "woff" => "font/woff",
        "ttf" => "font/ttf",
        "otf" => "font/otf",
        _ => "application/octet-stream",
    }
}

pub const DEFAULT_SETUP_KEY: &str = "local-development-key";

/// True for localhost, *.localhost and loopback IP addresses.
pub fn is_local_host(host: &str) -> bool {
    let host = host.to_ascii_lowercase();
    host == "localhost"
        || host.ends_with(".localhost")
        || host
            .trim_matches(['[', ']'])
            .parse::<std::net::IpAddr>()
            .is_ok_and(|address| address.is_loopback())
}
pub fn digest(bytes: &[u8]) -> String {
    hex::encode(<sha2::Sha256 as sha2::Digest>::digest(bytes))
}


pub fn base64url(value: &str) -> Result<Vec<u8>> {
    anyhow::ensure!(
        !value.is_empty()
            && value.len() % 4 != 1
            && value
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b"_-".contains(&b)),
        "Invalid base64url encoding."
    );
    let bytes = crate::decode_base64(value)?;
    let canonical = crate::encode_base64(&bytes)
        .trim_end_matches('=')
        .replace('+', "-")
        .replace('/', "_");
    anyhow::ensure!(canonical == value, "Noncanonical base64url encoding.");
    Ok(bytes)
}


/// The name this process was started as, `kernel` or `konae`, for the
/// commands an answer tells the operator to run.
pub fn program() -> String {
    std::env::args()
        .next()
        .and_then(|path| Path::new(&path).file_name().map(|name| name.to_string_lossy().into_owned()))
        .unwrap_or_else(|| "kernel".into())
}

pub fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as u64
}
pub fn env(name: &str, default: &str) -> String {
    std::env::var(name).unwrap_or_else(|_| default.into())
}
pub fn error(status: StatusCode, message: &str) -> Response {
    (status, Json(json!({"error": message}))).into_response()
}

/// A refused Capsule: `error` stays the sentence clients read, and `code` and
/// `hint` sit beside it (ADR-0004).
pub fn refusal_error(refused: &refusal::Refusal) -> Response {
    (StatusCode::BAD_REQUEST, Json(json!({"error": refused.message, "code": refused.code, "hint": refused.hint()}))).into_response()
}

#[cfg(any(test, feature = "testing"))]
#[allow(dead_code, unused_imports)]
pub mod tests {
    use super::*;

    #[test]
    fn the_transformation_journal_is_hidden_and_owner_sql_cannot_rewrite_it() {
        let root = std::env::temp_dir().join(format!("konae-schema-journal-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        let db = Connection::open(&path).unwrap();
        db.execute_batch("CREATE TABLE notes(id INTEGER PRIMARY KEY); CREATE TABLE __konae_schema_state(format_version INTEGER NOT NULL); CREATE TABLE __konae_schema_history(id TEXT);").unwrap();
        drop(db);
        let tables = inspect_database(&path).unwrap();
        assert_eq!(tables.len(), 1);
        assert_eq!(tables[0]["name"], "notes");
        assert!(run_admin_sql(&path, "SELECT * FROM __konae_schema_state").is_err());
        assert!(run_admin_sql(&path, "CREATE TABLE __konae_schema_state(id INTEGER)").is_err());
        assert!(run_admin_sql(&path, "DROP TABLE __konae_schema_history").is_err());
        assert!(run_admin_sql(&path, "ALTER TABLE notes RENAME TO __konae_schema_state").is_err());
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn deploy_input_reads_the_initial_signup_policy() {
        let input: DeployInput = serde_json::from_value(json!({
            "project": { "id": "app_1", "name": "App", "slug": "app", "files": {}, "manifest": {} },
            "visibility": "public",
            "artifact": { "version": 1, "entrypoint": "index.html", "files": { "index.html": "<main></main>" } },
            "initialSignupPolicy": { "mode": "closed", "allowlist": [] }
        })).unwrap();

        assert_eq!(input.initial_signup_policy.unwrap().mode, SignupMode::Closed);
    }

    #[tokio::test]
    async fn a_release_with_a_missing_page_template_uses_the_shared_case() {
        let cases: Value = serde_json::from_str(include_str!("page-release-cases.json")).unwrap();
        let case = &cases[0];
        let root = std::env::temp_dir().join(format!("konae-release-page-file-{}", Uuid::new_v4()));
        let state = test_state(&root);
        let body = release_body(
            "app_missing_page_file",
            "CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, title TEXT NOT NULL);",
            json!({
                "posts.head": {
                    "kind": "query", "access": "anonymous",
                    "statement": "SELECT title FROM posts LIMIT 10", "bindings": [],
                    "page": {"path": "/posts", "file": "post.html"}
                }
            }),
            "<main>posts</main>",
            None,
        );
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let status = response.status();
        let text = String::from_utf8(axum::body::to_bytes(response.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST, "{text}");
        assert!(text.contains(case["error"].as_str().unwrap()), "{text}");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_stored_deployment_on_the_editor_host_does_not_capture_the_owner_door() {
        let root = std::env::temp_dir().join(format!("konae-editor-host-{}", Uuid::new_v4()));
        let (state, _) = login_test_state(&root, "public").await;
        let mut deployment = state.deployments.read().await.values().next().cloned().unwrap();
        deployment.hostname = "app.apps.example.com".into();
        let state = AppState {
            public_origin: "http://app.apps.example.com".into(),
            host_suffix: "apps.example.com".into(),
            deployments: Arc::new(RwLock::new(HashMap::from([(deployment.hostname.clone(), deployment)]))),
            ..state
        };
        let mut headers = HeaderMap::new();
        headers.insert(header::HOST, HeaderValue::from_static("app.apps.example.com"));
        assert!(deployment_for_host(&state, &headers).await.is_none());
        assert!(deployment_for(&state, &headers).await.is_none());
        headers.insert(header::HOST, HeaderValue::from_static("app.apps.example.com:8080"));
        assert!(deployment_for_host(&state, &headers).await.is_none());
        // A page on the editor host is not an app origin either.
        headers.insert(header::ORIGIN, HeaderValue::from_static("http://app.apps.example.com"));
        assert!(!security::from_app_origin(&state, &headers).await);
        let _ = std::fs::remove_dir_all(root);
    }

    pub async fn login_test_state(root: &Path, visibility: &str) -> (AppState, HeaderMap) {
        let app_id = Uuid::new_v4().to_string();
        let deployment = Deployment {
            id: app_id.clone(),
            project_id: app_id,
            project_name: "Login test".into(),
            slug: "app".into(),
            url: "http://login-test.localhost".into(),
            created_at: now_ms(),
            released_at: 0,
            source_digest: None,
            manifest: json!({"visibility": visibility}),
            hostname: "login-test.localhost".into(),
            actions: "{}".into(),
            artifact_version: "v1".into(),
            signup_policy: SignupPolicy::default(),
            sign_in_methods: default_sign_in_methods(),
            contact_email: None,
            modules: {
                let mut modules = modules::auth_enabled_defaults();
                modules.get_mut("actions").unwrap()["on"] = json!(true);
                modules.get_mut("files").unwrap()["on"] = json!(true);
                modules
            },
            released_schema: String::new(),
            server: None,
        };
        tokio::fs::create_dir_all(crate::layout::data(&root, &deployment.id))
            .await
            .unwrap();
        let state = AppState {
            deployments: Arc::new(RwLock::new(HashMap::from([(
                deployment.hostname.clone(),
                deployment,
            )]))),
            ..AppState::for_test(&root)
        };
        let mut headers = HeaderMap::new();
        headers.insert(
            header::HOST,
            HeaderValue::from_static("login-test.localhost"),
        );
        (state, headers)
    }

    fn action(kind: &str, statement: &str, bindings: Vec<ActionBinding>) -> ActionDefinition {
        ActionDefinition {
            kind: kind.into(),
            access: "anonymous".into(),
            statement: statement.into(),
            bindings,
            http: None,
            page: None,
            signal: None,
            guard: None,
            notify: None,
            schedule: None,
            subscribe: None,
            call: Default::default(),
            extra: Default::default(),
        }
    }

    fn apply_schema(path: &Path, schema: &str, program: &ActionProgram) -> Result<schema_change::Change> {
        schema_change::apply(path, schema, program, schema_change::Mode::Apply(None))
    }

    fn action_program(actions: &[(&str, &str)]) -> ActionProgram {
        ActionProgram {
            version: 1,
            actions: actions
                .iter()
                .map(|(name, statement)| ((*name).into(), action("query", statement, Vec::new())))
                .collect(),
        }
    }

    #[test]
    fn actions_accept_one_constrained_statement_and_reject_structural_sql() {
        assert!(
            validate_action(
                "tasks.list",
                &action("query", "SELECT id FROM tasks LIMIT 10", vec![])
            )
            .is_ok()
        );
        assert!(
            validate_action(
                "tasks.create",
                &action("mutation", "INSERT INTO tasks(title) VALUES (?)", vec![])
            )
            .is_ok()
        );
        assert!(
            validate_action(
                "tasks.drop",
                &action("mutation", "DROP TABLE tasks", vec![])
            )
            .is_err()
        );
        assert!(
            validate_action("tasks.read", &action("query", "SELECT 1; SELECT 2", vec![])).is_err()
        );
        let mut granted = action("mutation", "DELETE FROM tasks", vec![]);
        granted.access = "granted".into();
        assert!(validate_action("tasks.delete", &granted).is_err());
        assert!(validate_action("tasks.list", &action("query", "SELECT id FROM tasks", vec![]))
            .unwrap_err()
            .message
            .contains("reads rows and has no LIMIT"));
        assert!(validate_action("tasks.list", &action("query", "SELECT id FROM tasks WHERE title = 'LIMIT 5'", vec![])).is_err());
        assert!(validate_action("tasks.count", &action("query", "SELECT count(*) AS n FROM tasks", vec![])).is_ok());
        assert!(validate_action("votes.results", &action("query", "SELECT choice, count(*) AS n FROM votes GROUP BY choice", vec![])).is_err());
        assert!(validate_action("tasks.one", &action("query", "SELECT 1", vec![])).is_ok());
    }

    #[test]
    fn action_inputs_are_named_typed_and_closed() {
        let definition = action(
            "mutation",
            "INSERT INTO tasks(title) VALUES (?)",
            vec![ActionBinding {
                source: "input".into(),
                key: Some("title".into()),
                value_type: Some("string".into()),
                max_length: Some(20),
                nullable: false,
                field: None,
                value: None,
            }],
        );
        assert_eq!(
            resolve_bindings(&definition, &json!({"title": "Ship it"}), None).unwrap(),
            vec![SqlValue::Text("Ship it".into())]
        );
        assert!(
            resolve_bindings(
                &definition,
                &json!({"title": "Ship it", "sql": "DROP TABLE tasks"}),
                None,
            )
            .unwrap_err()
            .contains("Unexpected")
        );
        assert!(
            resolve_bindings(&definition, &json!({"title": 42}), None)
                .unwrap_err()
                .contains("non-empty string")
        );
    }

    #[tokio::test]
    async fn login_route_is_available_for_public_and_private_apps() {
        for visibility in ["public", "private"] {
            let root = std::env::temp_dir()
                .join(format!("konae-login-{visibility}-{}", Uuid::new_v4()));
            let (state, headers) = login_test_state(&root, visibility).await;
            let response = login_page(State(state), headers).await;
            assert_eq!(response.status(), StatusCode::OK, "visibility={visibility}");
            let bytes = axum::body::to_bytes(response.into_body(), 16_384)
                .await
                .unwrap();
            let html = String::from_utf8(bytes.to_vec()).unwrap();
            assert!(html.contains("<h1>Sign in</h1>") && html.contains(r#"<p class="kicker">"#));
            assert!(html.contains("/_konae/auth/signup"));
            assert!(!html.contains("Account creation is open"));
            let _ = tokio::fs::remove_dir_all(root).await;
        }
    }

    async fn set_policy(state: &AppState, mode: SignupMode, allowlist: &[&str]) {
        let entries = allowlist.iter().map(|e| e.to_string()).collect::<Vec<_>>();
        for deployment in state.deployments.write().await.values_mut() {
            deployment.signup_policy = SignupPolicy::from_input(mode, &entries).unwrap();
        }
    }

    async fn signup_status(state: &AppState, headers: &HeaderMap, email: &str) -> StatusCode {
        let body = json!({"email": email, "password": "correct horse battery"});
        let request = Request::builder().body(Body::from(body.to_string())).unwrap();
        signup(State(state.clone()), headers.clone(), request).await.status()
    }

    #[test]
    fn signup_policy_matches_exact_emails_and_whole_domains() {
        let open = SignupPolicy::default();
        assert!(open.allows("anyone@example.test"));
        let closed = SignupPolicy::from_input(SignupMode::Closed, &[]).unwrap();
        assert!(!closed.allows("anyone@example.test"));
        let invitation: SignupPolicy = serde_json::from_value(json!({"mode": "invitation"})).unwrap();
        assert!(!invitation.allows("anyone@example.test"), "Invitation only refuses every plain signup");
        let list = SignupPolicy::from_input(
            SignupMode::Allowlist,
            &[" Carol@Example.TEST ".into(), "@Team.Example".into(), "carol@example.test".into()],
        )
        .unwrap();
        assert_eq!(list.allowlist, vec!["carol@example.test", "@team.example"]);
        assert!(list.allows("CAROL@example.test"));
        assert!(list.allows("dana@TEAM.example"));
        assert!(!list.allows("dana@sub.team.example"));
        assert!(!list.allows("dana@evilteam.example"));
        assert!(!list.allows("team.example@attacker.test"));
        assert!(!list.allows("erin@example.test"));
        assert!(!list.allows("not-an-email"));
        let empty = SignupPolicy::from_input(SignupMode::Allowlist, &[]).unwrap();
        assert!(!empty.allows("carol@example.test"));
        for invalid in ["@", "@nodot", "two@@example.test", "@bad domain.test", "plain"] {
            assert!(
                SignupPolicy::from_input(SignupMode::Allowlist, &[invalid.into()]).is_err(),
                "entry={invalid}"
            );
        }
        let too_many = (0..=MAX_ALLOWLIST_ENTRIES)
            .map(|i| format!("user{i}@example.test"))
            .collect::<Vec<_>>();
        assert!(SignupPolicy::from_input(SignupMode::Allowlist, &too_many).is_err());
    }

    #[tokio::test]
    async fn signup_follows_the_deployment_policy() {
        let root = std::env::temp_dir().join(format!("konae-signup-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "public").await;
        assert_eq!(signup_status(&state, &headers, "open@example.test").await, StatusCode::OK);

        set_policy(&state, SignupMode::Closed, &[]).await;
        assert_eq!(signup_status(&state, &headers, "closed@example.test").await, StatusCode::FORBIDDEN);

        set_policy(&state, SignupMode::Allowlist, &["Listed@Example.test", "@team.example"]).await;
        assert_eq!(signup_status(&state, &headers, "listed@EXAMPLE.test").await, StatusCode::OK);
        assert_eq!(signup_status(&state, &headers, "any@team.example").await, StatusCode::OK);
        assert_eq!(signup_status(&state, &headers, "other@example.test").await, StatusCode::FORBIDDEN);
        assert_eq!(signup_status(&state, &headers, "any@sub.team.example").await, StatusCode::FORBIDDEN);

        // Existing accounts still sign in when signup is closed.
        set_policy(&state, SignupMode::Closed, &[]).await;
        let body = json!({"email": "open@example.test", "password": "correct horse battery"});
        let request = Request::builder().body(Body::from(body.to_string())).unwrap();
        assert_eq!(login(State(state.clone()), headers.clone(), request).await.status(), StatusCode::OK);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn operator_policy_updates_keep_saved_source_settings_across_restart() {
        let root = std::env::temp_dir().join(format!("konae-policy-preserves-draft-{}", Uuid::new_v4()));
        let (state, _) = login_test_state(&root, "public").await;
        let mut current = state.deployments.read().await.values().next().unwrap().clone();
        current.modules.get_mut("auth").unwrap()["on"] = json!(true);
        current.modules.get_mut("files").unwrap()["on"] = json!(true);
        current.actions = "{\"version\":1,\"actions\":{}}".into();
        state.deployments.write().await.insert(current.hostname.clone(), current.clone());
        Settings::of(&current).write(&root).await.unwrap();
        let draft = json!({"id":current.id,"name":"Unpublished draft name","slug":"app","files":{"index.html":"<main>app</main>","actions.json":"{\"version\":1,\"actions\":{}}","schema.sql":""},"directories":[],"manifest":{"version":1,"visibility":"private","fileAccess":"app-users"},"updatedAt":now_ms()});
        crate::sources::write(&root, &current.id, &draft).await.unwrap();
        tokio::fs::create_dir_all(crate::layout::dist(&root, &current.id)).await.unwrap();
        tokio::fs::write(crate::layout::dist(&root, &current.id).join("index.html"), "<main>deployed</main>").await.unwrap();

        set_signup_policy(&state, &current.id, SignupMode::Closed, None).await.unwrap();
        let saved = crate::sources::read(&root, &current.id).await.unwrap().unwrap();
        assert_eq!(saved["name"], "Unpublished draft name");
        assert_eq!(saved["manifest"]["visibility"], "private");
        assert!(saved["manifest"].get("fileAccess").is_none());

        let restarted = AppState::for_test(&root);
        let serving = folder::open(&restarted, &current.id, None).await.unwrap();
        assert_eq!(serving.project_name, current.project_name);
        assert_eq!(serving.manifest["visibility"], "public");
        assert_eq!(serving.modules["files"]["on"], true);
        assert!(serving.manifest.get("fileAccess").is_none());
        assert_eq!(serving.signup_policy.mode, SignupMode::Closed);
        std::fs::remove_dir_all(root).unwrap();
    }

    #[tokio::test]
    async fn login_page_hides_account_creation_when_signup_is_closed() {
        let root = std::env::temp_dir().join(format!("konae-login-policy-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "private").await;
        let page = |state: AppState| {
            let headers = headers.clone();
            async move {
                let response = login_page(State(state), headers).await;
                let bytes = axum::body::to_bytes(response.into_body(), 16_384).await.unwrap();
                String::from_utf8(bytes.to_vec()).unwrap()
            }
        };
        set_policy(&state, SignupMode::Closed, &[]).await;
        let html = page(state.clone()).await;
        assert!(!html.contains("/_konae/auth/signup"));
        assert!(html.contains("not accepting new accounts"));
        set_policy(&state, SignupMode::Allowlist, &["@example.test"]).await;
        let html = page(state.clone()).await;
        assert!(html.contains("/_konae/auth/signup"));
        assert!(html.contains("Only invited email addresses"));
        set_policy(&state, SignupMode::Invitation, &[]).await;
        let html = page(state.clone()).await;
        assert!(!html.contains("/_konae/auth/signup"));
        assert!(html.contains("Only invited people can create an account"));
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn private_apps_refuse_anonymous_actions_without_a_session() {
        let root = std::env::temp_dir().join(format!("konae-private-action-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "private").await;
        let program = json!({"version": 1, "actions": {"items.count": {"kind": "query", "access": "anonymous", "statement": "SELECT 1 AS n", "bindings": []}}});
        for deployment in state.deployments.write().await.values_mut() {
            deployment.actions = program.to_string();
            initialize_database(&database_path(&state, &deployment.id)).unwrap();
        }
        let call = |state: AppState| {
            let headers = headers.clone();
            async move {
                invoke_action(State(state), AxumPath("items.count".into()), headers, Json(json!({})))
                    .await
                    .status()
            }
        };
        assert_eq!(call(state.clone()).await, StatusCode::UNAUTHORIZED);
        for deployment in state.deployments.write().await.values_mut() {
            deployment.manifest = json!({"visibility": "public"});
        }
        assert_eq!(call(state.clone()).await, StatusCode::OK);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_deployment_that_does_not_say_public_serves_no_asset_without_a_login() {
        let root = std::env::temp_dir().join(format!("konae-fail-closed-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "public").await;
        let id = state.deployments.read().await.values().next().unwrap().id.clone();
        let artifact = layout::dist(&state.data_root, &id);
        tokio::fs::create_dir_all(&artifact).await.unwrap();
        tokio::fs::write(artifact.join("report.txt"), "secret").await.unwrap();
        let read = |manifest: Value| {
            let (state, headers) = (state.clone(), headers.clone());
            async move {
                for deployment in state.deployments.write().await.values_mut() {
                    deployment.manifest = manifest.clone();
                }
                let response = serve_key(state, headers, "report.txt".into()).await;
                let bytes = axum::body::to_bytes(response.into_body(), 1 << 20).await.unwrap();
                String::from_utf8_lossy(&bytes).into_owned()
            }
        };
        assert_eq!(read(json!({"visibility": "public"})).await, "secret");
        for manifest in [json!({}), json!({"visibility": null}), json!({"visibility": "Public"}), json!({"visibility": "open"})] {
            let deployment = Deployment { manifest: manifest.clone(), ..state.deployments.read().await.values().next().unwrap().clone() };
            assert!(is_private(&deployment), "{manifest}");
            let body = read(manifest.clone()).await;
            assert!(!body.contains("secret") && body.contains("<form"), "{manifest}");
        }
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_scheduled_mutation_without_a_route_runs_only_on_its_schedule() {
        let root = std::env::temp_dir().join(format!("konae-scheduled-action-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "public").await;
        let program = json!({"version": 1, "actions": {"holds.release": {
            "kind": "mutation", "access": "anonymous", "schedule": {"every": "15m"},
            "statement": "UPDATE holds SET released_at = ?1 WHERE released_at IS NULL", "bindings": [{"source": "kernel", "field": "now"}]
        }}});
        for deployment in state.deployments.write().await.values_mut() {
            deployment.actions = program.to_string();
            deployment.manifest = json!({"visibility": "public"});
        }
        let response = invoke_action(State(state), AxumPath("holds.release".into()), headers, Json(json!({}))).await;
        assert_eq!(response.status(), StatusCode::FORBIDDEN);
        let bytes = axum::body::to_bytes(response.into_body(), 4096).await.unwrap();
        assert!(String::from_utf8_lossy(&bytes).contains("Action holds.release runs only on its schedule."));
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[test]
    fn redeploy_adds_tables_without_losing_rows_and_rejects_destructive_schema() {
        let root = std::env::temp_dir().join(format!("konae-schema-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        initialize_database(&path).unwrap();

        let initial = "CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, title TEXT NOT NULL); CREATE INDEX IF NOT EXISTS tasks_title ON tasks(title);";
        let original_action = action_program(&[("tasks.list", "SELECT id, title FROM tasks")]);
        apply_schema(&path, initial, &original_action).unwrap();
        Connection::open(&path)
            .unwrap()
            .execute("INSERT INTO tasks(title) VALUES ('Keep this row')", [])
            .unwrap();

        let extended = format!(
            "{initial} CREATE TABLE IF NOT EXISTS notes (id INTEGER PRIMARY KEY, body TEXT NOT NULL); CREATE INDEX IF NOT EXISTS notes_body ON notes(body);"
        );
        let extended_actions = action_program(&[
            ("tasks.list", "SELECT id, title FROM tasks"),
            ("notes.list", "SELECT id, body FROM notes"),
        ]);
        apply_schema(&path, &extended, &extended_actions).unwrap();
        apply_schema(&path, &extended, &extended_actions).unwrap();

        let connection = Connection::open(&path).unwrap();
        let title: String = connection
            .query_row("SELECT title FROM tasks", [], |row| row.get(0))
            .unwrap();
        assert_eq!(title, "Keep this row");
        assert!(connection
            .query_row(
                "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name='notes')",
                [],
                |row| row.get::<_, bool>(0),
            )
            .unwrap());
        drop(connection);

        assert!(apply_schema(&path, "DROP TABLE tasks;", &extended_actions).is_err());
        let connection = Connection::open(&path).unwrap();
        let title: String = connection
            .query_row("SELECT title FROM tasks", [], |row| row.get(0))
            .unwrap();
        assert_eq!(title, "Keep this row");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn schemas_may_call_safe_functions_but_not_dangerous_ones() {
        let root = std::env::temp_dir().join(format!("konae-schema-functions-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        initialize_database(&path).unwrap();
        let schema = "CREATE TABLE IF NOT EXISTS items (
              id INTEGER PRIMARY KEY,
              name TEXT NOT NULL CHECK (length(name) > 0),
              title TEXT NOT NULL DEFAULT '',
              slug TEXT GENERATED ALWAYS AS (lower(name)) VIRTUAL,
              created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS items_title ON items(lower(title));
            CREATE INDEX IF NOT EXISTS items_named ON items(name) WHERE length(name) > 0;";
        let actions = action_program(&[("items.list", "SELECT id, name, slug FROM items")]);
        apply_schema(&path, schema, &actions).unwrap();
        let connection = Connection::open(&path).unwrap();
        assert!(connection.execute("INSERT INTO items(name) VALUES ('')", []).is_err(), "the CHECK constraint runs");
        connection.execute("INSERT INTO items(name) VALUES ('Mixed')", []).unwrap();
        let slug: String = connection.query_row("SELECT slug FROM items", [], |row| row.get(0)).unwrap();
        assert_eq!(slug, "mixed");
        drop(connection);

        for function in DENIED_FUNCTIONS {
            let schema = format!(
                "CREATE TABLE IF NOT EXISTS evil_{function} (id INTEGER PRIMARY KEY, path TEXT CHECK ({function}(path) IS NULL));"
            );
            let error = apply_schema(&path, &schema, &actions).unwrap_err().to_string();
            assert_eq!(error, format!("schema.sql may only create tables and indexes, but it contains {function}()."), "{function}");
        }
        let evil = format!("{schema} CREATE INDEX IF NOT EXISTS evil_index ON items(load_extension(name));");
        let error = apply_schema(&path, &evil, &actions).unwrap_err().to_string();
        assert_eq!(error, "schema.sql may only create tables and indexes, but it contains load_extension().");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn a_schema_value_and_an_action_pattern_are_bounded_and_no_trigger_or_view_gets_in() {
        let root = std::env::temp_dir().join(format!("konae-sql-bounds-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        initialize_database(&path).unwrap();
        let actions = action_program(&[("items.list", "SELECT id FROM items LIMIT 5")]);
        apply_schema(&path, "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, name TEXT);", &actions).unwrap();
        let connection = Connection::open(&path).unwrap();
        connection.execute("INSERT INTO items(name) VALUES ('a')", []).unwrap();
        drop(connection);
        // An index whose expression builds a 200 MB value per row hits the
        // value limit instead of the memory of the Kernel.
        let heavy = "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, name TEXT); CREATE INDEX IF NOT EXISTS heavy ON items(length(hex(zeroblob(200000000))));";
        let error = apply_schema(&path, heavy, &actions).unwrap_err().to_string();
        assert!(error.contains("too big"), "{error}");

        let db = Connection::open(&path).unwrap();
        restrict_database(&db).unwrap();
        let pattern = |length: usize| format!("SELECT 'x' LIKE '{}'", "%".repeat(length));
        db.query_row(&pattern(MAX_LIKE_PATTERN_BYTES as usize), [], |row| row.get::<_, bool>(0)).unwrap();
        let long = db.query_row(&pattern(MAX_LIKE_PATTERN_BYTES as usize + 1), [], |row| row.get::<_, bool>(0)).unwrap_err().to_string();
        assert!(long.contains("pattern too complex"), "{long}");
        // Studio and the schema change open this connection too.
        for statement in ["CREATE TRIGGER t AFTER INSERT ON items BEGIN DELETE FROM items; END", "CREATE VIEW v AS SELECT 1",
            "CREATE TEMP TRIGGER t AFTER INSERT ON items BEGIN SELECT 1; END", "CREATE TEMP VIEW v AS SELECT 1"] {
            assert!(db.execute_batch(statement).unwrap_err().to_string().contains("not authorized"), "{statement}");
        }
        drop(db);

        let _ = std::fs::remove_dir_all(root);
    }

    #[tokio::test]
    async fn named_locks_leave_no_entry_once_released() {
        let root = std::env::temp_dir().join(format!("konae-locks-{}", Uuid::new_v4()));
        let state = test_state(&root);
        let count = |state: &AppState| state.db_locks.lock().unwrap().len();
        for i in 0..100 {
            drop(database_lock(&state, &format!("transfer:{i}")).await);
        }
        assert_eq!(count(&state), 0);

        let first = database_lock(&state, "shared").await;
        let waiter = {
            let state = state.clone();
            tokio::spawn(async move {
                let _second = database_lock(&state, "shared").await;
            })
        };
        tokio::task::yield_now().await;
        assert_eq!(count(&state), 1);
        drop(first);
        waiter.await.unwrap();
        assert_eq!(count(&state), 0, "the last holder removes the entry");

        // A caller that gives up while waiting removes the entry too.
        let held = database_lock(&state, "contended").await;
        let gave_up = tokio::time::timeout(
            std::time::Duration::from_millis(20),
            database_lock(&state, "contended"),
        )
        .await;
        assert!(gave_up.is_err());
        assert_eq!(count(&state), 1, "the holder keeps its entry");
        drop(held);
        assert_eq!(count(&state), 0);
    }

    #[test]
    fn redeploy_rolls_back_schema_when_an_action_does_not_prepare() {
        let root = std::env::temp_dir().join(format!("konae-schema-action-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        initialize_database(&path).unwrap();
        let invalid_action = action_program(&[("tasks.list", "SELECT missing FROM tasks")]);
        assert!(
            apply_schema(
                &path,
                "CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY);",
                &invalid_action,
            )
            .is_err()
        );
        let connection = Connection::open(&path).unwrap();
        assert!(!connection
            .query_row(
                "SELECT EXISTS(SELECT 1 FROM sqlite_master WHERE type='table' AND name='tasks')",
                [],
                |row| row.get::<_, bool>(0),
            )
            .unwrap());
        let _ = std::fs::remove_dir_all(root);
    }

    fn test_state(root: &Path) -> AppState {
        AppState::for_test(&root)
    }

    fn input_binding(key: &str, value_type: &str, max_length: Option<usize>) -> ActionBinding {
        ActionBinding {
            source: "input".into(),
            key: Some(key.into()),
            value_type: Some(value_type.into()),
            max_length,
            nullable: false,
            field: None,
            value: None,
        }
    }

    #[test]
    fn nullable_inputs_preserve_types_and_required_inputs() {
        for value_type in ["string", "number", "boolean"] {
            let mut binding = input_binding("value", value_type, Some(4));
            binding.nullable = true;
            let definition = action("query", "SELECT ?1", vec![binding]);
            assert!(validate_action("inputs.echo", &definition).is_ok());
            for input in [json!({}), json!({"value": null})] {
                assert_eq!(resolve_bindings(&definition, &input, None).unwrap(), vec![SqlValue::Null]);
            }
            assert!(resolve_bindings(&definition, &json!({"other": null}), None).unwrap_err().contains("Unexpected"));
            let wrong = match value_type {
                "string" => json!({"value": 5}),
                "number" => json!({"value": "5"}),
                _ => json!({"value": 0}),
            };
            assert!(resolve_bindings(&definition, &wrong, None).is_err());
            let required = action("query", "SELECT ?1", vec![input_binding("value", value_type, Some(4))]);
            assert!(resolve_bindings(&required, &json!({}), None).is_err());
            assert!(resolve_bindings(&required, &json!({"value": null}), None).is_err());
        }
        let mut binding = input_binding("value", "string", Some(4));
        binding.nullable = true;
        let definition = action("query", "SELECT ?1", vec![binding]);
        assert!(resolve_bindings(&definition, &json!({"value": ""}), None).is_err());
        assert!(resolve_bindings(&definition, &json!({"value": "longer"}), None).is_err());
        assert_eq!(resolve_bindings(&definition, &json!({"value": "ship"}), None).unwrap(), vec![SqlValue::Text("ship".into())]);
        for source in ["actor", "kernel", "literal"] {
            let mut binding = input_binding("value", "string", None);
            binding.source = source.into();
            binding.nullable = true;
            assert!(validate_action("inputs.echo", &action("query", "SELECT ?1", vec![binding])).is_err());
        }
    }

    #[test]
    fn mutation_returning_fails_schema_validation_without_executing() {
        let root = std::env::temp_dir().join(format!("konae-returning-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        initialize_database(&path).unwrap();
        let schema = "CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, body TEXT, \"RETURNING\" INTEGER);";
        for sql in [
            "INSERT INTO notes(body) VALUES ('note') RETURNING id",
            "UPDATE notes SET body='note' returning body",
            "DELETE FROM notes RETURNING *",
        ] {
            let program = ActionProgram { version: 1, actions: HashMap::from([("notes.write".into(), action("mutation", sql, vec![]))]) };
            assert!(apply_schema(&path, schema, &program).unwrap_err().to_string().contains("cannot use RETURNING"));
        }
        for sql in [
            "INSERT INTO notes(body) VALUES ('RETURNING')",
            "UPDATE notes SET body='note' /* RETURNING id */",
            "UPDATE notes SET \"RETURNING\"=1",
        ] {
            let program = ActionProgram { version: 1, actions: HashMap::from([("notes.write".into(), action("mutation", sql, vec![]))]) };
            apply_schema(&path, schema, &program).unwrap();
        }
        let count: i64 = Connection::open(&path).unwrap().query_row("SELECT count(*) FROM notes", [], |row| row.get(0)).unwrap();
        assert_eq!(count, 0);
        let _ = std::fs::remove_dir_all(root);
    }




    #[test]
    fn artifact_content_types_follow_the_extension() {
        for (path, expected) in [
            ("index.html", "text/html; charset=utf-8"),
            ("docs/page.HTM", "text/html; charset=utf-8"),
            ("app.js", "text/javascript; charset=utf-8"),
            ("chunk.mjs", "text/javascript; charset=utf-8"),
            ("styles.css", "text/css; charset=utf-8"),
            ("data.json", "application/json"),
            ("app.js.map", "application/json"),
            ("site.webmanifest", "application/manifest+json"),
            ("robots.txt", "text/plain; charset=utf-8"),
            ("logo.svg", "image/svg+xml"),
            ("a.png", "image/png"),
            ("a.jpg", "image/jpeg"),
            ("a.JPEG", "image/jpeg"),
            ("a.gif", "image/gif"),
            ("a.webp", "image/webp"),
            ("favicon.ico", "image/x-icon"),
            ("module.wasm", "application/wasm"),
            ("font.woff2", "font/woff2"),
            ("font.woff", "font/woff"),
            ("font.ttf", "font/ttf"),
            ("font.otf", "font/otf"),
            ("sitemap.xml", "application/xml; charset=utf-8"),
            ("feed.rss", "application/rss+xml; charset=utf-8"),
            ("feed.atom", "application/atom+xml; charset=utf-8"),
            ("notes.md", "text/markdown; charset=utf-8"),
            ("rows.csv", "text/csv; charset=utf-8"),
            ("photo.avif", "image/avif"),
            ("menu.pdf", "application/pdf"),
            ("archive.zip", "application/octet-stream"),
            ("LICENSE", "application/octet-stream"),
            ("dir.html/file", "application/octet-stream"),
        ] {
            assert_eq!(content_type(path), expected, "path={path}");
        }
        let response = artifact_response(b"x".to_vec(), "x.bin");
        assert_eq!(response.headers()[header::X_CONTENT_TYPE_OPTIONS], "nosniff");
        assert_eq!(response.headers()[header::CONTENT_TYPE], "application/octet-stream");
    }

    #[test]
    fn number_inputs_bind_integers_as_integer_and_fractions_as_real() {
        let definition = action(
            "mutation",
            "INSERT INTO items(label) VALUES (?)",
            vec![input_binding("value", "number", None)],
        );
        assert_eq!(
            resolve_bindings(&definition, &json!({"value": 5}), None).unwrap(),
            vec![SqlValue::Integer(5)]
        );
        assert_eq!(
            resolve_bindings(&definition, &json!({"value": -3}), None).unwrap(),
            vec![SqlValue::Integer(-3)]
        );
        assert_eq!(
            resolve_bindings(&definition, &json!({"value": 5.5}), None).unwrap(),
            vec![SqlValue::Real(5.5)]
        );
        assert_eq!(
            resolve_bindings(&definition, &json!({"value": u64::MAX}), None).unwrap(),
            vec![SqlValue::Real(u64::MAX as f64)]
        );

        let root = std::env::temp_dir().join(format!("konae-number-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path)
            .unwrap()
            .execute("CREATE TABLE items(label TEXT)", [])
            .unwrap();
        let params = resolve_bindings(&definition, &json!({"value": 5}), None).unwrap();
        run_mutation(&path, &definition, params).unwrap();
        let stored: String = Connection::open(&path)
            .unwrap()
            .query_row("SELECT label FROM items", [], |row| row.get(0))
            .unwrap();
        assert_eq!(stored, "5");
        let _ = std::fs::remove_dir_all(root);
    }

    /// ADR-0012: a notice that lists or addresses rows reads them back
    /// through the Kernel's RETURNING clause; the answer stays changes and

    #[test]
    fn a_mutation_reads_back_its_changed_rows_for_the_notice_only() {
        let program: ActionProgram = serde_json::from_value(json!({"version": 1, "actions": {
            "tasks.remind": {"kind": "mutation", "access": "authenticated", "schedule": {"every": "1h"},
                "statement": "UPDATE tasks SET reminded_at = ?1 WHERE reminded_at IS NULL; -- hourly",
                "bindings": [{"source": "kernel", "field": "now"}],
                "notify": {"to": {"column": "assignee"}, "changes": ["title"], "subject": "Due", "body": "{changes}"}}
        }})).unwrap();
        let definition = &program.actions["tasks.remind"];
        let root = std::env::temp_dir().join(format!("konae-returning-rows-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap().execute_batch(
            "CREATE TABLE tasks(id INTEGER PRIMARY KEY, title TEXT, assignee TEXT, reminded_at INTEGER);
             INSERT INTO tasks(title, assignee, reminded_at) VALUES ('a', 'ana', NULL), ('b', 'ben', NULL), ('c', 'ana', 5);",
        ).unwrap();
        let ran = run_mutation(&path, definition, vec![SqlValue::Integer(9)]).unwrap();
        assert_eq!(ran.answer, json!({"changes": 2, "lastInsertId": 0}));
        let mut rows: Vec<Value> = ran.rows.iter().cloned().map(Value::Object).collect();
        rows.sort_by_key(|row| row["title"].to_string());
        assert_eq!(rows, vec![json!({"title": "a", "assignee": "ana"}), json!({"title": "b", "assignee": "ben"})]);
        let reminded: i64 = Connection::open(&path).unwrap().query_row("SELECT count(*) FROM tasks WHERE reminded_at = 9", [], |row| row.get(0)).unwrap();
        assert_eq!(reminded, 2);
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn string_max_length_counts_utf16_code_units() {
        let two = action("mutation", "SELECT ?", vec![input_binding("title", "string", Some(2))]);
        let one = action("mutation", "SELECT ?", vec![input_binding("title", "string", Some(1))]);

        let emoji = json!({"title": "\u{1F600}"});
        assert!(resolve_bindings(&two, &emoji, None).is_ok());
        assert!(resolve_bindings(&one, &emoji, None).unwrap_err().contains("too long"));
        assert!(resolve_bindings(&two, &json!({"title": "\u{e9}\u{e9}"}), None).is_ok());
    }

    async fn deploy_files(state: &AppState, files: Value) -> Value {
        deploy_with_visibility(state, files, "public").await
    }

    async fn deploy_with_visibility(state: &AppState, files: Value, visibility: &str) -> Value {
        let body = json!({
            "project": {
                "id": "app_republish", "name": "Republish", "slug": "republish", "manifest": {},
                "files": {"actions.json": "{\"version\":1,\"actions\":{}}", "schema.sql": ""}
            },
            "visibility": visibility,
            "artifact": {"version": 1, "entrypoint": "index.html", "files": files}
        });
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let status = response.status();
        let bytes = axum::body::to_bytes(response.into_body(), 1_000_000).await.unwrap();
        assert_eq!(status, StatusCode::OK, "{}", String::from_utf8_lossy(&bytes));
        serde_json::from_slice::<Value>(&bytes).unwrap()["result"].clone()
    }

    #[tokio::test]
    async fn a_first_release_takes_the_slug_hostname_when_free() {
        let root = std::env::temp_dir().join(format!("konae-slug-host-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        let first = deploy_files(&state, json!({"index.html": "<p>one</p>"})).await;
        assert_eq!(first["hostname"], "republish.localhost");
        assert_eq!(first["url"], "http://republish.localhost");
        let again = deploy_files(&state, json!({"index.html": "<p>two</p>"})).await;
        assert_eq!(again["hostname"], "republish.localhost");
        let body = json!({
            "project": {
                "id": "app_other", "name": "Other", "slug": "republish", "manifest": {},
                "files": {"actions.json": "{\"version\":1,\"actions\":{}}", "schema.sql": ""}
            },
            "visibility": "public",
            "artifact": {"version": 1, "entrypoint": "index.html", "files": {"index.html": "<p>other</p>"}}
        });
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let status = response.status();
        let bytes = axum::body::to_bytes(response.into_body(), 1_000_000).await.unwrap();
        assert_eq!(status, StatusCode::OK, "{}", String::from_utf8_lossy(&bytes));
        let other = serde_json::from_slice::<Value>(&bytes).unwrap()["result"].clone();
        let host = other["hostname"].as_str().unwrap();
        assert!(host.starts_with("republish-"), "{host}");
        assert!(host.ends_with(".localhost"), "{host}");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_browser_navigation_to_a_page_counts_one_page_view_by_the_file_served() {
        let root = std::env::temp_dir().join(format!("konae-page-views-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        deploy_files(&state, json!({"index.html": "<p>home</p>", "about.html": "<p>about</p>", "app.js": "1"})).await;
        let (host, deployment) = state.deployments.read().await.iter().next().map(|(h, d)| (h.clone(), d.clone())).unwrap();
        let get = |path: &str, extra: &[(&'static str, &'static str)]| {
            let mut headers = HeaderMap::new();
            headers.insert(header::HOST, HeaderValue::from_str(&host).unwrap());
            for (name, value) in extra {
                headers.insert(*name, HeaderValue::from_static(value));
            }
            serve_key(state.clone(), headers, path.into())
        };
        let navigation = [("sec-fetch-dest", "document")];
        assert_eq!(get("index.html", &navigation).await.status(), StatusCode::OK);
        assert_eq!(get("about", &navigation).await.status(), StatusCode::OK);
        assert_eq!(get("about", &navigation).await.status(), StatusCode::OK);

        get("index.html", &[]).await;
        get("index.html", &[("sec-fetch-dest", "script")]).await;
        get("app.js", &navigation).await;
        get("index.html", &[("sec-fetch-dest", "document"), ("sec-purpose", "prefetch;prerender")]).await;
        assert_eq!(get("missing", &navigation).await.status(), StatusCode::NOT_FOUND);
        usage::flush();
        let today = usage::day(now_ms());
        let usage = usage::read_usage(&crate::layout::usage(&root, &deployment.id), &today, &today).unwrap();
        let views: Vec<_> = usage["totals"].as_array().unwrap().iter().filter(|row| row["kind"] == "page_view").cloned().collect();
        assert_eq!(views, vec![
            json!({"kind": "page_view", "name": "about.html", "count": 2}),
            json!({"kind": "page_view", "name": "index.html", "count": 1}),
        ]);


        for deployment in state.deployments.write().await.values_mut() {
            deployment.manifest["routing"] = json!("spa");
        }
        assert_eq!(get("items/3", &navigation).await.status(), StatusCode::OK);
        assert_eq!(get("missing-chunk.js", &[("sec-fetch-dest", "script")]).await.status(), StatusCode::OK);
        usage::flush();
        let usage = usage::read_usage(&crate::layout::usage(&root, &deployment.id), &today, &today).unwrap();
        let index = usage["totals"].as_array().unwrap().iter().find(|row| row["kind"] == "page_view" && row["name"] == "index.html").cloned();
        assert_eq!(index, Some(json!({"kind": "page_view", "name": "index.html", "count": 2})));
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn seo_lists_only_titled_pages_and_revalidates_the_chosen_address() {
        let root = std::env::temp_dir().join(format!("konae-seo-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let mut state = test_state(&root);
        state.public_origin = "https://konae.example.test".into();
        state.guards = Arc::new(Guards::new(Vec::new()).with_statement_wait(std::time::Duration::from_millis(5)));
        deploy_files(&state, json!({
            "index.html": "<!doctype html><html><head><title>Home</title><meta name=\"description\" content=\"Start here\"></head><body>Home</body></html>",
            "about.html": "<!doctype html><html><head><title>A \"small\" <app> &amp; more</title><meta property=\"og:title\" content=\"Owner title\"></head><body>About</body></html>",
            "post.html": "<!doctype html><html><head><title>Post template</title></head><body>Post</body></html>",
            "untitled.html": "<html><body>Missing title</body></html>",
            "robots.txt": "User-agent: special\nDisallow: /private\n",
            "card.png": "image"
        })).await;
        let (host, deployment) = {
            let mut deployments = state.deployments.write().await;
            let (host, deployment) = deployments.iter_mut().next().unwrap();
            deployment.actions = r#"{"version":1,"actions":{"posts.by":{"kind":"query","access":"anonymous","statement":"SELECT title FROM posts WHERE slug = ?1 LIMIT 1","bindings":[{"source":"input","key":"slug","type":"string"}],"page":{"path":"/posts/:slug","file":"post.html","list":"posts.list"}},"posts.list":{"kind":"query","access":"anonymous","statement":"SELECT 'listed' AS slug, ?1 AS updated LIMIT 1","bindings":[{"source":"kernel","field":"now"}]}}}"#.into();
            (host.clone(), deployment.clone())
        };
        if let Err(error_value) = action_shape::read(&deployment.actions) { panic!("{error_value}"); }
        let mut headers = HeaderMap::new();
        headers.insert(header::HOST, HeaderValue::from_str(&host).unwrap());
        let _off = serve_key(state.clone(), headers.clone(), "index.html".into()).await;
        {
            let mut deployments = state.deployments.write().await;
            let app = deployments.get_mut(&host).unwrap();
            app.modules.get_mut("seo").unwrap()["on"] = json!(true);
            app.modules.get_mut("seo").unwrap()["canonical"] = Value::Null;
            app.modules.get_mut("seo").unwrap()["image"] = json!("card.png");
        }
        let home = serve_key(state.clone(), headers.clone(), "index.html".into()).await;
        let home_body = axum::body::to_bytes(home.into_body(), 100_000).await.unwrap();
        let home_html = String::from_utf8(home_body.to_vec()).unwrap();
        for card in ["og:title", "og:description", "og:url", "og:image"] { assert!(home_html.contains(card), "missing {card}"); }
        let about = serve_key(state.clone(), headers.clone(), "about".into()).await;
        let old_etag = about.headers()[header::ETAG].to_str().unwrap().to_owned();
        let about_body = axum::body::to_bytes(about.into_body(), 100_000).await.unwrap();
        let about_html = String::from_utf8(about_body.to_vec()).unwrap();
        assert!(about_html.contains("<title>A \"small\" <app> &amp; more</title>"));
        assert!(about_html.contains("content=\"Owner title\""));
        assert!(about_html.contains("href=\"https://republish.localhost/about\""), "{about_html}");
        let mut navigation_headers = headers.clone();
        navigation_headers.insert(header::IF_NONE_MATCH, HeaderValue::from_str(&old_etag).unwrap());
        navigation_headers.insert("sec-fetch-dest", HeaderValue::from_static("document"));
        let navigation_revalidation = serve_key(state.clone(), navigation_headers, "about".into()).await;
        assert_eq!(navigation_revalidation.status(), StatusCode::NOT_MODIFIED);
        let robots = serve_key(state.clone(), headers.clone(), "robots.txt".into()).await;
        assert!(String::from_utf8(axum::body::to_bytes(robots.into_body(), 100_000).await.unwrap().to_vec()).unwrap().contains("Disallow: /private"));
        let mut held = Vec::new();
        for _ in 0..4 { held.push(state.guards.statement_permit(&deployment.id).await.unwrap()); }
        let blocked_sitemap = serve_key(state.clone(), headers.clone(), "sitemap.xml".into()).await;
        let blocked_sitemap = String::from_utf8(axum::body::to_bytes(blocked_sitemap.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert!(!blocked_sitemap.contains("/posts/listed"));
        drop(held);
        let sitemap = serve_key(state.clone(), headers.clone(), "sitemap.xml".into()).await;
        let sitemap_etag = sitemap.headers()[header::ETAG].to_str().unwrap().to_owned();
        let sitemap = String::from_utf8(axum::body::to_bytes(sitemap.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert!(sitemap.contains("/about"));
        assert!(sitemap.contains("/posts/listed"));
        assert!(!sitemap.contains("/post</loc>"));
        assert!(!sitemap.contains("untitled"));
        let mut sitemap_headers = headers.clone();
        sitemap_headers.insert(header::IF_NONE_MATCH, HeaderValue::from_str(&sitemap_etag).unwrap());
        let sitemap_revalidation = serve_key(state.clone(), sitemap_headers, "sitemap.xml".into()).await;
        assert_eq!(sitemap_revalidation.status(), StatusCode::NOT_MODIFIED);
        let template = serve_key(state.clone(), headers.clone(), "post.html".into()).await;
        assert_eq!(template.headers()["x-robots-tag"], "noindex");
        let listed = modules::read(&state, &deployment);
        assert_eq!(listed["modules"]["seo"]["current"]["canonical"]["reason"], "Generated hostname is the default.");
        assert!(listed["modules"]["seo"]["current"]["excluded"].to_string().contains("untitled.html"));
        let domain_file = crate::layout::private(&root, &deployment.id).join(crate::domain::RECORD_FILE);
        tokio::fs::create_dir_all(domain_file.parent().unwrap()).await.unwrap();
        tokio::fs::write(&domain_file, serde_json::to_vec(&json!({"hostname":"app.example.test","token":"test","verified":true,"createdAt":0})).unwrap()).await.unwrap();
        headers.insert(header::IF_NONE_MATCH, HeaderValue::from_str(&old_etag).unwrap());
        let changed = serve_key(state.clone(), headers, "about.html".into()).await;
        assert_eq!(changed.status(), StatusCode::OK);
        let changed = String::from_utf8(axum::body::to_bytes(changed.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert!(changed.contains("https://app.example.test/about"));
        state.deployments.write().await.get_mut(&host).unwrap().manifest["routing"] = json!("spa");
        let fallback = serve_key(state.clone(), HeaderMap::from_iter([(header::HOST, HeaderValue::from_str(&host).unwrap())]), "deep/page".into()).await;
        assert_eq!(fallback.headers()["x-robots-tag"], "noindex");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn page_queries_wait_through_database_swap_and_keep_the_new_wal() {
        let root = std::env::temp_dir().join(format!("konae-page-swap-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        deploy_files(&state, json!({"index.html":"<title>Home</title>","post.html":"<html><head><title>Template</title></head><body></body></html>"})).await;
        let (host, deployment) = {
            let mut deployments = state.deployments.write().await;
            let (host, deployment) = deployments.iter_mut().next().unwrap();
            deployment.actions = r#"{"version":1,"actions":{"posts.head":{"kind":"query","access":"anonymous","statement":"SELECT title FROM posts WHERE slug = ?1 LIMIT 1","bindings":[{"source":"input","key":"slug","type":"string"}],"page":{"path":"/posts/:slug","file":"post.html"}}}}"#.into();
            deployment.artifact_version = format!("{}-page-swap", deployment.artifact_version);
            (host.clone(), deployment.clone())
        };
        let routes = http::route_table(&deployment);
        assert!(routes.has_pages());
        let live = crate::layout::database(&root, &deployment.id);
        let staged = crate::layout::private(&root, &deployment.id).join("page-swap-staged.sqlite");
        let replaced = crate::layout::private(&root, &deployment.id).join("page-swap-replaced.sqlite");
        for path in [&live, &staged] {
            let connection = Connection::open(path).unwrap();
            connection.execute_batch("CREATE TABLE posts(slug TEXT PRIMARY KEY, title TEXT);").unwrap();
            connection.execute("INSERT INTO posts VALUES('hello', ?1)", [if path == &live { "Old" } else { "New" }]).unwrap();
        }
        let lock = database_lock(&state, &deployment.id).await;
        let (at_gap_tx, at_gap_rx) = std::sync::mpsc::channel();
        let (continue_tx, continue_rx) = std::sync::mpsc::channel();
        let swap = tokio::task::spawn_blocking(move || swap_database_with(&live, &staged, &replaced, || {
            at_gap_tx.send(()).unwrap();
            continue_rx.recv().unwrap();
        }));
        tokio::task::spawn_blocking(move || at_gap_rx.recv().unwrap()).await.unwrap();
        let headers = HeaderMap::from_iter([(header::HOST, HeaderValue::from_str(&host).unwrap())]);
        let request = tokio::spawn(serve_key_with_routes(state.clone(), headers, "posts/hello".into(), Some(routes)));
        let blocked = tokio::time::timeout(std::time::Duration::from_millis(20), async { while !request.is_finished() { tokio::task::yield_now().await; } }).await.is_err();
        continue_tx.send(()).unwrap();
        swap.await.unwrap().unwrap();
        assert!(blocked, "the page request completed inside the database swap");
        let writer = Connection::open(&crate::layout::database(&root, &deployment.id)).unwrap();
        writer.execute_batch("PRAGMA journal_mode=WAL;").unwrap();
        writer.execute("INSERT INTO posts VALUES('later', 'WAL row')", []).unwrap();
        assert!(crate::layout::database(&root, &deployment.id).with_extension("sqlite-wal").exists() || {
            let mut sidecar = crate::layout::database(&root, &deployment.id).as_os_str().to_owned();
            sidecar.push("-wal");
            std::path::PathBuf::from(sidecar).exists()
        });
        drop(lock);
        let response = request.await.unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let body = String::from_utf8(axum::body::to_bytes(response.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert!(body.contains("New"), "{body}");
        writer.execute("UPDATE posts SET title=NULL WHERE slug='hello'", []).unwrap();
        let headers = HeaderMap::from_iter([(header::HOST, HeaderValue::from_str(&host).unwrap())]);
        let untitled = serve_key_with_routes(state.clone(), headers, "posts/hello".into(), Some(http::route_table(&deployment))).await;
        assert_eq!(untitled.headers()["x-robots-tag"], "noindex");
        let untitled = String::from_utf8(axum::body::to_bytes(untitled.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert!(untitled.contains("name=\"konae-page-params\""));
        assert!(untitled.contains("&quot;slug&quot;:&quot;hello&quot;"));
        let reopened = Connection::open(crate::layout::database(&root, &deployment.id)).unwrap();
        assert_eq!(reopened.query_row("SELECT title FROM posts WHERE slug='later'", [], |row| row.get::<_, String>(0)).unwrap(), "WAL row");
        drop(writer);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_file_the_browser_holds_answers_304_until_the_next_publish() {
        let root = std::env::temp_dir().join(format!("konae-etag-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        deploy_files(&state, json!({"index.html": "<p>home</p>", "app.js": "1"})).await;
        for deployment in state.deployments.write().await.values_mut() {
            deployment.manifest["visibility"] = json!("public");
        }
        let (host, deployment) = state.deployments.read().await.iter().next().map(|(h, d)| (h.clone(), d.clone())).unwrap();
        let get = |path: &str, extra: Vec<(&'static str, String)>| {
            let mut headers = HeaderMap::new();
            headers.insert(header::HOST, HeaderValue::from_str(&host).unwrap());
            for (name, value) in extra {
                headers.insert(name, HeaderValue::from_str(&value).unwrap());
            }
            serve_key(state.clone(), headers, path.into())
        };
        let first = get("app.js", vec![]).await;
        assert_eq!(first.status(), StatusCode::OK);
        assert_eq!(first.headers()[header::CACHE_CONTROL], "public, no-cache");
        let tag = first.headers()[header::ETAG].to_str().unwrap().to_owned();
        assert_eq!(tag, format!("\"{}\"", deployment.artifact_version.clone()));

        let again = get("app.js", vec![("if-none-match", tag.clone())]).await;
        assert_eq!(again.status(), StatusCode::NOT_MODIFIED);
        assert_eq!(again.headers()[header::ETAG], tag.as_str());
        assert!(axum::body::to_bytes(again.into_body(), 1024).await.unwrap().is_empty());
        let weak = get("app.js", vec![("if-none-match", format!("\"other\", W/{tag}"))]).await;
        assert_eq!(weak.status(), StatusCode::NOT_MODIFIED);

        // A navigation still resolves its file, so the page view counts.
        let page = get("index.html", vec![("if-none-match", tag.clone()), ("sec-fetch-dest", "document".into())]).await;
        assert_eq!(page.status(), StatusCode::NOT_MODIFIED);
        usage::flush();
        let today = usage::day(now_ms());
        let usage = usage::read_usage(&crate::layout::usage(&root, &deployment.id), &today, &today).unwrap();
        assert!(usage["totals"].as_array().unwrap().iter().any(|row| row["kind"] == "page_view" && row["name"] == "index.html"));

        // A publish changes the tag, so the old one gets the new bytes.
        deploy_files(&state, json!({"index.html": "<p>home</p>", "app.js": "2"})).await;
        for deployment in state.deployments.write().await.values_mut() {
            deployment.manifest["visibility"] = json!("public");
        }
        let fresh = get("app.js", vec![("if-none-match", tag.clone())]).await;
        assert_eq!(fresh.status(), StatusCode::OK);
        assert_ne!(fresh.headers()[header::ETAG], tag.as_str());
        assert_eq!(&axum::body::to_bytes(fresh.into_body(), 1024).await.unwrap()[..], b"2");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[test]
    fn a_private_apps_files_stay_out_of_shared_caches() {
        let deployment = Settings::new("app", "App", "app", &json!({"visibility": "private"}))
            .deployment(Installed { hostname: "app.localhost".into(), created_at: 1, released_at: None, source_digest: None, actions: "{}".into(), artifact_version: "v1".into(), released: None }, "http://localhost");
        assert_eq!(ArtifactCache::of(&deployment).control(), "private, no-cache");
    }

    #[test]
    fn a_record_without_a_release_time_reads_its_first_publish() {
        let installed: Installed =
            serde_json::from_value(json!({"hostname": "app.localhost", "createdAt": 7, "actions": "{}", "artifactVersion": "v1"})).unwrap();
        let deployment = Settings::new("app", "App", "app", &json!({"visibility": "public"})).deployment(installed, "http://localhost");
        assert_eq!(deployment.released_at, 7);
        assert_eq!(serde_json::to_value(&deployment).unwrap()["releasedAt"], json!(7));
    }

    #[tokio::test]
    async fn a_republish_moves_the_release_time_and_keeps_the_first_publish() {
        let root = std::env::temp_dir().join(format!("konae-released-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        let first = deploy_files(&state, json!({"index.html": "<p>one</p>"})).await;
        assert!(first["releasedAt"].as_u64().unwrap() >= first["createdAt"].as_u64().unwrap());
        tokio::time::sleep(std::time::Duration::from_millis(5)).await;
        let second = deploy_files(&state, json!({"index.html": "<p>two</p>"})).await;
        assert_eq!(second["createdAt"], first["createdAt"]);
        assert!(second["releasedAt"].as_u64().unwrap() > first["releasedAt"].as_u64().unwrap());
        let id = second["id"].as_str().unwrap();
        let record: Value = serde_json::from_slice(&std::fs::read(crate::layout::record(&root, id)).unwrap()).unwrap();
        assert_eq!(record["releasedAt"], second["releasedAt"]);
        let loaded = load_deployments(&root, "http://localhost").await.unwrap();
        assert_eq!(json!(loaded.values().next().unwrap().released_at), second["releasedAt"]);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn deployment_loading_recovers_legacy_files_after_an_operator_settings_write() {
        let root = std::env::temp_dir().join(format!("konae-load-legacy-files-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        deploy_files(&state, json!({"index.html":"<script>miniapp.files.list()</script>"})).await;
        let id = state.deployments.read().await.values().next().unwrap().id.clone();
        let path = layout::settings(&root, &id);
        let mut raw: Value = serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
        raw.as_object_mut().unwrap().remove("modules");
        std::fs::write(&path, serde_json::to_vec(&raw).unwrap()).unwrap();
        Settings::read(&root, &id).unwrap().write(&root).await.unwrap();
        let loaded = load_deployments(&root, "http://localhost").await.unwrap();
        assert!(loaded.values().next().unwrap().modules["files"]["on"] == true);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn konae_load_decides_legacy_auth_before_existing_accounts_sign_in() {
        let root = std::env::temp_dir().join(format!("konae-legacy-auth-load-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        let released = deploy_files(&state, json!({"index.html": "<p>Members</p>"})).await;
        let id = released["id"].as_str().unwrap();
        let original = state.deployments.read().await.values().find(|deployment| deployment.id == id).unwrap().clone();
        accounts::app_store(&state, &original).unwrap().signup("member@example.test", "correct horse battery").unwrap();
        let settings_path = layout::settings(&root, id);
        let mut old: Value = serde_json::from_slice(&std::fs::read(&settings_path).unwrap()).unwrap();
        old["modules"].as_object_mut().unwrap().remove("auth");
        std::fs::write(&settings_path, serde_json::to_vec(&old).unwrap()).unwrap();

        let loaded = load_deployments(&root, "http://localhost").await.unwrap();
        let deployment = loaded.values().find(|deployment| deployment.id == id).unwrap();
        assert_eq!(deployment.modules["auth"]["on"], true);
        let auth = accounts::app_store(&state, deployment).unwrap();
        let session = auth.login("member@example.test", "correct horse battery").unwrap();
        assert!(auth.authenticate(Some(&session.token)).unwrap().is_some());
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_release_names_the_digest_of_the_sources_it_carried() {
        let root = std::env::temp_dir().join(format!("konae-source-digest-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        let first = deploy_files(&state, json!({"index.html": "<p>one</p>"})).await;
        let sources = [("actions.json", "{\"version\":1,\"actions\":{}}"), ("schema.sql", "")];
        let expected = sources::digest(sources.iter().map(|(path, text)| (*path, text.as_bytes())));
        assert_eq!(first["sourceDigest"], json!(expected));
        let id = first["id"].as_str().unwrap();
        let record: Value = serde_json::from_slice(&std::fs::read(crate::layout::record(&root, id)).unwrap()).unwrap();
        assert_eq!(record["sourceDigest"], json!(expected));
        // A write that is not a release keeps the digest.
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        persist_deployment(&state, &deployment).await.unwrap();
        let loaded = load_deployments(&root, "http://localhost").await.unwrap();
        assert_eq!(loaded.values().next().unwrap().source_digest.as_deref(), Some(expected.as_str()));
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[test]
    fn a_record_without_a_source_digest_names_none() {
        let installed: Installed =
            serde_json::from_value(json!({"hostname": "app.localhost", "createdAt": 7, "actions": "{}", "artifactVersion": "v1"})).unwrap();
        let deployment = Settings::new("app", "App", "app", &json!({"visibility": "public"})).deployment(installed, "http://localhost");
        assert_eq!(deployment.source_digest, None);
        assert!(serde_json::to_value(&deployment).unwrap().get("sourceDigest").is_none());
    }

    #[tokio::test]
    async fn republish_stops_serving_files_missing_from_the_new_artifact() {
        let root = std::env::temp_dir().join(format!("konae-republish-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        let first = deploy_files(
            &state,
            json!({"index.html": "<p>one</p>", "old.js": "1", "assets/old.css": "a{}"}),
        )
        .await;
        let id = first["id"].as_str().unwrap().to_owned();
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        assert_eq!(read_artifact(&state, &deployment, "old.js").await.unwrap(), b"1");

        deploy_files(&state, json!({"index.html": "<p>two</p>", "new.js": "2"})).await;
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        assert_eq!(deployment.id, id);
        assert_eq!(read_artifact(&state, &deployment, "index.html").await.unwrap(), b"<p>two</p>");
        assert_eq!(read_artifact(&state, &deployment, "new.js").await.unwrap(), b"2");
        assert!(read_artifact(&state, &deployment, "old.js").await.is_err());
        assert!(read_artifact(&state, &deployment, "assets/old.css").await.is_err());
        assert!(staged_or_retired(&root, &id).is_empty(), "only dist/ holds files");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn new_deployments_pick_a_policy_from_visibility_and_redeploys_keep_it() {
        for (visibility, expected) in [("public", SignupMode::Open), ("private", SignupMode::Closed)] {
            let root = std::env::temp_dir().join(format!("konae-policy-{}", Uuid::new_v4()));
            tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
            let state = test_state(&root);
            let first = deploy_with_visibility(&state, json!({"index.html": "<p>one</p>"}), visibility).await;
            assert_eq!(first["signupPolicy"]["mode"], json!(expected), "visibility={visibility}");

            set_policy(&state, SignupMode::Allowlist, &["@example.test"]).await;
            let second = deploy_with_visibility(&state, json!({"index.html": "<p>two</p>"}), visibility).await;
            assert_eq!(second["signupPolicy"], json!({"mode": "allowlist", "allowlist": ["@example.test"]}));
            let id = second["id"].as_str().unwrap();
            let stored = Settings::read(&root, id).unwrap();
            assert_eq!(stored.signup_policy.mode, SignupMode::Allowlist);
            let mut legacy = state.deployments.read().await.values().find(|deployment| deployment.id == id).unwrap().clone();
            legacy.manifest["runtime"] = json!({"database":{"mode":"declared-actions"}});
            assert!(released_settings(&legacy).manifest.get("runtime").is_none());
            let _ = tokio::fs::remove_dir_all(root).await;
        }
    }

    #[tokio::test]
    async fn an_operation_completes_a_legacy_applied_snapshot_from_live_files_and_database() {
        let root = std::env::temp_dir().join(format!("konae-legacy-operation-snapshot-{}", Uuid::new_v4()));
        let id = "app_legacy_operation";
        let settings = Settings::new(id, "Applied", "applied", &json!({"version":1,"visibility":"public"}));
        settings.write(&root).await.unwrap();
        tokio::fs::create_dir_all(crate::layout::dist(&root, id)).await.unwrap();
        tokio::fs::write(crate::layout::dist(&root, id).join("index.html"), "old applied artifact").await.unwrap();
        let database = crate::layout::database(&root, id);
        tokio::fs::create_dir_all(database.parent().unwrap()).await.unwrap();
        rusqlite::Connection::open(&database).unwrap().execute_batch("CREATE TABLE \"live notes\"(id INTEGER PRIMARY KEY, title TEXT); CREATE INDEX \"live notes title\" ON \"live notes\"(title); INSERT INTO \"live notes\" VALUES(1,'kept');").unwrap();
        let installed = Installed {
            hostname: "applied.localhost".into(), created_at: 1, released_at: Some(2), source_digest: Some("old-source".into()),
            actions: r#"{"version":1,"actions":{"applied.read":{"kind":"query","access":"anonymous","statement":"SELECT title FROM \"live notes\" LIMIT 5","bindings":[]}}}"#.into(),
            artifact_version: "v-old".into(), released: None,
        };
        tokio::fs::create_dir_all(crate::layout::private(&root, id)).await.unwrap();
        tokio::fs::write(crate::layout::record(&root, id), serde_json::to_vec(&installed).unwrap()).await.unwrap();
        let state = test_state(&root);
        let deployment = settings.deployment(installed, "http://localhost");
        state.deployments.write().await.insert(deployment.hostname.clone(), deployment.clone());

        let mut operated = deployment;
        operated.signup_policy = SignupPolicy::from_input(SignupMode::Closed, &[]).unwrap();
        persist_deployment(&state, &operated).await.unwrap();

        let migrated = Settings::read(&root, id).unwrap().released.unwrap();
        assert_eq!(migrated.signup_policy.mode, SignupMode::Closed);
        assert!(migrated.schema_sql.contains("CREATE TABLE IF NOT EXISTS \"live notes\""));
        assert!(migrated.schema_sql.contains("CREATE INDEX IF NOT EXISTS \"live notes title\""));
        let expected_digest = crate::folder::version_of(&HashMap::from([("index.html".to_owned(), b"old applied artifact".to_vec())]));
        assert_eq!(migrated.artifact_digest.as_deref(), Some(expected_digest.as_str()));
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn republishing_a_public_app_as_private_closes_an_open_signup() {
        // (first visibility, policy the owner set, second visibility, expected)
        let cases = [
            ("public", None, "private", json!({"mode": "closed", "allowlist": []})),
            (
                "public",
                Some((SignupMode::Allowlist, "@example.test")),
                "private",
                json!({"mode": "allowlist", "allowlist": ["@example.test"]}),
            ),
            // The owner opened a private app on purpose; a redeploy keeps that.
            ("private", Some((SignupMode::Open, "")), "private", json!({"mode": "open", "allowlist": []})),
            ("private", None, "public", json!({"mode": "closed", "allowlist": []})),
        ];
        for (first, chosen, second, expected) in cases {
            let root = std::env::temp_dir().join(format!("konae-flip-{}", Uuid::new_v4()));
            tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
            let state = test_state(&root);
            deploy_with_visibility(&state, json!({"index.html": "<p>one</p>"}), first).await;
            if second == "private" {
                let mut deployment = state.deployments.read().await.values().next().unwrap().clone();
                deployment.modules.get_mut("auth").unwrap()["on"] = json!(true);
                Settings::of(&deployment).write(&root).await.unwrap();
                state.deployments.write().await.insert(deployment.hostname.clone(), deployment);
            }
            if let Some((mode, entry)) = chosen {
                let entries: Vec<&str> = if entry.is_empty() { vec![] } else { vec![entry] };
                set_policy(&state, mode, &entries).await;
            }
            let republished = deploy_with_visibility(&state, json!({"index.html": "<p>two</p>"}), second).await;
            assert_eq!(republished["signupPolicy"], expected, "{first} {chosen:?} -> {second}");
            let id = republished["id"].as_str().unwrap();
            let stored = Settings::read(&root, id).unwrap();
            assert_eq!(serde_json::to_value(&stored.signup_policy).unwrap(), expected);
            let _ = tokio::fs::remove_dir_all(root).await;
        }
    }

    #[tokio::test]
    async fn signup_checks_input_first_and_gives_one_answer_for_closed_and_unlisted() {
        let root = std::env::temp_dir().join(format!("konae-signup-oracle-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "public").await;
        let attempt = |email: &'static str, password: &'static str| {
            let state = state.clone();
            let headers = headers.clone();
            async move {
                let body = json!({"email": email, "password": password});
                let request = Request::builder().body(Body::from(body.to_string())).unwrap();
                let response = signup(State(state), headers, request).await;
                let status = response.status();
                let bytes = axum::body::to_bytes(response.into_body(), 4096).await.unwrap();
                (status, serde_json::from_slice::<Value>(&bytes).unwrap()["error"].clone())
            }
        };
        set_policy(&state, SignupMode::Allowlist, &["listed@example.test"]).await;
        // A weak password gets the same answer whether or not the address is listed.
        let listed = attempt("listed@example.test", "x").await;
        let unlisted = attempt("other@example.test", "x").await;
        assert_eq!(listed.0, StatusCode::BAD_REQUEST);
        assert_eq!(listed, unlisted);
        assert_eq!(attempt("not-an-email", "correct horse battery").await.0, StatusCode::BAD_REQUEST);
        let refused = attempt("other@example.test", "correct horse battery").await;
        assert_eq!(refused.0, StatusCode::FORBIDDEN);
        set_policy(&state, SignupMode::Closed, &[]).await;
        assert_eq!(attempt("listed@example.test", "correct horse battery").await, refused);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[test]
    fn app_databases_are_capped_in_size() {
        let root = std::env::temp_dir().join(format!("konae-cap-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        initialize_database(&path).unwrap();
        let db = Connection::open(&path).unwrap();
        restrict_database(&db).unwrap();
        db.authorizer::<fn(AuthContext<'_>) -> Authorization>(None).unwrap();
        let page_size: u64 = db.query_row("PRAGMA page_size", [], |r| r.get(0)).unwrap();
        let pages: u64 = db.query_row("PRAGMA max_page_count", [], |r| r.get(0)).unwrap();
        assert_eq!(pages * page_size, MAX_APP_DATABASE_BYTES);
        drop(db);

        let db = Connection::open(&path).unwrap();
        db.execute_batch("CREATE TABLE notes(body TEXT)").unwrap();
        limit_database_size(&db, 64 * 1024).unwrap();
        let mut full = None;
        for _ in 0..100 {
            if let Err(error_value) = db.execute("INSERT INTO notes VALUES (?1)", ["x".repeat(4000)]) {
                full = Some(error_value.to_string());
                break;
            }
        }
        assert!(full.expect("the cap must stop writes").contains("full"));
        let _ = std::fs::remove_dir_all(root);
    }


    fn staged_or_retired(root: &Path, id: &str) -> Vec<String> {
        std::fs::read_dir(layout::private(root, id))
            .unwrap()
            .map(|entry| entry.unwrap().file_name().into_string().unwrap())
            .filter(|name| name.starts_with("dist-") || name.starts_with("server-"))
            .collect()
    }


    fn release_body(id: &str, schema: &str, actions: Value, page: &str, confirmation: Option<String>) -> Value {
        json!({
            "project": {
                "id": id, "name": "Steps", "slug": "steps", "manifest": {},
                "files": {"actions.json": json!({"version": 1, "actions": actions}).to_string(), "schema.sql": schema}
            },
            "visibility": "public",
            "artifact": {"version": 1, "entrypoint": "index.html", "files": {"index.html": page}},
            "schemaConfirmation": confirmation
        })
    }

    #[tokio::test]
    async fn a_static_release_with_only_seo_creates_no_action_database_and_serves_its_page() {
        let root = std::env::temp_dir().join(format!("konae-static-release-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = AppState::for_test(&root);
        let id = "app_static_home";
        let body = json!({
            "project":{"id":id,"name":"Home","slug":"home","manifest":{"version":1,"visibility":"public"},"files":{"index.html":"<!doctype html><title>Konae</title>"}},
            "visibility":"public",
            "initialModules":{"seo":{"on":true}},
            "artifact":{"version":1,"entrypoint":"index.html","files":{"index.html":"<!doctype html><title>Konae</title>"}}
        });
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let status = response.status();
        let bytes = axum::body::to_bytes(response.into_body(), 100_000).await.unwrap();
        assert_eq!(status, StatusCode::OK, "{}", String::from_utf8_lossy(&bytes));
        let deployment = state.deployments.read().await.values().find(|deployment| deployment.id == id).unwrap().clone();
        assert_eq!(deployment.modules["seo"]["on"], true);
        assert_eq!(deployment.modules["actions"]["on"], false);
        assert!(!database_path(&state, id).exists());
        assert!(!crate::layout::identity(&root, id).exists());
        let html = read_artifact(&state, &deployment, "index.html").await.unwrap();
        let html = String::from_utf8(html).unwrap();
        assert!(html.contains("<title>Konae</title>"));
        assert!(!html.contains("runtime.js"));
        let reloaded = load_deployments(&root, "http://localhost").await.unwrap();
        assert_eq!(reloaded.values().find(|deployment| deployment.id == id).unwrap().modules["seo"]["on"], true);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_first_release_refuses_unknown_module_options_from_an_import_package() {
        let root = std::env::temp_dir().join(format!("konae-invalid-package-modules-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = AppState::for_test(&root);
        let mut body = release_body("app_bad_package_modules", "", json!({}), "<p>Home</p>", None);
        body["initialPackage"] = json!({
            "manifest": {
                "format": "konae-package", "version": 1, "packageId": "pkg_bad_modules", "createdAt": 1,
                "deploymentId": "dep_source", "projectId": "project_source", "visibility": "public",
                "modules": {
                    "actions": {"on": false},
                    "seo": {"on": true, "canonical": "path", "image": null, "futureOption": true}
                },
                "publishedRevision": 1, "contents": [], "excluded": []
            },
            "components": {}
        });
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let status = response.status();
        let message = String::from_utf8(axum::body::to_bytes(response.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(message.contains("Unknown option futureOption for module seo."), "{message}");
        assert!(!crate::layout::settings(&root, "app_bad_package_modules").exists());
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn deployment_loading_skips_one_app_with_an_unknown_module_option() {
        let root = std::env::temp_dir().join(format!("konae-load-invalid-module-option-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        for (id, hostname, invalid) in [
            ("app_bad_option", "bad.localhost", true),
            ("app_good_option", "good.localhost", false),
        ] {
            tokio::fs::create_dir_all(crate::layout::private(&root, id)).await.unwrap();
            let mut settings = Settings::new(id, id, id, &json!({"visibility":"public"}));
            if invalid { settings.modules.get_mut("seo").unwrap()["futureOption"] = json!(true); }
            settings.write(&root).await.unwrap();
            let installed = Installed {
                hostname: hostname.into(), created_at: 1, released_at: Some(1), source_digest: None,
                actions: r#"{"version":1,"actions":{}}"#.into(), artifact_version: "v1".into(), released: None,
            };
            tokio::fs::write(crate::layout::record(&root, id), serde_json::to_vec(&installed).unwrap()).await.unwrap();
        }
        let loaded = load_deployments(&root, "http://localhost").await.unwrap();
        assert_eq!(loaded.len(), 1);
        assert!(loaded.values().any(|deployment| deployment.id == "app_good_option"));
        assert!(!loaded.values().any(|deployment| deployment.id == "app_bad_option"));
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_release_with_schema_and_actions_off_gets_the_module_refusal() {
        let root = std::env::temp_dir().join(format!("konae-schema-actions-off-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = AppState::for_test(&root);
        let mut body = release_body("app_schema_actions_off", "CREATE TABLE notes(id INTEGER PRIMARY KEY);", json!({}), "<main>Home</main>", None);
        body["initialModules"] = json!({"actions":{"on":false}});
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let status = response.status();
        let message = String::from_utf8(axum::body::to_bytes(response.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert_eq!(status, StatusCode::BAD_REQUEST, "{message}");
        assert!(message.contains("Module actions is off"), "{message}");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn an_actions_key_in_another_json_file_does_not_turn_on_actions() {
        let root = std::env::temp_dir().join(format!("konae-other-json-actions-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = AppState::for_test(&root);
        let mut body = release_body("app_other_json_actions", "", json!({}), "<main>Home</main>", None);
        body["initialModules"] = json!({"actions":{"on":false}});
        body["project"]["files"]["public/keys.json"] = json!("{\"actions\":{\"jump\":\"Space\"}}");
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let status = response.status();
        let message = String::from_utf8(axum::body::to_bytes(response.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
        assert_eq!(status, StatusCode::OK, "{message}");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn release_checks_files_before_actions_when_both_modules_are_off() {
        let root = std::env::temp_dir().join(format!("konae-files-before-actions-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = AppState::for_test(&root);
        let mut body = release_body("app_files_before_actions", "", json!({"notes.list":{"kind":"query","statement":"SELECT 1"}}), "<main>Home</main>", None);
        body["initialModules"] = json!({"actions":{"on":false},"files":{"on":false}});
        body["artifact"]["files"]["app.js"] = json!("miniapp.files.list()");
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let refused = response_json(response).await;
        assert_eq!(refused["code"], "module.off");
        assert_eq!(refused["error"], "Module files is off. Turn it on with module_set or App settings for a published app, or in the folder's konae.json for a local run.");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_static_whole_document_can_release_without_a_browser_sdk_module() {
        let root = std::env::temp_dir().join(format!("konae-static-whole-document-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = AppState::for_test(&root);
        let mut body = release_body("app_static_whole_document", "", json!({}), "<!doctype html><title>Static</title>", None);
        body["initialModules"] = json!({"actions":{"on":false},"auth":{"on":false},"files":{"on":false}});
        body["project"]["files"].as_object_mut().unwrap().remove("actions.json");
        body["project"]["files"].as_object_mut().unwrap().remove("schema.sql");
        let response = deploy(&state, body.to_string().as_bytes()).await;
        assert_eq!(response.status(), StatusCode::OK);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn release_swaps_fresh_baseline_and_existing_data_transformations() {
        let root = std::env::temp_dir().join(format!("konae-release-transform-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        let id = "app_transform_release";
        let schema = "CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, body TEXT NOT NULL);";
        let actions = json!({
            "notes.list": {"kind":"query", "access":"anonymous", "statement":"SELECT body FROM notes ORDER BY id LIMIT 10", "bindings": []}
        });
        let v1 = json!({
            "id": "baseline", "predecessor": null,
            "before": format!("sha256:{}", "0".repeat(64)),
            "after": schema_transform::fingerprint_schema(schema).unwrap(),
            "maxRows": 10, "statements": ["CREATE TABLE notes(id INTEGER PRIMARY KEY, body TEXT NOT NULL)"]
        });
        let document = json!({"version": 1, "transitions": [v1.clone()]}).to_string();
        let mut first = release_body(id, schema, actions.clone(), "<p>first</p>", None);
        first["project"]["files"]["schema-transforms.json"] = json!(document);
        let response = deploy(&state, first.to_string().as_bytes()).await;
        let status = response.status();
        let bytes = axum::body::to_bytes(response.into_body(), 100_000).await.unwrap();
        assert_eq!(status, StatusCode::OK, "{}", String::from_utf8_lossy(&bytes));

        async fn read_notes(state: &AppState) -> (StatusCode, String) {
            let deployment = state.deployments.read().await.values().next().unwrap().clone();
            let mut headers = HeaderMap::new();
            headers.insert(header::HOST, deployment.hostname.parse().unwrap());
            let response = invoke_action(State(state.clone()), AxumPath("notes.list".into()), headers, Json(json!({}))).await;
            let status = response.status();
            let body = String::from_utf8(axum::body::to_bytes(response.into_body(), 100_000).await.unwrap().to_vec()).unwrap();
            (status, body)
        }

        assert_eq!(read_notes(&state).await.0, StatusCode::OK, "fresh baseline schema must reach the live database");
        let database = database_path(&state, id);
        Connection::open(&database).unwrap().execute("INSERT INTO notes(body) VALUES('before')", []).unwrap();
        let fingerprint = schema_transform::fingerprint(&Connection::open(&database).unwrap()).unwrap();
        let v2 = json!({
            "id": "rewrite", "predecessor": "baseline",
            "before": fingerprint, "after": schema_transform::fingerprint_schema(schema).unwrap(),
            "maxRows": 1, "statements": ["UPDATE notes SET body='after' WHERE id=1"]
        });
        let update_document = json!({"version": 1, "transitions": [v1, v2]}).to_string();
        let mut second = release_body(id, schema, actions, "<p>second</p>", None);
        second["project"]["files"]["schema-transforms.json"] = json!(update_document);
        let input: DeployInput = serde_json::from_value(second.clone()).unwrap();
        let confirmation = runtime::validate_release(&state, &input, None).await.unwrap().confirmation().unwrap();
        second["schemaConfirmation"] = json!(confirmation);
        let response = deploy(&state, second.to_string().as_bytes()).await;
        let status = response.status();
        let bytes = axum::body::to_bytes(response.into_body(), 100_000).await.unwrap();
        assert_eq!(status, StatusCode::OK, "{}", String::from_utf8_lossy(&bytes));
        let (status, body) = read_notes(&state).await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert!(body.contains("after"), "the release must swap the staged transformed data: {body}");

        let restarted = test_state(&root);
        let deployment = folder::open(&restarted, id, None).await.unwrap();
        let (status, body) = read_notes(&restarted).await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert!(body.contains("after"), "the transformed rows must survive a restart: {body}");
        let db = Connection::open(database_path(&restarted, id)).unwrap();
        let history = schema_transform::load_history(&db).unwrap();
        assert_eq!(history.entries.len(), 2);
        assert!(history.entries[0].baseline_skipped);
        assert_eq!(history.entries[1].id, "rewrite");
        assert_eq!(history.entries[1].affected_rows, 1);
        assert_eq!(deployment.id, id);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn a_release_that_fails_at_any_step_leaves_the_old_actions_on_the_old_rows() {
        let list = |table: &str, column: &str| json!({"kind": "query", "access": "anonymous", "statement": format!("SELECT {column} FROM {table} ORDER BY id LIMIT 50"), "bindings": []});
        let both = "CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, body TEXT NOT NULL);\nCREATE TABLE IF NOT EXISTS tags(id INTEGER PRIMARY KEY, name TEXT NOT NULL);\n";
        let notes_only = "CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, body TEXT NOT NULL);\n";
        for step in ["stage_local_artifact", "stage_server", "schema_change", "stage_sources", "persist_deployment", "swap_sources", "switch_dist", "switch_server"] {
            let root = std::env::temp_dir().join(format!("konae-release-step-{}", Uuid::new_v4()));
            tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
            let state = test_state(&root);
            let id = format!("app_{step}");
            let mut first = release_body(&id, both, json!({"notes.list": list("notes", "body"), "tags.list": list("tags", "name")}), "<p>one</p>", None);
            functions::tests::add_function(&mut first, "export function handle() { return new Response('A'); }");
            let response = deploy(&state, first.to_string().as_bytes()).await;
            let status = response.status();
            let bytes = axum::body::to_bytes(response.into_body(), 100_000).await.unwrap();
            assert_eq!(status, StatusCode::OK, "{step}: {}", String::from_utf8_lossy(&bytes));
            Connection::open(database_path(&state, &id)).unwrap()
                .execute_batch("INSERT INTO notes(body) VALUES ('kept note'); INSERT INTO tags(name) VALUES ('old tag');").unwrap();
            let live = state.deployments.read().await.values().next().cloned().unwrap();
            let app = crate::layout::sources(&root, &id);
            let first_actions = std::fs::read(app.join("actions.json")).unwrap();
            assert!(!crate::layout::private(&root, &id).join("sources.json").exists());


            let mut second = release_body(&id, notes_only, json!({"notes.list": list("notes", "body")}), "<p>two</p>", None);
            functions::tests::add_function(&mut second, "export function handle() { return new Response('B'); }");
            second.as_object_mut().unwrap().remove("initialModules");
            let input: DeployInput = serde_json::from_value(second.clone()).unwrap();
            let confirmation = runtime::validate_release(&state, &input, None).await.unwrap().confirmation();
            assert!(confirmation.is_some(), "dropping tags loses a row");
            second["schemaConfirmation"] = json!(confirmation);
            FAILING_RELEASE_STEPS.lock().unwrap().push((id.clone(), step));
            assert_ne!(deploy(&state, second.to_string().as_bytes()).await.status(), StatusCode::OK, "{step}");
            FAILING_RELEASE_STEPS.lock().unwrap().retain(|(app, _)| app != &id);

            let call = |name: &'static str| {
                let state = state.clone();
                let mut headers = HeaderMap::new();
                headers.insert(header::HOST, live.hostname.parse().unwrap());
                async move {
                    let response = invoke_action(State(state), AxumPath(name.into()), headers, Json(json!({}))).await;
                    let status = response.status();
                    (status, String::from_utf8(axum::body::to_bytes(response.into_body(), 100_000).await.unwrap().to_vec()).unwrap())
                }
            };
            let (status, body) = call("tags.list").await;
            assert_eq!(status, StatusCode::OK, "{step}: {body}");
            assert!(body.contains("old tag"), "{step}: {body}");
            assert!(call("notes.list").await.1.contains("kept note"), "{step}");
            let serving = state.deployments.read().await.values().next().cloned().unwrap();
            assert_eq!(serving.artifact_version, live.artifact_version, "{step}");
            let record: Value = serde_json::from_slice(&std::fs::read(crate::layout::record(&root, &id)).unwrap()).unwrap();
            assert_eq!(record["artifactVersion"], json!(live.artifact_version), "{step}: the record names the release memory serves");
            assert_eq!(read_artifact(&state, &serving, "index.html").await.unwrap(), b"<p>one</p>", "{step}");
            assert_eq!(std::fs::read(crate::layout::dist(&root, &id).join("index.html")).unwrap(), b"<p>one</p>", "{step}: dist/ is the first release's");
            assert_eq!(std::fs::read(app.join("actions.json")).unwrap(), first_actions, "{step}: app/ is the first release's");
            assert!(!crate::layout::private(&root, &id).join("sources.json").exists(), "{step}: the release does not write editor metadata outside app/");
            let restored = functions::read_artifact(&layout::server(&root, &id)).unwrap().unwrap();
            assert!(restored.bundles["orders"].contains("'A'"), "{step}");
            assert_eq!(serving.server, live.server, "{step}");
            let mut restarted = test_state(&root);
            restarted.execution_mode = execution::ExecutionMode::Live;
            let reopened = folder::open(&restarted, &id, None).await.unwrap();
            assert_eq!(reopened.server, live.server, "{step}");
            assert!(staged_or_retired(&root, &id).is_empty(), "{step}: no staged files stay");
            let staged_sources: Vec<_> = std::fs::read_dir(crate::layout::private(&root, &id)).unwrap()
                .map(|entry| entry.unwrap().file_name().into_string().unwrap())
                .filter(|name| name.starts_with("app-")).collect();
            assert!(staged_sources.is_empty(), "{step}: {staged_sources:?}");
            let leftovers: Vec<_> = std::fs::read_dir(crate::layout::private(&root, &id)).unwrap()
                .map(|entry| entry.unwrap().file_name().into_string().unwrap())
                .filter(|name| name.starts_with("release-")).collect();
            assert!(leftovers.is_empty(), "{step}: {leftovers:?}");

            // The same release goes through once nothing fails.
            assert_eq!(deploy(&state, second.to_string().as_bytes()).await.status(), StatusCode::OK, "{step}");
            assert_ne!(std::fs::read(app.join("actions.json")).unwrap(), first_actions, "{step}: app/ is the second release's");
            assert_eq!(call("tags.list").await.0, StatusCode::NOT_FOUND, "{step}");
            assert!(call("notes.list").await.1.contains("kept note"), "{step}");
            let _ = tokio::fs::remove_dir_all(root).await;
        }
    }

    #[tokio::test]
    async fn a_failed_record_write_removes_the_new_artifact_version() {
        let root = std::env::temp_dir().join(format!("konae-orphan-{}", Uuid::new_v4()));
        tokio::fs::create_dir_all(crate::layout::apps(&root)).await.unwrap();
        let state = test_state(&root);
        let first = deploy_files(&state, json!({"index.html": "<p>one</p>"})).await;
        let id = first["id"].as_str().unwrap().to_owned();
        let record = crate::layout::record(&root, &id);
        tokio::fs::remove_file(&record).await.unwrap();
        tokio::fs::create_dir_all(record.join("blocker")).await.unwrap();
        let body = json!({
            "project": {
                "id": "app_republish", "name": "Republish", "slug": "republish", "manifest": {},
                "files": {"actions.json": "{\"version\":1,\"actions\":{}}", "schema.sql": ""}
            },
            "visibility": "public",
            "artifact": {"version": 1, "entrypoint": "index.html", "files": {"index.html": "<p>two</p>"}}
        });
        assert_eq!(deploy(&state, body.to_string().as_bytes()).await.status(), StatusCode::INTERNAL_SERVER_ERROR);
        assert!(staged_or_retired(&root, &id).is_empty(), "the staged files are gone");
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        assert_eq!(read_artifact(&state, &deployment, "index.html").await.unwrap(), b"<p>one</p>");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn restoring_a_backup_first_backs_up_the_live_database() {
        let root = std::env::temp_dir().join(format!("konae-restore-{}", Uuid::new_v4()));
        let (state, _) = login_test_state(&root, "public").await;
        let deployment_id = state.deployments.read().await.values().next().unwrap().id.clone();
        let id = deployment_id.as_str();
        let path = database_path(&state, id);
        initialize_database(&path).unwrap();
        Connection::open(&path)
            .unwrap()
            .execute_batch("CREATE TABLE notes(body TEXT); INSERT INTO notes VALUES ('old');")
            .unwrap();
        let backup = create_backup(&state, id, "Manual backup").await.unwrap();
        Connection::open(&path)
            .unwrap()
            .execute("INSERT INTO notes VALUES ('newer')", [])
            .unwrap();
        restore_backup(&state, id, backup["id"].as_str().unwrap()).await.unwrap();

        let backups = list_backups(&state, id).await.unwrap();
        let before = backups
            .iter()
            .find(|item| item["label"] == "Before restore")
            .expect("restore must keep a copy of the live database");
        let snapshot = crate::layout::backups(&root, &id)
            .join(format!("{}.sqlite", before["id"].as_str().unwrap()));
        let rows: i64 = Connection::open(snapshot)
            .unwrap()
            .query_row("SELECT COUNT(*) FROM notes", [], |row| row.get(0))
            .unwrap();
        assert_eq!(rows, 2);
        let rows: i64 = Connection::open(&path)
            .unwrap()
            .query_row("SELECT COUNT(*) FROM notes", [], |row| row.get(0))
            .unwrap();
        assert_eq!(rows, 1);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    pub fn signed_in(state: &AppState, deployment_id: &str, headers: &HeaderMap, email: &str) -> (HeaderMap, String) {
        let auth = AuthService::open(
            crate::layout::identity(&state
                .data_root, &deployment_id),
        )
        .unwrap();
        let session = auth.signup(email, "correct horse battery").unwrap();
        let mut headers = headers.clone();
        headers.insert(
            header::COOKIE,
            format!("konae_app_session={}", session.token).parse().unwrap(),
        );
        (headers, session.user.user_id)
    }

    pub async fn response_json(response: Response) -> Value {
        let bytes = axum::body::to_bytes(response.into_body(), 1_000_000).await.unwrap();
        serde_json::from_slice(&bytes).unwrap()
    }

    #[tokio::test]
    async fn upload_refuses_to_overwrite_an_unreadable_file_index() {
        let root = std::env::temp_dir().join(format!("konae-upload-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "public").await;
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        let (headers, _) = signed_in(&state, &deployment.id, &headers, "owner@example.test");
        let files = crate::layout::files(&root, &deployment.id);
        tokio::fs::create_dir_all(&files).await.unwrap();
        tokio::fs::write(files.join("index.json"), "{not json").await.unwrap();
        let body = json!({"name": "a.txt", "type": "text/plain", "dataUrl": "data:text/plain;base64,aGk="});
        let request = Request::builder().body(Body::from(body.to_string())).unwrap();
        let response = upload_file(State(state.clone()), headers.clone(), request).await;
        assert_eq!(response.status(), StatusCode::INTERNAL_SERVER_ERROR);
        assert_eq!(tokio::fs::read(files.join("index.json")).await.unwrap(), b"{not json");

        tokio::fs::remove_file(files.join("index.json")).await.unwrap();
        let request = Request::builder().body(Body::from(body.to_string())).unwrap();
        let response = upload_file(State(state), headers, request).await;
        assert_eq!(response.status(), StatusCode::OK);
        assert!(response_json(response).await["result"].get("sha256").is_none());
        let index: Vec<Value> =
            serde_json::from_slice(&tokio::fs::read(files.join("index.json")).await.unwrap()).unwrap();
        assert_eq!(index.len(), 1);
        assert_eq!(index[0]["visibility"], "private");
        assert_eq!(index[0]["sha256"], digest(b"hi"));
        let leftovers = std::fs::read_dir(&files)
            .unwrap()
            .filter(|entry| entry.as_ref().unwrap().file_name().to_string_lossy().contains(".tmp-"))
            .count();
        assert_eq!(leftovers, 0);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn files_off_refuses_upload_listing_and_read_with_the_module_sentence() {
        let root = std::env::temp_dir().join(format!("konae-files-off-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "public").await;
        let mut deployments = state.deployments.write().await;
        deployments.values_mut().next().unwrap().modules.get_mut("files").unwrap()["on"] = json!(false);
        drop(deployments);
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        let (headers, _) = signed_in(&state, &deployment.id, &headers, "owner@example.test");
        let expected = "Module files is off. Turn it on with module_set or App settings for a published app, or in the folder's konae.json for a local run.";
        let upload = Request::builder().body(Body::from(json!({"name":"a.txt","type":"text/plain","dataUrl":"data:text/plain;base64,aGk="}).to_string())).unwrap();
        for response in [
            upload_file(State(state.clone()), headers.clone(), upload).await,
            list_files(State(state.clone()), headers.clone()).await,
            serve_file(State(state.clone()), AxumPath("missing".into()), headers.clone()).await,
        ] {
            let body = response_json(response).await;
            assert_eq!(body["error"], expected);
            assert_eq!(body["code"], "module.off");
        }
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn release_refuses_a_capsule_that_uses_files_while_the_module_is_off() {
        let state = AppState::for_test(&std::env::temp_dir().join(format!("konae-files-release-off-{}", Uuid::new_v4())));
        let body = json!({
            "project": {"id":"files_off","name":"Files off","slug":"files-off","manifest":{},"files":{"actions.json":"{\"version\":1,\"actions\":{}}","schema.sql":""}},
            "visibility":"public",
            "artifact":{"version":1,"entrypoint":"index.html","files":{"index.html":"<main>app</main>","app.js":"miniapp.files.upload(file)"}},
            "initialModules":{"files":{"on":false}}
        });
        let response = deploy(&state, body.to_string().as_bytes()).await;
        let refused = response_json(response).await;
        assert_eq!(refused["error"], "Module files is off. Turn it on with module_set or App settings for a published app, or in the folder's konae.json for a local run.");
        assert_eq!(refused["code"], "module.off");
    }

    #[tokio::test]
    async fn files_are_private_to_the_uploader_unless_marked_public() {
        let root = std::env::temp_dir().join(format!("konae-files-{}", Uuid::new_v4()));
        let (state, headers) = login_test_state(&root, "public").await;
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        let (alice, alice_id) = signed_in(&state, &deployment.id, &headers, "alice@example.test");
        let (bob, _) = signed_in(&state, &deployment.id, &headers, "bob@example.test");
        let body = |visibility: Option<&str>| {
            let mut value = json!({"name": "a.txt", "type": "text/plain", "dataUrl": "data:text/plain;base64,aGk="});
            if let Some(visibility) = visibility {
                value["visibility"] = json!(visibility);
            }
            Request::builder().body(Body::from(value.to_string())).unwrap()
        };

        let anonymous = upload_file(State(state.clone()), headers.clone(), body(None)).await;
        assert_eq!(anonymous.status(), StatusCode::UNAUTHORIZED);

        let private_file = response_json(upload_file(State(state.clone()), alice.clone(), body(None)).await).await;
        assert_eq!(private_file["result"]["visibility"], "private");
        assert_eq!(private_file["result"]["ownerId"], alice_id);
        let private_id = private_file["result"]["id"].as_str().unwrap().to_owned();

        let public_file = response_json(upload_file(State(state.clone()), alice.clone(), body(Some("public"))).await).await;
        let public_id = public_file["result"]["id"].as_str().unwrap().to_owned();

        let alice_list = response_json(list_files(State(state.clone()), alice.clone()).await).await;
        assert_eq!(alice_list["result"].as_array().unwrap().len(), 2);
        assert!(alice_list["result"].as_array().unwrap().iter().any(|file| file["ownerId"] == alice_id));

        let bob_list = response_json(list_files(State(state.clone()), bob.clone()).await).await;
        assert_eq!(bob_list["result"].as_array().unwrap().len(), 1);
        assert_eq!(bob_list["result"][0]["id"], public_id);
        assert!(bob_list["result"][0].get("ownerId").is_none());

        let visitor_list = response_json(list_files(State(state.clone()), headers.clone()).await).await;
        assert_eq!(visitor_list["result"][0]["id"], public_id);
        assert!(visitor_list["result"][0].get("ownerId").is_none());

        assert_eq!(
            serve_file(State(state.clone()), AxumPath(private_id.clone()), bob.clone()).await.status(),
            StatusCode::NOT_FOUND
        );
        assert_eq!(
            serve_file(State(state.clone()), AxumPath(private_id.clone()), headers.clone()).await.status(),
            StatusCode::NOT_FOUND
        );
        assert_eq!(
            serve_file(State(state.clone()), AxumPath(private_id), alice.clone()).await.status(),
            StatusCode::OK
        );
        assert_eq!(
            serve_file(State(state.clone()), AxumPath(public_id.clone()), headers).await.status(),
            StatusCode::OK
        );

        let legacy_id = Uuid::new_v4().to_string();
        let directory = crate::layout::files(&root, &deployment.id);
        tokio::fs::write(directory.join(format!("{legacy_id}.blob")), b"hi").await.unwrap();
        let mut index: Vec<Value> = serde_json::from_slice(&tokio::fs::read(directory.join("index.json")).await.unwrap()).unwrap();
        index.push(json!({"id": legacy_id, "name": "old.txt", "type": "text/plain", "size": 2, "createdAt": 1}));
        tokio::fs::write(directory.join("index.json"), serde_json::to_vec(&index).unwrap()).await.unwrap();
        let after_legacy = response_json(list_files(State(state.clone()), alice).await).await;
        assert!(after_legacy["result"].as_array().unwrap().iter().all(|file| file["id"] != legacy_id));
        assert_eq!(
            serve_file(State(state.clone()), AxumPath(legacy_id), bob).await.status(),
            StatusCode::NOT_FOUND
        );

        let (private_state, private_headers) = login_test_state(&root.join("private"), "private").await;
        let private_deployment = private_state.deployments.read().await.values().next().cloned().unwrap();
        assert_eq!(
            list_files(State(private_state.clone()), private_headers.clone()).await.status(),
            StatusCode::UNAUTHORIZED
        );
        let (member, _) = signed_in(&private_state, &private_deployment.id, &private_headers, "member@example.test");
        assert_eq!(list_files(State(private_state), member).await.status(), StatusCode::OK);

        let _ = tokio::fs::remove_dir_all(root).await;
    }

    fn query_definition(statement: &str) -> ActionDefinition {
        let program: ActionProgram = serde_json::from_value(json!({"version": 1, "actions": {
            "rows.read": {"kind": "query", "access": "anonymous", "statement": statement, "bindings": []}
        }})).unwrap();
        program.actions["rows.read"].clone()
    }

    fn converted_after<T>(work: impl FnOnce() -> T) -> (T, usize) {
        COLUMNS_CONVERTED.with(|count| count.set(0));
        let value = work();
        (value, COLUMNS_CONVERTED.with(|count| count.get()))
    }



    const THREE_BLOBS: &str = "SELECT zeroblob(700000) a, zeroblob(700000) b, zeroblob(700000) c";

    #[test]
    fn an_action_result_stops_being_read_once_it_passes_2_mib() {
        let root = std::env::temp_dir().join(format!("konae-row-cap-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap();
        let (outcome, converted) = converted_after(|| run_query(&path, &query_definition(THREE_BLOBS), Vec::new()));
        assert_eq!(outcome.unwrap_err().to_string(), "Query result exceeds 2 MiB or 1000 rows.");
        assert_eq!(converted, 1, "the column that passes the cap is the last one read");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn browse_refuses_an_oversized_row_before_converting_its_values() {
        let root = std::env::temp_dir().join(format!("konae-browse-row-cap-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap().execute_batch(
            "CREATE TABLE items(payload BLOB); INSERT INTO items VALUES (zeroblob(1100000));",
        ).unwrap();
        let (outcome, converted) = converted_after(|| browse_table(&path, &json!({"tableName": "items"})));
        assert_eq!(outcome.err().unwrap().to_string(), QUERY_RESULT_TOO_LARGE);
        assert_eq!(converted, 1, "the row id is accounted before the oversized payload is read");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn browse_keeps_its_row_shape_for_ordinary_values() {
        let root = std::env::temp_dir().join(format!("konae-browse-row-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap().execute_batch(
            "CREATE TABLE items(name TEXT, done INTEGER); INSERT INTO items VALUES ('task', 1);",
        ).unwrap();
        let (outcome, _) = converted_after(|| browse_table(&path, &json!({"tableName": "items"})));
        let result = outcome.unwrap();
        assert_eq!(result["totalRows"], 1);
        assert_eq!(result["rows"], json!([{"rowId": 1, "values": {"name": "task", "done": 1}}]));
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn action_result_budget_counts_column_names_before_converting_values() {
        let root = std::env::temp_dir().join(format!("konae-column-name-cap-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap();
        let alias = "a".repeat(16_000);
        let statement = format!("WITH RECURSIVE rows(n) AS (SELECT 1 UNION ALL SELECT n + 1 FROM rows WHERE n < 140) SELECT NULL AS \"{alias}\" FROM rows");
        let (outcome, converted) = converted_after(|| run_query(&path, &query_definition(&statement), Vec::new()));
        assert_eq!(outcome.err().unwrap().to_string(), QUERY_RESULT_TOO_LARGE);
        assert_eq!(converted, 130, "the oversized repeated column name is refused before value conversion");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn action_result_budget_counts_controls_in_lossy_text_before_conversion() {
        let root = std::env::temp_dir().join(format!("konae-invalid-text-cap-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap();
        let statement = "SELECT CAST(zeroblob(350000) || x'ff' AS TEXT) AS payload";
        let (outcome, converted) = converted_after(|| run_query(&path, &query_definition(statement), Vec::new()));
        assert_eq!(outcome.err().unwrap().to_string(), QUERY_RESULT_TOO_LARGE);
        assert_eq!(converted, 0, "the NUL escapes pass the byte cap before lossy text conversion");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn notify_refuses_an_oversized_returning_row_and_rolls_back() {
        let root = std::env::temp_dir().join(format!("konae-notify-row-cap-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap().execute_batch("CREATE TABLE items(payload BLOB);").unwrap();
        let definition: ActionDefinition = serde_json::from_value(json!({
            "kind": "mutation", "access": "anonymous",
            "statement": "INSERT INTO items(payload) VALUES (zeroblob(1100000))",
            "bindings": [],
            "notify": {"to": "owner", "changes": ["payload"], "subject": "Changed", "body": "{changes}"}
        })).unwrap();
        let (outcome, converted) = converted_after(|| run_mutation(&path, &definition, Vec::new()));
        assert_eq!(outcome.err().unwrap().to_string(), QUERY_RESULT_TOO_LARGE);
        assert_eq!(converted, 0, "the oversized returned payload is rejected before conversion");
        let count: i64 = Connection::open(&path).unwrap().query_row("SELECT count(*) FROM items", [], |row| row.get(0)).unwrap();
        assert_eq!(count, 0, "the mutation rolls back when its notice result exceeds the budget");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn owner_sql_stops_reading_a_result_once_it_passes_2_mib() {
        let root = std::env::temp_dir().join(format!("konae-admin-row-cap-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap();
        let (outcome, converted) = converted_after(|| run_admin_sql(&path, THREE_BLOBS));
        assert_eq!(outcome.unwrap_err().to_string(), "SQL result exceeds 2 MiB.");
        assert_eq!(converted, 1, "the column that passes the cap is the last one read");
        let _ = std::fs::remove_dir_all(root);
    }

    #[test]
    fn a_result_under_the_cap_comes_back_unchanged() {
        let root = std::env::temp_dir().join(format!("konae-row-small-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let path = root.join("database.sqlite");
        Connection::open(&path).unwrap();
        let sql = "SELECT x'00ff10' AS b, 'héllo \"q\"' AS t, 7 AS n, 1.5 AS r, NULL AS z";
        let expected = json!({"b": "00ff10", "t": "héllo \"q\"", "n": 7, "r": 1.5, "z": null});
        assert_eq!(run_query(&path, &query_definition(sql), Vec::new()).unwrap(), vec![expected.clone()]);
        assert_eq!(run_admin_sql(&path, sql).unwrap()["rows"], json!([expected]));
        let _ = std::fs::remove_dir_all(root);
    }



    async fn statement_cap_state(root: &Path) -> (AppState, HeaderMap, String) {
        let (mut state, headers) = login_test_state(root, "public").await;
        let program = json!({"version": 1, "actions": {
            "items.count": {"kind": "query", "access": "anonymous", "statement": "SELECT 1 AS n", "bindings": []},
            "items.broken": {"kind": "query", "access": "anonymous", "statement": "SELECT * FROM missing_table", "bindings": []},
            "items.route": {"kind": "query", "access": "anonymous", "statement": "SELECT 1 AS n LIMIT 1", "bindings": [], "http": {"method": "GET", "path": "/api/count"}}
        }});
        let mut id = String::new();
        for deployment in state.deployments.write().await.values_mut() {
            deployment.actions = program.to_string();
            deployment.manifest = json!({"visibility": "public"});
            deployment.modules.get_mut("http").unwrap()["on"] = json!(true);
            initialize_database(&database_path(&state, &deployment.id)).unwrap();
            id = deployment.id.clone();
        }
        state.guards = Arc::new(Guards::new(Vec::new()).with_statement_wait(std::time::Duration::from_millis(60)));
        (state, headers, id)
    }

    async fn hold_statements(state: &AppState, id: &str, count: usize) -> Vec<tokio::sync::OwnedSemaphorePermit> {
        let mut held = Vec::new();
        for _ in 0..count {
            held.push(state.guards.statement_permit(id).await.unwrap());
        }
        held
    }

    async fn call_action(state: &AppState, headers: &HeaderMap, name: &str) -> Response {
        invoke_action(State(state.clone()), AxumPath(name.into()), headers.clone(), Json(json!({}))).await
    }

    #[tokio::test]
    async fn a_fifth_action_statement_on_one_deployment_is_refused_while_another_is_served() {
        let root = std::env::temp_dir().join(format!("konae-statement-cap-{}", Uuid::new_v4()));
        let (state, headers, id) = statement_cap_state(&root).await;
        let _elsewhere = hold_statements(&state, "another-deployment", 4).await;
        assert_eq!(call_action(&state, &headers, "items.count").await.status(), StatusCode::OK, "another Deployment's slots do not count");
        let mut held = hold_statements(&state, &id, 4).await;
        let refused = call_action(&state, &headers, "items.count").await;
        assert_eq!(refused.status(), StatusCode::TOO_MANY_REQUESTS);
        assert!(refused.headers().contains_key(header::RETRY_AFTER));
        let body = axum::body::to_bytes(refused.into_body(), 4096).await.unwrap();
        assert_eq!(serde_json::from_slice::<Value>(&body).unwrap()["error"], "rate-limited");
        held.pop();
        assert_eq!(call_action(&state, &headers, "items.count").await.status(), StatusCode::OK, "a freed slot lets the next call run");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn an_action_statement_that_errors_releases_its_permit() {
        let root = std::env::temp_dir().join(format!("konae-statement-error-{}", Uuid::new_v4()));
        let (state, headers, id) = statement_cap_state(&root).await;
        let _held = hold_statements(&state, &id, 3).await;
        for _ in 0..5 {
            assert_eq!(call_action(&state, &headers, "items.broken").await.status(), StatusCode::BAD_REQUEST);
        }
        assert_eq!(call_action(&state, &headers, "items.count").await.status(), StatusCode::OK);
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn the_runtime_endpoint_answers_a_refused_statement_with_the_rate_limited_tool_error() {
        let root = std::env::temp_dir().join(format!("konae-statement-runtime-{}", Uuid::new_v4()));
        let (state, _, id) = statement_cap_state(&root).await;
        let _held = hold_statements(&state, &id, 4).await;
        let request = Request::builder()
            .method("POST")
            .uri("/_konae/mcp")
            .header(header::HOST, "login-test.localhost")
            .header(header::CONTENT_TYPE, "application/json")
            .body(Body::from(json!({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "actions_invoke", "arguments": {"name": "items.count"}}}).to_string()))
            .unwrap();
        let response = runtime::runtime(State(state.clone()), request).await;
        assert!(response.headers().contains_key(header::RETRY_AFTER));
        let body: Value = serde_json::from_slice(&axum::body::to_bytes(response.into_body(), 1 << 16).await.unwrap()).unwrap();
        assert_eq!(body["result"]["isError"], true);
        assert_eq!(body["result"]["content"][0]["text"], "rate-limited");
        let _ = tokio::fs::remove_dir_all(root).await;
    }

    #[tokio::test]
    async fn an_http_route_answers_a_refused_statement_with_the_rate_limited_response() {
        let root = std::env::temp_dir().join(format!("konae-statement-route-{}", Uuid::new_v4()));
        let (state, headers, id) = statement_cap_state(&root).await;
        let deployment = state.deployments.read().await.values().next().cloned().unwrap();
        let client: std::net::IpAddr = "192.0.2.1".parse().unwrap();
        let _held = hold_statements(&state, &id, 4).await;
        let refused = http::call_route(&state, &deployment, "GET", "/api/count", "", b"", &headers, client).await;
        assert_eq!(refused.status(), StatusCode::TOO_MANY_REQUESTS);
        assert!(refused.headers().contains_key(header::RETRY_AFTER));
        let body = axum::body::to_bytes(refused.into_body(), 4096).await.unwrap();
        assert_eq!(serde_json::from_slice::<Value>(&body).unwrap()["error"], "rate-limited");
        let _ = tokio::fs::remove_dir_all(root).await;
    }
}
