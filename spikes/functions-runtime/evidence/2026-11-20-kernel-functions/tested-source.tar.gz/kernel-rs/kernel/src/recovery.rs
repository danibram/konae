
use crate::installation::Installation;
use std::sync::{LazyLock, RwLock as SyncRwLock};

use anyhow::{Context, bail, ensure};
use aws_sdk_s3::primitives::ByteStream;
use rusqlite::params;

use super::copies::{CopyKey, Target};
use super::*;

pub const LEDGER_DIR: &str = "revocations";
pub const LEDGER_START: &str = "started.json";
/// In the data directory: the restore could not apply the record.
pub const HOLD_FILE: &str = "recovery-hold.json";

fn reconcile_usage() -> String {
    format!("Usage: {} reconcile --from <copy directory | s3://bucket/prefix> | --without-record", crate::program())
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct Entry {
    pub id: String,
    pub at: u64,
    /// `app-user`, `api-key`, or the kind of an account database the
    /// installation lists.
    pub kind: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub deployment_id: Option<String>,
    pub subject: String,
    /// `suspended` or `revoked`.
    pub state: String,
}

impl Entry {
    pub fn new(kind: &str, deployment_id: Option<&str>, subject: &str, state: &str) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            at: now_ms(),
            kind: kind.into(),
            deployment_id: deployment_id.map(str::to_owned),
            subject: subject.into(),
            state: state.into(),
        }
    }

    fn file_name(&self) -> String {
        format!("{:013}-{}.json", self.at, self.id)
    }

    #[cfg(test)]
    pub fn file_name_for_test(&self) -> String {
        self.file_name()
    }
}


static HOLDS: LazyLock<SyncRwLock<HashMap<PathBuf, Option<String>>>> = LazyLock::new(Default::default);

/// The message every paused request gets while a restore is unreconciled.
pub fn hold(data_root: &Path) -> Option<String> {
    let path = data_root.join(HOLD_FILE);
    if let Some(found) = HOLDS.read().unwrap_or_else(|poisoned| poisoned.into_inner()).get(&path) {
        return found.clone();
    }
    let held = match std::fs::read(&path) {
        Ok(bytes) => {
            let reason = serde_json::from_slice::<Value>(&bytes).ok().and_then(|v| v["reason"].as_str().map(str::to_owned)).unwrap_or_default();
            Some(format!(
                "This installation was restored from a copy and stays in maintenance until its record of suspensions and revocations is applied. {reason} The operator runs {} reconcile.", crate::program()
            ))
        }
        Err(error_value) if error_value.kind() == std::io::ErrorKind::NotFound => None,
        Err(_) => Some("This installation is in maintenance: its recovery state cannot be read.".into()),
    };
    HOLDS.write().unwrap_or_else(|poisoned| poisoned.into_inner()).insert(path, held.clone());
    held
}

pub fn set_hold(data_root: &Path, reason: &str) -> Result<()> {
    save_hold(data_root, reason, None)
}

fn save_hold(data_root: &Path, reason: &str, key_check: Option<&str>) -> Result<()> {
    write_file(data_root, HOLD_FILE, &serde_json::to_vec(&json!({"reason": reason, "at": now_ms(), "keyCheck": key_check}))?)?;
    HOLDS.write().unwrap_or_else(|poisoned| poisoned.into_inner()).remove(&data_root.join(HOLD_FILE));
    Ok(())
}

fn clear_hold(data_root: &Path) -> Result<()> {
    match std::fs::remove_file(data_root.join(HOLD_FILE)) {
        Ok(()) => {}
        Err(error_value) if error_value.kind() == std::io::ErrorKind::NotFound => {}
        Err(error_value) => return Err(error_value.into()),
    }
    HOLDS.write().unwrap_or_else(|poisoned| poisoned.into_inner()).remove(&data_root.join(HOLD_FILE));
    Ok(())
}


/// Writes `entry` to every copy target. With no target configured there is
/// no copy to restore and nothing to record.
/// With a key, an entry sent to S3 carries a `mac` bound to its file name.
pub async fn write(targets: &[Target], s3: Option<&S3Client>, bucket: &str, entry: &Entry, key: Option<&CopyKey>) -> Result<()> {
    let bytes = serde_json::to_vec(entry)?;
    for target in targets {
        match target {
            Target::BlocksDirectory(_) | Target::BlocksS3 { .. } => {
                append_record(target, s3, bucket, key, &entry.file_name(), serde_json::to_value(entry)?).await?;
            }
            Target::Directory(directory) => {
                let (directory, name, bytes) = (directory.join(LEDGER_DIR), entry.file_name(), bytes.clone());
                tokio::task::spawn_blocking(move || write_file(&directory, &name, &bytes)).await??;
            }
            Target::S3 { prefix } => {
                let s3 = s3.context("S3 is not configured.")?;
                let bytes = match key {
                    Some(key) => {
                        let mut value = serde_json::to_value(entry)?;
                        value["mac"] = Value::String(key.sign_entry(&entry.file_name(), entry)?);
                        serde_json::to_vec(&value)?
                    }
                    None => bytes.clone(),
                };
                s3.put_object()
                    .bucket(bucket)
                    .key(format!("{prefix}{LEDGER_DIR}/{}", entry.file_name()))
                    .body(ByteStream::from(bytes))
                    .send()
                    .await?;
            }
        }
    }
    Ok(())
}

fn write_file(directory: &Path, name: &str, bytes: &[u8]) -> Result<()> {
    use std::io::Write;
    std::fs::create_dir_all(directory)?;
    let temporary = directory.join(format!(".{name}.tmp"));
    let mut file = std::fs::File::create(&temporary)?;
    file.write_all(bytes)?;
    file.sync_all()?;
    std::fs::rename(temporary, directory.join(name))?;
    Ok(())
}

/// Records a change made by a running Kernel. The change already holds on
/// this volume; an error means it is not yet safe from a restore, and the
/// caller reports that instead of success.
pub async fn record(state: &AppState, entry: Entry) -> Result<()> {
    let targets = state.copies.ledger_targets();
    if targets.is_empty() {
        return Ok(());
    }
    write(targets, state.s3.as_ref(), &state.data_bucket, &entry, state.copies.key()).await.map_err(|error_value| {
        anyhow::anyhow!(
            "The change holds on this server, but it could not be recorded at the copy target, so a restore could undo it: {error_value:#}. Repeat the same request to record it."
        )
    })
}

/// Records a change made by an operator command, which runs without a
/// Kernel. Reads the copy settings from the environment.
pub fn record_offline(data_root: &Path, entry: Entry) -> Result<()> {
    let read = |name: &str| std::env::var(name).ok().filter(|value| !value.trim().is_empty());
    if ["KONAE_COPY_DIR", "KONAE_COPY_S3", "KONAE_COPY_V3_DIR", "KONAE_COPY_V3_S3"].iter().all(|name| read(name).is_none()) {
        return Ok(());
    }
    let run = async {
        let s3 = crate::copy_bucket_from_env()?;
        let Some(config) = copies::CopyConfig::from_env(data_root, s3.is_some())? else { return Ok(()) };
        let (client, bucket) = s3.map_or((None, String::new()), |(client, bucket)| (Some(client), bucket));
        write(&config.targets, client.as_ref(), &bucket, &entry, copies::CopyKey::from_env()?.as_ref()).await
    };
    let result = match tokio::runtime::Handle::try_current() {
        Ok(handle) => tokio::task::block_in_place(|| handle.block_on(run)),
        Err(_) => tokio::runtime::Builder::new_current_thread().enable_all().build()?.block_on(run),
    };
    result.context("The change holds on this server, but it could not be recorded at the copy target, so a restore could undo it. Run the command again")
}

async fn append_record(target: &Target, s3: Option<&S3Client>, bucket: &str, key: Option<&CopyKey>, name: &str, mut value: Value) -> Result<()> {
    let source = copies::blocks::source(target, s3, bucket)?;
    let repository = copies::blocks::source_identity(&source).context("Invalid v3 repository.")?;
    let mac = key.context("Set KONAE_COPY_SECRET for the revocation record.")?.record_mac(repository, name, &value)?;
    value["mac"] = Value::String(mac);
    konae_backup::blocks::append_record(&source, LEDGER_DIR, name, &serde_json::to_vec(&value)?).await
}

/// Marks a target as keeping a revocation record.
pub async fn start(target: &Target, s3: Option<&S3Client>, bucket: &str) -> Result<()> {
    let key = if matches!(target, Target::BlocksDirectory(_) | Target::BlocksS3 { .. }) {
        CopyKey::from_env()?
    } else { None };
    start_with_key(target, s3, bucket, key.as_ref()).await
}

pub(crate) async fn start_with_key(target: &Target, s3: Option<&S3Client>, bucket: &str, key: Option<&CopyKey>) -> Result<()> {
    let bytes = serde_json::to_vec(&json!({"version": 1}))?;
    match target {
        Target::BlocksDirectory(_) | Target::BlocksS3 { .. } => {
            append_record(target, s3, bucket, key, LEDGER_START, json!({"version":1})).await
        }
        Target::Directory(directory) => {
            let directory = directory.join(LEDGER_DIR);
            tokio::task::spawn_blocking(move || write_file(&directory, LEDGER_START, &bytes)).await?
        }
        Target::S3 { prefix } => {
            s3.context("S3 is not configured.")?
                .put_object()
                .bucket(bucket)
                .key(format!("{prefix}{LEDGER_DIR}/{LEDGER_START}"))
                .body(ByteStream::from(bytes))
                .send()
                .await?;
            Ok(())
        }
    }
}


/// Parses the record's files. `None` when a file does not parse, because a
/// record with a hole cannot prove an account was not suspended.
pub fn parse(files: &[Vec<u8>]) -> Result<Vec<Entry>> {
    files
        .iter()
        .map(|bytes| serde_json::from_slice::<Entry>(bytes).context("The revocation record holds a file that does not parse."))
        .collect()
}

/// Checks one S3 entry file against its MAC. An entry without a MAC, or with
/// one that does not verify, is refused.
pub fn check_signed(key: &CopyKey, name: &str, bytes: &[u8]) -> Result<()> {
    let value: Value = serde_json::from_slice(bytes).with_context(|| format!("The revocation record file {name} does not parse."))?;
    let entry: Entry = serde_json::from_value(value.clone()).with_context(|| format!("The revocation record file {name} does not parse."))?;
    match value.get("mac") {
        Some(Value::String(mac)) => {
            ensure!(
                key.verify_entry(name, &entry, mac)?,
                "The revocation record file {name} has a MAC that does not verify, so it was not written with this KONAE_COPY_SECRET or was altered."
            );
            Ok(())
        }
        Some(_) => bail!("The revocation record file {name} has a MAC that does not verify, so it was not written with this KONAE_COPY_SECRET or was altered."),
        None => bail!("The revocation record file {name} carries no MAC, so someone without this KONAE_COPY_SECRET wrote it."),
    }
}

fn identity_path(root: &Path, installation: &Installation, entry: &Entry) -> Option<PathBuf> {
    if let Some(account) = installation.account_for_kind(&entry.kind) {
        return Some(root.join(account.file));
    }
    let app = entry.deployment_id.as_deref()?;
    (!app.is_empty() && !app.contains(['/', '\\', '.'])).then(|| layout::identity(root, app))
}

/// The custodian supplies the hash of one entry recorded after the cut.
/// Read the same subject before and after applying the verified record.
pub(crate) fn prove_revocation(
    root: &Path, installation: &Installation, record: Result<Option<Vec<Vec<u8>>>>, hash: &str, cut: u64,
) -> Result<usize> {
    use sha2::{Digest, Sha256};
    let files = record?.context("The required revocation record could not be read.")?;
    let bytes = files.iter().find(|entry| hex::encode(Sha256::digest(entry)) == hash)
        .context("The required revocation entry is absent from the verified record.")?;
    let entry: Entry = serde_json::from_slice(bytes)?;
    ensure!(entry.at > cut, "The required revocation must follow the selected cut.");
    let path = identity_path(root, installation, &entry).context("The required revocation has no identity store.")?;
    let db = Connection::open_with_flags(path, rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY)?;
    let query = match (entry.kind.as_str(), entry.state.as_str()) {
        ("clerk-owner", "suspended") => "SELECT suspended FROM creator_identities WHERE owner=?1",
        ("api-key", "revoked") => "SELECT revoked_at IS NOT NULL FROM api_keys WHERE id=?1",
        (kind, "suspended") if kind == "app-user" || installation.account_for_kind(kind).is_some() =>
            "SELECT state='suspended' FROM app_users WHERE id=?1",
        _ => bail!("The required entry must suspend an account or revoke an API key."),
    };
    let applied = || db.query_row(query, [&entry.subject], |row| row.get::<_, bool>(0));
    ensure!(!applied()?, "The required revocation already holds at the cut.");
    let changed = reconcile(root, installation, &parse(&files)?)?;
    ensure!(applied()?, "The required revocation did not take effect.");
    Ok(changed)
}

/// Applies the record to a data directory that is not serving. Only the
/// newest entry for each account or key counts, and only a suspension or a
/// revocation changes anything: a restore never lifts a suspension.
/// Returns how many rows changed.
pub fn reconcile(root: &Path, installation: &Installation, entries: &[Entry]) -> Result<usize> {
    let mut latest: HashMap<(String, Option<String>, String), &Entry> = HashMap::new();
    for entry in entries {
        let app_entry = matches!(entry.kind.as_str(), "app-user" | "api-key");
        let expected = if entry.kind == "api-key" { "revoked" } else { "suspended" };
        ensure!(entry.state == expected && !entry.subject.is_empty() && !entry.id.is_empty()
            && (app_entry || installation.account_for_kind(&entry.kind).is_some())
            && if app_entry { entry.deployment_id.as_deref().is_some_and(crate::runtime::valid_app_id) }
               else { entry.deployment_id.is_none() }, "Invalid subject, scope or state in the revocation record.");
        let key = (entry.kind.clone(), entry.deployment_id.clone(), entry.subject.clone());
        let newer = latest.get(&key).is_none_or(|seen| (entry.at, &entry.id) > (seen.at, &seen.id));
        if newer {
            latest.insert(key, entry);
        }
    }
    let mut changed = 0;
    for entry in latest.values() {
        let Some(identity) = identity_path(root, installation, entry) else { continue };
        if !identity.try_exists()? {
            continue;
        }
        let db = Connection::open_with_flags(&identity, rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE)?;
        changed += match (entry.kind.as_str(), entry.state.as_str()) {
            ("clerk-owner", "suspended") if table_exists(&db, "creator_identities")? =>
                db.execute("UPDATE creator_identities SET suspended=1 WHERE owner=?1 AND suspended=0", [&entry.subject])?,
            ("clerk-owner", _) => 0,
            (kind, "suspended") if kind == "app-user" || installation.account_for_kind(kind).is_some() => {
                let mut rows = db.execute("UPDATE app_users SET state='suspended' WHERE id=?1 AND state<>'suspended'", [&entry.subject])?;
                rows += db.execute("DELETE FROM app_sessions WHERE user_id=?1", [&entry.subject])?;
                if table_exists(&db, "account_challenges")? {
                    rows += db.execute("DELETE FROM account_challenges WHERE user_id=?1 AND consumed_at IS NULL", [&entry.subject])?;
                }
                rows
            }
            ("api-key", "revoked") if table_exists(&db, "api_keys")? => db.execute(
                "UPDATE api_keys SET revoked_at=?1 WHERE id=?2 AND revoked_at IS NULL",
                params![now_ms() as i64, entry.subject],
            )?,
            _ => 0,
        };
    }
    Ok(changed)
}

/// Applies the record read from a copy source, or holds the installation.
/// Returns how many rows changed, or the reason it held.
pub fn apply_or_hold(root: &Path, installation: &Installation, record: Result<Option<Vec<Vec<u8>>>>) -> Result<std::result::Result<usize, String>> {
    apply_or_hold_for_key(root, installation, record, None)
}

pub(crate) fn apply_or_hold_for_key(root: &Path, installation: &Installation, record: Result<Option<Vec<Vec<u8>>>>,
    key_check: Option<&str>) -> Result<std::result::Result<usize, String>> {
    let reason = match record {
        Ok(Some(files)) => match parse(&files).and_then(|entries| reconcile(root, installation, &entries)) {
            Ok(changed) => return Ok(Ok(changed)),
            Err(error_value) => format!("{error_value:#}"),
        },
        Ok(None) => format!("The copy source has no {LEDGER_DIR}/{LEDGER_START}, so the record cannot be read."),
        Err(error_value) => format!("The record could not be read: {error_value:#}"),
    };
    save_hold(root, &reason, key_check)?;
    Ok(Err(reason))
}

/// Load a restored installation and exercise its health route in process.
pub async fn drill_check(installation: &Installation) -> Result<bool> {
    if std::env::args().nth(1).as_deref() != Some("drill-check") {
        return Ok(false);
    }
    let startup = Startup::from_env()?;
    ensure!(startup.execution_mode.is_test(), "drill-check requires KONAE_EXECUTION_MODE=test.");
    ensure!(startup.data_root.is_dir(), "The restored directory is missing.");
    super::copies::check_activation(&startup.data_root)?;
    ensure!(hold(&startup.data_root).is_none(), "The revocation record needs reconciliation.");
    let denied = |error: Option<std::io::Error>| error.is_some_and(|e| e.kind() == std::io::ErrorKind::PermissionDenied);
    ensure!(denied(std::net::TcpListener::bind(("127.0.0.1", 0)).err()), "The drill must deny listeners before loading the Kernel.");
    let outbound = std::net::TcpStream::connect_timeout(&([127, 0, 0, 1], 9).into(), std::time::Duration::from_secs(1));
    ensure!(denied(outbound.err()), "The drill must deny outbound connections before loading the Kernel.");
    let _operation = crate::file_store::external_operation(&startup.data_root)?;
    let (state, _) = state_from_env(&startup, installation.clone(), "recovery-drill-local-mail-key-only", Vec::new(), None).await?;
    let deployments = state.deployments.read().await.len();
    let request = Request::builder().uri("/_konae/health").body(Body::empty())?;
    let response = tower::ServiceExt::oneshot(stack(state, Router::new()), request).await?;
    ensure!(response.status().is_success(), "The restored Kernel failed its health check.");
    println!("{}", json!({"version": env!("CARGO_PKG_VERSION"), "loadedDeployments": deployments}));
    Ok(true)
}

/// The `reconcile` command. Returns false for any other command.
pub async fn operator_command(installation: &Installation) -> Result<bool> {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(String::as_str) != Some("reconcile") {
        return Ok(false);
    }
    let root = PathBuf::from(std::env::var("KONAE_DATA_DIR").unwrap_or_else(|_| "/data".into()));
    ensure!(matches!(args.as_slice(), [_, option] if option == "--without-record")
        || matches!(args.as_slice(), [_, option, _] if option == "--from"), "{}", reconcile_usage());
    ensure!(root.is_dir(), "The restored directory is missing.");
    let _volume = crate::file_store::hold_while_stopped(&root, "reconcile")?;
    super::copies::check_activation(&root)?;
    match args.get(1).map(String::as_str) {
        Some("--without-record") if args.len() == 2 => {
            clear_hold(&root)?;
            println!(
                "Reopened {} without the revocation record. Accounts suspended and API keys revoked after the restored copy may be active again; check them in each app's Users view and revoke again. Start the Kernel again.",
                root.display()
            );
        }
        Some("--from") if args.len() == 3 => {
            #[derive(Deserialize)]
            #[serde(rename_all = "camelCase")]
            struct Hold { key_check: Option<String> }
            let path = root.join(HOLD_FILE);
            let key_check = if path.try_exists()? {
                serde_json::from_slice::<Hold>(&std::fs::read(path)?)?.key_check
            } else { None };
            let key = copies::CopyKey::from_env()?;
            let record = match copies::record_source(&args[2]).await {
                Err(error) => Err(error),
                Ok(source) => {
                    if let Some(required) = &key_check {
                        let actual = copies::ledger_binding(&source, key.as_ref());
                        let reason = if required.starts_with("v3/") {
                            "Use the selected v3 repository and its revocation key to reconcile."
                        } else {
                            "The installation stays in maintenance. Use the signed S3 revocation record and the copy's KONAE_COPY_SECRET."
                        };
                        ensure!(actual.as_ref() == Some(required), "{reason}");
                    }
                    copies::read_source_record(&source, key.as_ref()).await
                }
            };
            match apply_or_hold_for_key(&root, installation, record, key_check.as_deref())? {
                Ok(changed) => {
                    clear_hold(&root)?;
                    println!(
                        "Applied the revocation record to {}: {changed} rows changed. Start the Kernel again.",
                        root.display()
                    );
                }
                Err(reason) => bail!("The installation stays in maintenance. {reason}"),
            }
        }
        _ => bail!("{}", reconcile_usage()),
    }
    Ok(true)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::auth::AuthService;

    fn scratch() -> PathBuf {
        std::env::temp_dir().join(format!("konae-recovery-{}", Uuid::new_v4()))
    }

    #[tokio::test]
    async fn entries_reach_every_directory_target_and_parse_back() {
        let (one, two) = (scratch(), scratch());
        let targets = [Target::Directory(one.clone()), Target::Directory(two.clone())];
        start(&targets[0], None, "data").await.unwrap();
        let entry = Entry::new("app-user", Some("app-1"), "user-1", "suspended");
        write(&targets, None, "data", &entry, None).await.unwrap();
        for root in [&one, &two] {
            let files = std::fs::read_dir(root.join(LEDGER_DIR)).unwrap().count();
            assert!(files >= 1);
        }
        let record = copies::read_record(one.to_str().unwrap(), None).await.unwrap().unwrap();
        assert_eq!(parse(&record).unwrap(), vec![entry]);
        assert!(copies::read_record(two.to_str().unwrap(), None).await.unwrap().is_none(), "no started.json means no readable record");
        std::fs::remove_dir_all(one).unwrap();
        std::fs::remove_dir_all(two).unwrap();
    }

    fn state_with(root: &Path, target: &Path) -> AppState {
        let config = copies::CopyConfig { targets: vec![Target::Directory(target.to_owned())], interval: std::time::Duration::from_secs(3600) };
        AppState {
            copies: Arc::new(copies::CopyStatus::new(Some(&config))),
            ..AppState::for_test(&root)
        }
    }

    #[tokio::test]
    async fn a_change_is_confirmed_only_once_it_is_off_the_volume() {
        let (root, target) = (scratch(), scratch());
        std::fs::create_dir_all(&root).unwrap();
        record(&state_with(&root, &target), Entry::new("api-key", Some("app-1"), "key-1", "revoked")).await.unwrap();
        assert_eq!(std::fs::read_dir(target.join(LEDGER_DIR)).unwrap().count(), 1);
        let blocked = scratch();
        std::fs::write(&blocked, "not a directory").unwrap();
        let refused = record(&state_with(&root, &blocked), Entry::new("api-key", Some("app-1"), "key-2", "revoked")).await.unwrap_err().to_string();
        assert!(refused.contains("could not be recorded at the copy target") && refused.contains("Repeat the same request"), "{refused}");
        for path in [root, target] {
            std::fs::remove_dir_all(path).unwrap();
        }
        std::fs::remove_file(blocked).unwrap();
    }

    #[test]
    fn a_restore_never_revives_a_suspended_account_or_a_revoked_key() {
        let root = scratch();
        let folder = crate::layout::folder(&root, "app-1");
        std::fs::create_dir_all(folder.join("data")).unwrap();
        let app = AuthService::open(folder.join("data/identity.sqlite")).unwrap();
        let kept = app.signup("kept@example.test", "correct horse battery").unwrap();
        let gone = app.signup("gone@example.test", "correct horse battery").unwrap();
        Connection::open(folder.join("data/identity.sqlite"))
            .unwrap()
            .execute_batch("CREATE TABLE api_keys(id TEXT PRIMARY KEY, revoked_at INTEGER); INSERT INTO api_keys VALUES('key-1', NULL), ('key-2', NULL);")
            .unwrap();
        let creators = AuthService::open(root.join("accounts.sqlite")).unwrap();
        let creator = creators.signup("creator@example.test", "correct horse battery").unwrap();
        let entries = vec![
            Entry::new("app-user", Some("app-1"), &gone.user.user_id, "suspended"),
            Entry::new("api-key", Some("app-1"), "key-1", "revoked"),
            Entry::new("installation-account", None, &creator.user.user_id, "suspended"),
        ];
        let mut invalid = entries.clone();
        invalid.push(Entry::new("app-user", Some("../app-1"), &kept.user.user_id, "suspended"));
        assert!(reconcile(&root, &crate::installation::Installation::for_test(), &invalid).unwrap_err().to_string().contains("Invalid subject"));
        assert!(reconcile(&root, &crate::installation::Installation::for_test(), &entries).unwrap() >= 4);
        let state = |path: &Path, id: &str| -> String {
            Connection::open(path).unwrap().query_row("SELECT state FROM app_users WHERE id=?1", [id], |r| r.get(0)).unwrap()
        };
        assert_eq!(state(&folder.join("data/identity.sqlite"), &gone.user.user_id), "suspended");
        assert_ne!(state(&folder.join("data/identity.sqlite"), &kept.user.user_id), "suspended");
        assert_eq!(state(&root.join("accounts.sqlite"), &creator.user.user_id), "suspended");
        let sessions: i64 = Connection::open(folder.join("data/identity.sqlite"))
            .unwrap()
            .query_row("SELECT COUNT(*) FROM app_sessions WHERE user_id=?1", [&gone.user.user_id], |r| r.get(0))
            .unwrap();
        assert_eq!(sessions, 0);
        let revoked: Vec<(String, Option<i64>)> = {
            let db = Connection::open(folder.join("data/identity.sqlite")).unwrap();
            let mut query = db.prepare("SELECT id, revoked_at FROM api_keys ORDER BY id").unwrap();
            query.query_map([], |r| Ok((r.get(0)?, r.get(1)?))).unwrap().map(Result::unwrap).collect()
        };
        assert!(revoked[0].1.is_some() && revoked[1].1.is_none());
        assert_eq!(reconcile(&root, &crate::installation::Installation::for_test(), &entries).unwrap(), 0);
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn the_witness_must_change_its_subject_after_the_cut() {
        use sha2::{Digest, Sha256};
        let root = scratch();
        let folder = layout::data(&root, "one");
        std::fs::create_dir_all(&folder).unwrap();
        let db = Connection::open(folder.join("identity.sqlite")).unwrap();
        db.execute_batch("CREATE TABLE api_keys(id TEXT PRIMARY KEY, revoked_at INTEGER);
                          INSERT INTO api_keys VALUES('retired', NULL), ('other', NULL)").unwrap();
        let entry = Entry::new("api-key", Some("one"), "retired", "revoked");
        let bytes = serde_json::to_vec(&entry).unwrap();
        let hash = hex::encode(Sha256::digest(&bytes));
        let prove = |cut| prove_revocation(&root, &Installation::kernel(), Ok(Some(vec![bytes.clone()])), &hash, cut);
        assert!(prove(entry.at).unwrap_err().to_string().contains("must follow"));
        assert_eq!(prove(entry.at - 1).unwrap(), 1);
        assert!(prove(entry.at - 1).unwrap_err().to_string().contains("already holds"));
        assert!(db.query_row("SELECT revoked_at IS NULL FROM api_keys WHERE id='other'", [], |r| r.get::<_, bool>(0)).unwrap());
        drop(db);
        std::fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn an_unreadable_record_holds_the_installation_until_reconciled() {
        let root = scratch();
        std::fs::create_dir_all(&root).unwrap();
        let reason = apply_or_hold(&root, &crate::installation::Installation::for_test(), Ok(None)).unwrap().unwrap_err();
        assert!(reason.contains("started.json"));
        assert!(hold(&root).unwrap().contains("reconcile"));
        assert!(super::super::maintenance::pause(&root, "any-app").is_some());
        assert!(super::super::maintenance::holds_mail(&root, "installation"));
        let broken = apply_or_hold(&root, &crate::installation::Installation::for_test(), Ok(Some(vec![b"{not json".to_vec()]))).unwrap().unwrap_err();
        assert!(broken.contains("does not parse"));
        let failed = apply_or_hold(&root, &crate::installation::Installation::for_test(), Err(anyhow::anyhow!("bucket unreachable"))).unwrap().unwrap_err();
        assert!(failed.contains("bucket unreachable"));
        assert_eq!(apply_or_hold(&root, &crate::installation::Installation::for_test(), Ok(Some(Vec::new()))).unwrap(), Ok(0));
        clear_hold(&root).unwrap();
        assert!(hold(&root).is_none());
        std::fs::remove_dir_all(root).unwrap();
    }
}
