
use std::{
    sync::Mutex,
    time::{Duration, Instant},
};

use anyhow::{Context, bail, ensure};
use axum::extract::Query;
use ring::rand::{SecureRandom, SystemRandom};
use ring::signature::{RSA_PKCS1_2048_8192_SHA256, RsaPublicKeyComponents};
use rusqlite::params;
use sha2::{Digest, Sha256};

use super::*;
use auth::{IdentityIntent, IdentityOutcome, VerifiedIdentity};

const FLOW_TTL_SECONDS: i64 = 10 * 60;
const MAX_JWKS_BYTES: usize = 64 * 1024;
const REFETCH_COOLDOWN: Duration = Duration::from_secs(60);
const MAX_TOKEN_RESPONSE_BYTES: usize = 64 * 1024;
pub const CALLBACK_PATH: &str = "/_konae/auth/google/callback";
const START_PATH: &str = "/_konae/auth/google/start";

/// The project secrets that hold the app's Google client.
pub const CLIENT_ID: &str = "google_client_id";
pub const CLIENT_SECRET: &str = "google_client_secret";

/// Whether `name` is one of the two secrets that hold the app's Google client.
pub fn is_client_name(name: &str) -> bool {
    name == CLIENT_ID || name == CLIENT_SECRET
}

/// The refusal for a Deployment whose owner has not turned Google on, or
/// whose Google client is not set on this installation.
pub const NOT_ON: &str = "Google sign-in is not turned on for this app.";
/// `module_set` refuses google with this while either secret is unset.
pub const NEEDS_CLIENT: &str = "Set this app's Google client ID and client secret before turning Google on.";
pub const NAMES_RESERVED: &str = "google_client_id and google_client_secret hold this app's Google client. Set them with use google.";
pub const NAMES_ONLY: &str = "A secret with use google is named google_client_id or google_client_secret.";
pub const ID_LOOKS_LIKE_SECRET: &str = "This looks like the client secret. The client ID ends with .apps.googleusercontent.com.";
const FAILED: &str = "Google sign-in failed. Start again from the sign-in page.";
const UNVERIFIED: &str = "Google has not verified this email address, so it cannot sign in here.";
pub const NOT_AUTHORITATIVE: &str =
    "This Google account uses an email address Google does not manage, so it cannot sign in here. Sign in with email and password.";
const CHECKS: &str = "Google's answer did not pass its checks. Start again from the sign-in page.";
const STALE: &str = "This Google sign-in expired or was already used. Start again from the sign-in page.";
const OTHER_BROWSER: &str = "This Google sign-in started in another browser. Start again from the sign-in page.";
/// The home address shares its origin with every path address and has no
/// callback of its own, so Google does not start there.
pub const NOT_ON_HOME: &str =
    "Google sign-in does not run on the installation's home address. Open this app on its own address to continue with Google.";

/// `secret_delete` refuses a Google secret with this while Google is on.
pub fn still_on(name: &str) -> String {
    format!("Google sign-in is on for this app and needs {name}. Turn Google off before deleting it.")
}

const AUTHORIZE: &str = "https://accounts.google.com/o/oauth2/v2/auth";
const TOKEN: &str = "https://oauth2.googleapis.com/token";
const JWKS: &str = "https://www.googleapis.com/oauth2/v3/certs";
const ISSUERS: [&str; 2] = ["https://accounts.google.com", "accounts.google.com"];

#[derive(Clone, Debug)]
struct Endpoints {
    authorize: String,
    token: String,
    jwks: String,
    issuers: Vec<String>,
}

impl Endpoints {
    fn google() -> Self {
        Self {
            authorize: AUTHORIZE.into(),
            token: TOKEN.into(),
            jwks: JWKS.into(),
            issuers: ISSUERS.iter().map(|issuer| (*issuer).to_owned()).collect(),
        }
    }

    fn fake(base: &str) -> Self {
        let base = base.trim_end_matches('/');
        Self {
            authorize: format!("{base}/authorize"),
            token: format!("{base}/token"),
            jwks: format!("{base}/jwks"),
            issuers: vec![base.to_owned()],
        }
    }
}

/// Where the installation reaches Google, and Google's signing keys.
pub struct Google {
    endpoints: Endpoints,
    http: reqwest::Client,
    keys: Mutex<Option<KeyCache>>,
}

/// One app's Google OAuth client, from its project secrets.
pub struct Client {
    id: String,
    secret: String,
}

struct KeyCache {
    keys: Vec<Jwk>,
    fetched_at: Instant,
    fresh_until: Instant,
}

#[derive(Clone, Deserialize)]
struct Jwk {
    kid: String,
    kty: String,
    #[serde(default)]
    alg: Option<String>,
    #[serde(default, rename = "use")]
    usage: Option<String>,
    n: String,
    e: String,
}

impl Google {
    /// Google itself.
    pub fn real() -> Self {
        Self::with(Endpoints::google())
    }

    /// Google, unless `KONAE_GOOGLE_TEST_ISSUER` points the endpoints at
    /// a local fake issuer. A release build refuses to start with it set, and
    /// a development build reads it only with a local HTTP public origin.
    pub fn from_env(public_origin: &str) -> Result<Self> {
        for retired in ["KONAE_GOOGLE_CLIENT_ID", "KONAE_GOOGLE_CLIENT_SECRET"] {
            if std::env::var(retired).is_ok_and(|value| !value.is_empty()) {
                eprintln!("{retired} is no longer read. Each app's owner sets the app's own Google client in Access > Users.");
            }
        }
        let Some(base) = std::env::var("KONAE_GOOGLE_TEST_ISSUER").ok().filter(|v| !v.is_empty()) else {
            return Ok(Self::real());
        };
        if !cfg!(debug_assertions) {
            bail!("KONAE_GOOGLE_TEST_ISSUER works only in a development build. Unset it.");
        }
        ensure!(
            local_http(public_origin) && local_http(&base),
            "KONAE_GOOGLE_TEST_ISSUER needs a local HTTP public origin and a local HTTP issuer."
        );
        Ok(Self::with(Endpoints::fake(&base)))
    }

    fn with(endpoints: Endpoints) -> Self {
        let http = reqwest::Client::builder()
            .redirect(reqwest::redirect::Policy::none())
            .timeout(Duration::from_secs(10))
            .build()
            .expect("an HTTP client");
        Self { endpoints, http, keys: Mutex::new(None) }
    }

    #[cfg(any(test, feature = "testing"))]
    pub fn for_test(base: &str) -> Self {
        Self::with(Endpoints::fake(base))
    }

    async fn verify(&self, token: &str, client_id: &str, nonce: &str, now: i64) -> std::result::Result<VerifiedIdentity, &'static str> {
        let parts: Vec<&str> = token.split('.').collect();
        if token.len() > 16384 || parts.len() != 3 {
            return Err(CHECKS);
        }
        #[derive(Deserialize)]
        struct Header {
            alg: String,
            kid: String,
            #[serde(default)]
            crit: Vec<String>,
        }
        let header: Header = super::base64url(parts[0])
            .ok()
            .and_then(|bytes| serde_json::from_slice(&bytes).ok())
            .ok_or(CHECKS)?;
        if header.alg != "RS256" || !header.crit.is_empty() {
            return Err(CHECKS);
        }
        let key = self.key(&header.kid).await.ok_or(CHECKS)?;
        let (n, e, signature) = match (super::base64url(&key.n), super::base64url(&key.e), super::base64url(parts[2])) {
            (Ok(n), Ok(e), Ok(signature)) => (n, e, signature),
            _ => return Err(CHECKS),
        };
        RsaPublicKeyComponents { n, e }
            .verify(&RSA_PKCS1_2048_8192_SHA256, format!("{}.{}", parts[0], parts[1]).as_bytes(), &signature)
            .map_err(|_| CHECKS)?;
        let claims: Value = super::base64url(parts[1])
            .ok()
            .and_then(|bytes| serde_json::from_slice(&bytes).ok())
            .ok_or(CHECKS)?;
        let issuer = claims["iss"].as_str().unwrap_or("");
        let audience_ok = match &claims["aud"] {
            Value::String(aud) => aud == client_id,
            Value::Array(list) => {
                list.iter().any(|aud| aud.as_str() == Some(client_id)) && claims["azp"].as_str() == Some(client_id)
            }
            _ => false,
        };
        let exp = claims["exp"].as_i64().unwrap_or(0);
        let iat = claims["iat"].as_i64().unwrap_or(i64::MAX);
        if !self.endpoints.issuers.iter().any(|allowed| allowed == issuer)
            || !audience_ok
            || exp <= now
            || iat > now + 300
            || claims["nonce"].as_str() != Some(nonce)
        {
            return Err(CHECKS);
        }
        // Google documents a boolean; its samples show the string "true".
        let verified = claims["email_verified"] == Value::Bool(true) || claims["email_verified"] == "true";
        let email = claims["email"].as_str().unwrap_or("");
        if !verified || auth::normalize_email(email).is_err() {
            return Err(UNVERIFIED);
        }
        if !google_vouches_for(email, claims["hd"].as_str()) {
            return Err(NOT_AUTHORITATIVE);
        }
        Ok(VerifiedIdentity { email: email.to_owned() })
    }

    /// The key a token names: from the cache while it is fresh, else from
    /// one fetch of the JWKS URL. An unknown key on a fresh cache fetches
    /// again only when the last fetch is older than `REFETCH_COOLDOWN`.
    async fn key(&self, kid: &str) -> Option<Jwk> {
        {
            let cache = self.keys.lock().unwrap();
            if let Some(cache) = cache.as_ref().filter(|cache| cache.fresh_until > Instant::now()) {
                if let Some(key) = cache.keys.iter().find(|key| key.kid == kid) {
                    return Some(key.clone());
                }
                if cache.fetched_at.elapsed() < REFETCH_COOLDOWN {
                    return None;
                }
            }
        }
        let fetched = self.fetch_keys().await.ok()?;
        let key = fetched.keys.iter().find(|key| key.kid == kid).cloned();
        *self.keys.lock().unwrap() = Some(fetched);
        key
    }

    async fn fetch_keys(&self) -> Result<KeyCache> {
        let response = self.http.get(&self.endpoints.jwks).send().await?;
        ensure!(response.status().is_success(), "Google keys answered {}.", response.status());
        let max_age = response
            .headers()
            .get(header::CACHE_CONTROL)
            .and_then(|value| value.to_str().ok())
            .and_then(|value| {
                value.split(',').find_map(|part| part.trim().strip_prefix("max-age=")?.parse::<u64>().ok())
            })
            .unwrap_or(3600)
            .clamp(60, 24 * 3600);
        let bytes = read_capped(response, MAX_JWKS_BYTES).await?;
        #[derive(Deserialize)]
        struct Jwks {
            keys: Vec<Jwk>,
        }
        let keys: Vec<Jwk> = serde_json::from_slice::<Jwks>(&bytes)?
            .keys
            .into_iter()
            .filter(|key| {
                key.kty == "RSA"
                    && key.alg.as_deref().is_none_or(|alg| alg == "RS256")
                    && key.usage.as_deref().is_none_or(|usage| usage == "sig")
            })
            .take(16)
            .collect();
        let fetched_at = Instant::now();
        Ok(KeyCache { keys, fetched_at, fresh_until: fetched_at + Duration::from_secs(max_age) })
    }

    /// Exchanges an authorization code for its ID token with the app's client.
    async fn exchange(&self, client: &Client, code: &str, verifier: &str, redirect_uri: &str) -> Result<String> {
        let response = self
            .http
            .post(&self.endpoints.token)
            .form(&[
                ("grant_type", "authorization_code"),
                ("code", code),
                ("client_id", client.id.as_str()),
                ("client_secret", client.secret.as_str()),
                ("redirect_uri", redirect_uri),
                ("code_verifier", verifier),
            ])
            .send()
            .await?;
        ensure!(response.status().is_success(), "Google's token endpoint answered {}.", response.status());
        let body: Value = serde_json::from_slice(&read_capped(response, MAX_TOKEN_RESPONSE_BYTES).await?)?;
        body["id_token"].as_str().map(str::to_owned).context("Google answered without an ID token.")
    }
}

fn google_vouches_for(email: &str, hosted_domain: Option<&str>) -> bool {
    let Some((_, domain)) = email.rsplit_once('@') else { return false };
    domain.eq_ignore_ascii_case("gmail.com") || hosted_domain.is_some_and(|hd| hd.eq_ignore_ascii_case(domain))
}

async fn read_capped(mut response: reqwest::Response, cap: usize) -> Result<Vec<u8>> {
    let mut bytes = Vec::new();
    while let Some(chunk) = response.chunk().await? {
        bytes.extend_from_slice(&chunk);
        ensure!(bytes.len() <= cap, "The answer exceeds {cap} bytes.");
    }
    Ok(bytes)
}

fn local_http(origin: &str) -> bool {
    url::Url::parse(origin).is_ok_and(|url| {
        url.scheme() == "http"
            && url.host_str().is_some_and(|host| host == "localhost" || host == "127.0.0.1" || host == "[::1]" || host.ends_with(".localhost"))
    })
}

#[derive(Default)]
pub struct StoredClient {
    pub id: Option<String>,
    pub secret: Option<String>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ClientSet {
    pub id: bool,
    pub secret: bool,
}

impl ClientSet {
    pub fn complete(self) -> bool {
        self.id && self.secret
    }
}

fn client(state: &AppState, deployment: &Deployment) -> Option<Client> {
    match stored_client(state, deployment) {
        StoredClient { id: Some(id), secret: Some(secret) } => Some(Client { id, secret }),
        _ => None,
    }
}

fn stored_client(state: &AppState, deployment: &Deployment) -> StoredClient {
    http::read_secrets(&state.data_root, &deployment.id)
        .and_then(|db| http::google_client(&db))
        .unwrap_or_default()
}

/// Whether the app's client ID and client secret are each set.
pub fn client_set(state: &AppState, deployment: &Deployment) -> ClientSet {
    let stored = stored_client(state, deployment);
    ClientSet { id: stored.id.is_some(), secret: stored.secret.is_some() }
}

/// Whether this Deployment's sign-in page offers Google: the owner turned it
/// on and set the app's client on this installation.
pub fn offered(state: &AppState, deployment: &Deployment) -> bool {
    !state.execution_mode.is_test() && deployment.sign_in_methods.contains(&SignInMethod::Google) && client(state, deployment).is_some()
}

/// Whether the sign-in page this request opens offers Google: `offered`, and
/// not on the home address, where `start` refuses.
pub fn offered_here(state: &AppState, deployment: &Deployment, headers: &HeaderMap) -> bool {
    offered(state, deployment) && !(path::on_path_host(state, headers) && path::prefix(headers).is_none())
}

/// The redirect URIs the owner registers in the Google console: the
/// generated host's callback and, once verified, the custom domain's. The
/// start step sends one of these and no other.
pub fn redirect_uris(state: &AppState, deployment: &Deployment) -> Vec<String> {
    let mut hosts = vec![deployment.hostname.clone()];
    if let Some(record) = domain::read_record(state, &deployment.id).filter(|record| record.verified) {
        hosts.push(record.hostname);
    }
    let mut uris: Vec<String> = hosts.into_iter().map(|host| format!("{}{CALLBACK_PATH}", deployment_url(&state.public_origin, &host))).collect();
    if let Some(uri) = path_callback(state, deployment) {
        uris.push(uri);
    }
    uris
}

fn path_callback(state: &AppState, deployment: &Deployment) -> Option<String> {
    let origin = state.path_origin.as_deref()?.trim_end_matches('/');
    path::read_record(state, &deployment.id)
        .filter(|record| record.enabled)
        .map(|_| format!("{origin}/p/{}{CALLBACK_PATH}", deployment.id))
}

fn callback_uri(state: &AppState, deployment: &Deployment, headers: &HeaderMap, origin: &str) -> std::result::Result<String, &'static str> {
    if path::on_path_host(state, headers) {
        return match path::prefix(headers) {
            Some(_) => path_callback(state, deployment).ok_or(FAILED),
            None => Err(NOT_ON_HOME),
        };
    }
    Ok(format!("{origin}{CALLBACK_PATH}"))
}

// ---------------------------------------------------------------------------
// Flow store

const GOOGLE_DATABASE: &str = "google.sqlite";

fn open(state: &AppState) -> Result<Connection> {
    let db = Connection::open(state.data_root.join(GOOGLE_DATABASE))?;
    db.busy_timeout(Duration::from_secs(5))?;
    db.execute_batch(
        "PRAGMA journal_mode = WAL;
         CREATE TABLE IF NOT EXISTS google_flows (
           state_hash TEXT PRIMARY KEY,
           browser_hash TEXT NOT NULL,
           deployment_id TEXT NOT NULL,
           app_origin TEXT NOT NULL,
           nonce TEXT NOT NULL,
           verifier TEXT NOT NULL,
           intent TEXT NOT NULL,
           intent_value TEXT NOT NULL DEFAULT '',
           expires_at INTEGER NOT NULL
         );",
    )?;
    Ok(db)
}

fn random_hex() -> String {
    let mut bytes = [0_u8; 32];
    SystemRandom::new().fill(&mut bytes).expect("system randomness");
    hex::encode(bytes)
}

fn digest(value: &str) -> String {
    hex::encode(Sha256::digest(value.as_bytes()))
}

fn base64url(bytes: &[u8]) -> String {
    encode_base64(bytes).trim_end_matches('=').replace('+', "-").replace('/', "_")
}

/// The origin the browser used for this app host.
fn app_origin(state: &AppState, headers: &HeaderMap) -> Option<String> {
    let host = headers.get(header::HOST)?.to_str().ok()?;
    let scheme = if state.public_origin.starts_with("https://") { "https" } else { "http" };
    let parsed = url::Url::parse(&format!("{scheme}://{host}")).ok()?;
    (parsed.path() == "/" && parsed.username().is_empty() && parsed.query().is_none())
        .then(|| parsed.origin().ascii_serialization())
}

/// The flow cookie's name. On the path host every app shares the origin, so
fn cookie_name(state: &AppState, deployment: &Deployment, headers: &HeaderMap) -> String {
    let base = if state.public_origin.starts_with("https://") { "__Host-konae_google" } else { "konae_google" };
    if path::on_path_host(state, headers) { format!("{base}_{}", deployment.id) } else { base.to_owned() }
}

fn browser_cookie(state: &AppState, deployment: &Deployment, headers: &HeaderMap, value: &str, max_age: i64) -> HeaderValue {
    let name = cookie_name(state, deployment, headers);
    let secure = if name.starts_with("__Host-") { "; Secure" } else { "" };
    HeaderValue::from_str(&format!("{name}={value}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}{secure}")).unwrap()
}


pub fn routes() -> Router<AppState> {
    Router::new().route(START_PATH, get(start_get).post(start_post)).route(CALLBACK_PATH, get(callback))
}

async fn start_get(State(state): State<AppState>, request: Request) -> Response {
    if state.execution_mode.is_test() { return error(StatusCode::FORBIDDEN, "Google sign-in is unavailable in local test mode."); }
    let headers = request.headers().clone();
    let peer = request.extensions().get::<axum::extract::ConnectInfo<std::net::SocketAddr>>().map(|info| info.0);
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Konae deployment not found.");
    };
    match begin(&state, &deployment, &headers, peer, IdentityIntent::SignIn).await {
        Ok((location, cookie)) => {
            let mut response = (StatusCode::SEE_OTHER, [(header::LOCATION, location)]).into_response();
            response.headers_mut().insert(header::SET_COOKIE, cookie);
            response.headers_mut().insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
            response
        }
        Err((status, message)) => login_link_page(status, &message),
    }
}

#[derive(Deserialize)]
struct InvitationStart {
    invitation: String,
}

async fn start_post(State(state): State<AppState>, request: Request) -> Response {
    if state.execution_mode.is_test() { return error(StatusCode::FORBIDDEN, "Google sign-in is unavailable in local test mode."); }
    let headers = request.headers().clone();
    if !same_origin(&headers) {
        return error(StatusCode::FORBIDDEN, "Cross-origin auth request rejected.");
    }
    let peer = request.extensions().get::<axum::extract::ConnectInfo<std::net::SocketAddr>>().map(|info| info.0);
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Deployment not found.");
    };
    let Ok(bytes) = axum::body::to_bytes(request.into_body(), 4096).await else {
        return error(StatusCode::BAD_REQUEST, "Authentication request is too large.");
    };
    let Ok(input) = serde_json::from_slice::<InvitationStart>(&bytes) else {
        return error(StatusCode::BAD_REQUEST, "Send the invitation token.");
    };
    let intent = IdentityIntent::Invitation { token_hash: auth::hash_token(&input.invitation) };
    match begin(&state, &deployment, &headers, peer, intent).await {
        Ok((location, cookie)) => {
            let mut response = Json(json!({"result": {"location": location}})).into_response();
            response.headers_mut().insert(header::SET_COOKIE, cookie);
            response.headers_mut().insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
            response
        }
        Err((status, message)) => error(status, &message),
    }
}

async fn begin(
    state: &AppState,
    deployment: &Deployment,
    headers: &HeaderMap,
    peer: Option<std::net::SocketAddr>,
    intent: IdentityIntent,
) -> std::result::Result<(String, HeaderValue), (StatusCode, String)> {
    let client = match client(state, deployment) {
        Some(client) if deployment.sign_in_methods.contains(&SignInMethod::Google) => client,
        _ => return Err((StatusCode::NOT_FOUND, NOT_ON.into())),
    };
    let ip = state.guards.client_ip(peer, headers);
    if let Err(wait) = state.guards.auth_attempt(&deployment.id, ip, "google") {
        return Err((StatusCode::TOO_MANY_REQUESTS, format!("Too many sign-in attempts. Try again in {} seconds.", wait.as_secs().max(1))));
    }
    let origin = app_origin(state, headers).ok_or((StatusCode::BAD_REQUEST, FAILED.to_owned()))?;
    let redirect_uri = callback_uri(state, deployment, headers, &origin).map_err(|message| (StatusCode::BAD_REQUEST, message.to_owned()))?;
    if !redirect_uris(state, deployment).contains(&redirect_uri) {
        return Err((StatusCode::BAD_REQUEST, FAILED.into()));
    }
    let (flow_state, browser, nonce, verifier) = (random_hex(), random_hex(), random_hex(), random_hex());
    let (intent_name, intent_value) = match &intent {
        IdentityIntent::SignIn => ("signin", String::new()),
        IdentityIntent::Invitation { token_hash } => ("invitation", token_hash.clone()),
    };
    let now = auth::now_seconds();
    let stored = (|| -> Result<()> {
        let db = open(state)?;
        db.execute("DELETE FROM google_flows WHERE expires_at <= ?1", [now])?;
        db.execute(
            "INSERT INTO google_flows (state_hash, browser_hash, deployment_id, app_origin, nonce, verifier, intent, intent_value, expires_at)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
            params![digest(&flow_state), digest(&browser), deployment.id, origin, nonce, verifier, intent_name, intent_value, now + FLOW_TTL_SECONDS],
        )?;
        Ok(())
    })();
    if let Err(error_value) = stored {
        eprintln!("Google sign-in could not record a flow: {error_value}");
        return Err((StatusCode::INTERNAL_SERVER_ERROR, FAILED.into()));
    }
    let challenge = base64url(&Sha256::digest(verifier.as_bytes()));
    let mut location = url::Url::parse(&state.accounts.google.endpoints.authorize).map_err(|_| (StatusCode::INTERNAL_SERVER_ERROR, FAILED.to_owned()))?;
    location
        .query_pairs_mut()
        .append_pair("client_id", &client.id)
        .append_pair("redirect_uri", &redirect_uri)
        .append_pair("response_type", "code")
        .append_pair("scope", "openid email")
        .append_pair("state", &flow_state)
        .append_pair("nonce", &nonce)
        .append_pair("code_challenge", &challenge)
        .append_pair("code_challenge_method", "S256")
        .append_pair("prompt", "select_account");
    Ok((location.into(), browser_cookie(state, deployment, headers, &browser, FLOW_TTL_SECONDS)))
}

#[derive(Deserialize)]
struct CallbackQuery {
    #[serde(default)]
    code: Option<String>,
    #[serde(default)]
    state: Option<String>,
    #[serde(default)]
    error: Option<String>,
}

struct Flow {
    nonce: String,
    verifier: String,
    intent: IdentityIntent,
}

fn take_flow(db: &Connection, flow_state: &str, deployment_id: &str, origin: &str, browser: Option<&str>, now: i64) -> std::result::Result<Flow, &'static str> {
    let row: Option<(String, String, String, String, String, String, String, i64)> = db
        .query_row(
            "SELECT browser_hash, deployment_id, app_origin, nonce, verifier, intent, intent_value, expires_at
             FROM google_flows WHERE state_hash = ?1",
            [digest(flow_state)],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?, row.get(4)?, row.get(5)?, row.get(6)?, row.get(7)?)),
        )
        .optional()
        .map_err(|_| FAILED)?;
    let Some((browser_hash, flow_deployment, flow_origin, nonce, verifier, intent, intent_value, expires_at)) = row else {
        return Err(STALE);
    };
    if expires_at <= now || flow_deployment != deployment_id || flow_origin != origin {
        return Err(STALE);
    }
    if browser.map(digest).as_deref() != Some(browser_hash.as_str()) {
        return Err(OTHER_BROWSER);
    }
    let taken = db.execute("DELETE FROM google_flows WHERE state_hash = ?1", [digest(flow_state)]).map_err(|_| FAILED)?;
    if taken != 1 {
        return Err(STALE);
    }
    let intent = match intent.as_str() {
        "invitation" => IdentityIntent::Invitation { token_hash: intent_value },
        _ => IdentityIntent::SignIn,
    };
    Ok(Flow { nonce, verifier, intent })
}

/// Google's redirect, on the app's own host. Arrives as a cross-site
/// navigation, so it does not ask for same-origin headers; the single-use
/// state and this browser's flow cookie are its proof.
async fn callback(State(state): State<AppState>, headers: HeaderMap, Query(query): Query<CallbackQuery>) -> Response {
    if state.execution_mode.is_test() { return error(StatusCode::FORBIDDEN, "Google sign-in is unavailable in local test mode."); }
    let Some(deployment) = deployment_for(&state, &headers).await else {
        return error(StatusCode::NOT_FOUND, "Konae deployment not found.");
    };
    let mut response = callback_in(&state, &deployment, &headers, query).await;
    response.headers_mut().append(header::SET_COOKIE, browser_cookie(&state, &deployment, &headers, "", 0));
    response.headers_mut().insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response.headers_mut().insert(header::REFERRER_POLICY, HeaderValue::from_static("no-referrer"));
    response
}

async fn callback_in(state: &AppState, deployment: &Deployment, headers: &HeaderMap, query: CallbackQuery) -> Response {
    let Some(origin) = app_origin(state, headers) else {
        return login_link_page(StatusCode::BAD_REQUEST, FAILED);
    };
    let Some(flow_state) = query.state.filter(|value| value.len() <= 128) else {
        return login_link_page(StatusCode::BAD_REQUEST, FAILED);
    };
    let now = auth::now_seconds();
    let browser = cookie_value(headers, &cookie_name(state, deployment, headers));
    let flow = open(state)
        .map_err(|_| FAILED)
        .and_then(|db| take_flow(&db, &flow_state, &deployment.id, &origin, browser.as_deref(), now));
    let flow = match flow {
        Ok(flow) => flow,
        Err(message) => return login_link_page(StatusCode::GONE, message),
    };
    if query.error.is_some() {
        return login_link_page(StatusCode::FORBIDDEN, "Google sign-in was cancelled.");
    }
    let Some(code) = query.code.filter(|code| !code.is_empty() && code.len() <= 2048) else {
        return login_link_page(StatusCode::BAD_REQUEST, FAILED);
    };
    let client = match client(state, deployment) {
        Some(client) if deployment.sign_in_methods.contains(&SignInMethod::Google) => client,
        _ => return login_link_page(StatusCode::NOT_FOUND, NOT_ON),
    };
    let google = state.accounts.google.clone();
    let Ok(redirect_uri) = callback_uri(state, deployment, headers, &origin) else {
        return login_link_page(StatusCode::BAD_REQUEST, FAILED);
    };
    let token = match google.exchange(&client, &code, &flow.verifier, &redirect_uri).await {
        Ok(token) => token,
        Err(error_value) => {
            eprintln!("Google sign-in exchange failed: {error_value}");
            return login_link_page(StatusCode::BAD_GATEWAY, FAILED);
        }
    };
    let identity = match google.verify(&token, &client.id, &flow.nonce, now).await {
        Ok(identity) => identity,
        Err(message) => return login_link_page(StatusCode::FORBIDDEN, message),
    };
    let email = identity.email.clone();
    match sign_in(state, deployment, flow.intent, identity).await {
        Ok(signed) => {
            let operation = if signed.outcome == IdentityOutcome::Created { usage::Operation::Signup } else { usage::Operation::Login };
            usage::count(&state.data_root, &deployment.id, operation);
            let mut response = (StatusCode::SEE_OTHER, [(header::LOCATION, "/")]).into_response();
            let session_cookie = crate::app_cookie_name(state, &deployment.id, headers);
            response.headers_mut().insert(header::SET_COOKIE, accounts::app_session_cookie(&session_cookie, &signed.session));
            response
        }
        Err(AuthError::AccountPending) => {
            let invited = accounts::invitation_pending(state, deployment, &email).await;
            login_link_page(StatusCode::FORBIDDEN, &accounts::pending_message(state, invited))
        }
        Err(error_value) => {
            let status = match &error_value {
                AuthError::Storage(_) | AuthError::PasswordHash => StatusCode::INTERNAL_SERVER_ERROR,
                AuthError::InvalidChallenge => StatusCode::GONE,
                AuthError::AccountExists => StatusCode::CONFLICT,
                _ => StatusCode::FORBIDDEN,
            };
            login_link_page(status, &error_value.to_string())
        }
    }
}

async fn sign_in(
    state: &AppState,
    deployment: &Deployment,
    intent: IdentityIntent,
    identity: VerifiedIdentity,
) -> std::result::Result<auth::IdentitySignIn, AuthError> {
    let _identity_guard = database_lock(state, &format!("identity:{}", deployment.id)).await;
    let auth = invitations::store(state, deployment)?;
    let deployments = state.deployments.clone();
    let (new_id, invited_id) = (deployment.id.clone(), deployment.id.clone());
    let deployments_too = deployments.clone();
    blocking(move || {
        auth.sign_in_with_identity(
            &identity,
            &intent,
            |email| {
                deployments
                    .blocking_read()
                    .values()
                    .find(|current| current.id == new_id)
                    .is_some_and(|current| current.signup_policy.allows(email))
            },
            |email| {
                deployments_too
                    .blocking_read()
                    .values()
                    .find(|current| current.id == invited_id)
                    .is_some_and(|current| invitations::admits_invitation(&current.signup_policy, email))
            },
            invitations::mark_accepted,
        )
    })
    .await
}


fn escape(value: &str) -> String {
    value.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

const PAGE_HEAD: &str = r#"<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>Sign in with Google</title><style>/*KERNEL_PAGE_CSS*/</style><link rel="icon" href="data:,"><main><h1>Sign in with Google</h1><p role="alert">"#;

fn html(status: StatusCode, body: String) -> Response {
    let mut response = (status, body).into_response();
    response.headers_mut().insert(header::CONTENT_TYPE, HeaderValue::from_static("text/html; charset=utf-8"));
    response.headers_mut().insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    response.headers_mut().insert("x-robots-tag", HeaderValue::from_static("noindex"));
    response
}

fn page_with_link(status: StatusCode, message: &str, link: &str) -> Response {
    html(status, crate::own_page::style(&format!("{PAGE_HEAD}{}</p><p><a href=\"{}\">Back to sign in</a></p></main></html>", escape(message), escape(link))))
}

fn login_link_page(status: StatusCode, message: &str) -> Response {
    page_with_link(status, message, "../../login")
}

/// The sign-in page's Google button, as a link: a navigation is not bound by
/// the page's form-action or connect-src. On a path address it keeps the
/// page's `/p/<segment>` prefix, as the Kernel's other pages do.
pub const BUTTON: &str = r##"<a class="google" href="/_konae/auth/google/start"><svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#ea4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.6 5.4 2.7 13.3l7.9 6.1C12.5 13.6 17.8 9.5 24 9.5z"/><path fill="#4285f4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.4-4.7 7l7.6 5.9c4.4-4.1 6.8-10.1 6.8-17.4z"/><path fill="#fbbc05" d="M10.5 28.6c-.5-1.4-.8-3-.8-4.6s.3-3.2.8-4.6l-7.9-6.1C1 16.6 0 20.2 0 24s1 7.4 2.7 10.7l7.8-6.1z"/><path fill="#34a853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.2 0-11.5-4.2-13.4-9.9l-7.9 6.1C6.6 42.6 14.6 48 24 48z"/></svg>Continue with Google</a><p class="or"><span>or</span></p><script>{const m=/^\/p\/([^\/]+)(\/|$)/.exec(location.pathname);if(m)document.querySelector('a.google').href='/p/'+m[1]+'/_konae/auth/google/start'}</script>"##;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn google_error_pages_are_not_indexed() {
        assert_eq!(login_link_page(StatusCode::BAD_REQUEST, "Sign-in failed.").headers()["x-robots-tag"], "noindex");
    }
    use std::sync::atomic::{AtomicUsize, Ordering};
    use accounts::AccountSettings;
    use ring::signature::{RSA_PKCS1_SHA256, RsaKeyPair};

    const KERNEL: &str = "http://localhost:8790";
    const APP: &str = "practice.localhost:8790";
    const OTHER: &str = "other.localhost:8790";
    const PATH_ORIGIN: &str = "http://localhost:8790";
    const PATH_HOST: &str = "localhost:8790";
    const APP_CLIENT: &str = "1001-practice.apps.googleusercontent.com";
    const OTHER_CLIENT: &str = "1002-other.apps.googleusercontent.com";
    const CLIENT_SECRET_VALUE: &str = "GOCSPX-test-secret-value";

    #[derive(Clone)]
    struct Grant {
        claims: Value,
        challenge: String,
        redirect_uri: String,
        kid: &'static str,
    }

    #[derive(Clone, Default)]
    struct Fake {
        grants: Arc<Mutex<HashMap<String, Grant>>>,
        key_fetches: Arc<AtomicUsize>,
    }

    fn encode(bytes: &[u8]) -> String {
        base64url(bytes)
    }

    fn signed(kid: &str, claims: &Value) -> String {
        let key = RsaKeyPair::from_pkcs8(include_bytes!("../../test-fixtures/clerk/test-key.pk8")).unwrap();
        let message = format!(
            "{}.{}",
            encode(json!({"alg": "RS256", "kid": kid}).to_string().as_bytes()),
            encode(claims.to_string().as_bytes())
        );
        let mut signature = vec![0; key.public().modulus_len()];
        key.sign(&RSA_PKCS1_SHA256, &SystemRandom::new(), message.as_bytes(), &mut signature).unwrap();
        format!("{message}.{}", encode(&signature))
    }

    /// A local stand-in for Google's token and JWKS endpoints. The token
    async fn fake_google() -> (Fake, String) {
        let fake = Fake::default();
        let jwks_fake = fake.clone();
        let token_fake = fake.clone();
        let router = Router::new()
            .route(
                "/jwks",
                get(move || {
                    let fake = jwks_fake.clone();
                    async move {
                        fake.key_fetches.fetch_add(1, Ordering::SeqCst);
                        ([(header::CACHE_CONTROL, "public, max-age=300")], include_str!("../../test-fixtures/clerk/jwks.json"))
                    }
                }),
            )
            .route(
                "/token",
                post(move |body: String| {
                    let fake = token_fake.clone();
                    async move {
                        let form: HashMap<String, String> = url::form_urlencoded::parse(body.as_bytes()).into_owned().collect();
                        let grant = fake.grants.lock().unwrap().remove(form.get("code").map(String::as_str).unwrap_or(""));
                        let Some(grant) = grant else {
                            return (StatusCode::BAD_REQUEST, Json(json!({"error": "invalid_grant"})));
                        };
                        let verifier = form.get("code_verifier").cloned().unwrap_or_default();
                        if form.get("client_secret").map(String::as_str) != Some(CLIENT_SECRET_VALUE)
                            || form.get("redirect_uri") != Some(&grant.redirect_uri)
                            || base64url(&Sha256::digest(verifier.as_bytes())) != grant.challenge
                        {
                            return (StatusCode::BAD_REQUEST, Json(json!({"error": "invalid_request"})));
                        }
                        (StatusCode::OK, Json(json!({"id_token": signed(grant.kid, &grant.claims)})))
                    }
                }),
            );
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let base = format!("http://127.0.0.1:{}", listener.local_addr().unwrap().port());
        tokio::spawn(async move { axum::serve(listener, router).await.unwrap() });
        (fake, base)
    }

    struct Fixture {
        state: AppState,
        fake: Fake,
        base: String,
        root: PathBuf,
    }

    impl Drop for Fixture {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.root);
        }
    }

    fn set_client(state: &AppState, project: &str, client_id: &str) {
        let db = http::secrets_store(&state.data_root, project).unwrap();
        http::secrets_call(&db, project, None, "secret_set", &json!({"name": CLIENT_ID, "value": client_id, "use": "google"})).unwrap();
        http::secrets_call(&db, project, None, "secret_set", &json!({"name": CLIENT_SECRET, "value": CLIENT_SECRET_VALUE})).unwrap();
    }

    async fn fixture(mode: SignupMode) -> Fixture {
        let (fake, base) = fake_google().await;
        let root = std::env::temp_dir().join(format!("konae-google-{}", Uuid::new_v4()));
        std::fs::create_dir_all(&root).unwrap();
        let mut deployments = HashMap::new();
        for host in [APP, OTHER] {
            let hostname = host.split(':').next().unwrap();
            let app_id = Uuid::new_v4().to_string();
            let item = Deployment {
                id: app_id.clone(),
                project_id: app_id,
                project_name: "Practice".into(),
                slug: "app".into(),
                url: format!("http://{host}"),
                created_at: now_ms(),
                released_at: 0,
                source_digest: None,
                manifest: json!({"visibility": "private"}),
                hostname: hostname.into(),
                actions: "{}".into(),
                artifact_version: "v1".into(),
                signup_policy: SignupPolicy::from_input(mode, &["@practice.example".into()]).unwrap(),
                sign_in_methods: vec![SignInMethod::Password, SignInMethod::Google],
                contact_email: None,
                modules: crate::modules::auth_enabled_defaults(),
                released_schema: String::new(), server: None,
            };
            std::fs::create_dir_all(crate::layout::data(&root, &item.id)).unwrap();
            deployments.insert(hostname.to_owned(), item);
        }
        let state = AppState {
            deployments: Arc::new(RwLock::new(deployments)),
            accounts: AccountSettings {
                verification: auth::Verification::Required,
                mail: None,
                queue: None,
                google: Arc::new(Google::for_test(&base)),
            },
            public_origin: KERNEL.into(),
            path_origin: Some(PATH_ORIGIN.into()),
            ..AppState::for_test(&root)
        };
        let fixture = Fixture { state, fake, base, root };
        set_client(&fixture.state, &fixture.deployment(APP).await.project_id, APP_CLIENT);
        set_client(&fixture.state, &fixture.deployment(OTHER).await.project_id, OTHER_CLIENT);
        fixture
    }

    fn headers(host: &str, cookie: Option<&str>) -> HeaderMap {
        let mut headers = HeaderMap::new();
        headers.insert(header::HOST, HeaderValue::from_str(host).unwrap());
        if let Some(cookie) = cookie {
            headers.insert(header::COOKIE, HeaderValue::from_str(cookie).unwrap());
        }
        headers
    }

    fn location(response: &Response) -> String {
        response.headers().get(header::LOCATION).expect("a redirect").to_str().unwrap().to_owned()
    }

    fn set_cookies(response: &Response) -> Vec<String> {
        response
            .headers()
            .get_all(header::SET_COOKIE)
            .iter()
            .map(|value| value.to_str().unwrap().split(';').next().unwrap().to_owned())
            .collect()
    }

    async fn text(response: Response) -> String {
        String::from_utf8(axum::body::to_bytes(response.into_body(), 1 << 20).await.unwrap().to_vec()).unwrap()
    }

    struct Person {
        subject: &'static str,
        email: &'static str,
        hd: Option<&'static str>,
    }

    /// A Gmail address: Google is its authority.
    const ANA: Person = Person { subject: "100000000000000000001", email: "ana@gmail.com", hd: None };
    /// A Workspace address: the `hd` claim names its domain.
    const BEA: Person = Person { subject: "100000000000000000002", email: "bea@practice.example", hd: Some("practice.example") };
    /// A Google account made with an outside address.
    const CARL: Person = Person { subject: "100000000000000000003", email: "carl@outside.example", hd: None };

    impl Fixture {
        async fn deployment(&self, host: &str) -> Deployment {
            self.state.deployments.read().await.get(host.split(':').next().unwrap()).cloned().unwrap()
        }

        fn identity(&self, deployment_id: &str) -> Connection {
            Connection::open(crate::layout::identity(&self.root, &deployment_id)).unwrap()
        }

        /// Starts a flow on `host` and returns the browser cookie and the
        /// authorization URL's query.
        async fn start(&self, host: &str) -> (String, HashMap<String, String>) {
            let request = Request::builder().uri(START_PATH).header(header::HOST, host).body(Body::empty()).unwrap();
            let response = start_get(State(self.state.clone()), request).await;
            assert_eq!(response.status(), StatusCode::SEE_OTHER, "{}", text(response).await);
            let url = url::Url::parse(&location(&response)).unwrap();
            assert!(url.as_str().starts_with(&format!("{}/authorize?", self.base)));
            let cookie = set_cookies(&response).into_iter().find(|c| c.starts_with("konae_google=")).unwrap();
            (cookie, url.query_pairs().into_owned().collect())
        }

        async fn google(&self, host: &str, cookie: &str, query: &HashMap<String, String>, person: &Person, kid: &'static str, edit: impl FnOnce(&mut Value)) -> Response {
            let now = auth::now_seconds();
            let mut claims = json!({
                "iss": self.base, "aud": query["client_id"], "azp": query["client_id"], "sub": person.subject,
                "email": person.email, "email_verified": true, "nonce": query["nonce"], "iat": now, "exp": now + 3600,
            });
            if let Some(hd) = person.hd {
                claims["hd"] = json!(hd);
            }
            edit(&mut claims);
            let code = format!("code-{}", Uuid::new_v4());
            let grant = Grant { claims, challenge: query["code_challenge"].clone(), redirect_uri: query["redirect_uri"].clone(), kid };
            self.fake.grants.lock().unwrap().insert(code.clone(), grant);
            let callback_query = CallbackQuery { code: Some(code), state: Some(query["state"].clone()), error: None };
            callback(State(self.state.clone()), headers(host, Some(cookie)), Query(callback_query)).await
        }

        /// One whole sign-in. Returns the callback's response.
        async fn sign_in(&self, host: &str, person: &Person) -> Response {
            let (cookie, query) = self.start(host).await;
            self.google(host, &cookie, &query, person, "local-test", |_| {}).await
        }

        async fn session_user(&self, host: &str, response: &Response) -> Value {
            let cookie = set_cookies(response).into_iter().find(|c| c.starts_with("konae_app_session=")).expect("a session cookie");
            let response = session(State(self.state.clone()), headers(host, Some(&cookie))).await;
            serde_json::from_str::<Value>(&text(response).await).unwrap()["result"].clone()
        }

        async fn password_account(&self, host: &str, email: &str) -> String {
            let deployment = self.deployment(host).await;
            let store = AuthService::open_in(
                crate::layout::identity(&self.root, &deployment.id),
                &auth::deployment_scope(&deployment.id),
                auth::Verification::Local,
            )
            .unwrap();
            let session = store.create_account(auth::NewAccount::prepare(email, "correct horse battery").unwrap()).unwrap();
            self.identity(&deployment.id).execute("UPDATE app_users SET verified_at = 1 WHERE email = ?1", [email]).unwrap();
            session.user.user_id
        }

        fn users(&self, deployment_id: &str) -> i64 {
            self.identity(deployment_id).query_row("SELECT COUNT(*) FROM app_users", [], |row| row.get(0)).unwrap_or(0)
        }
    }

    #[tokio::test]
    async fn a_person_signs_in_with_google_on_the_apps_own_host_and_gets_one_stable_account() {
        let fixture = fixture(SignupMode::Open).await;
        let (cookie, query) = fixture.start(APP).await;
        assert_eq!(query["client_id"], APP_CLIENT);
        assert_eq!(query["redirect_uri"], format!("http://{APP}{CALLBACK_PATH}"));
        let first = fixture.google(APP, &cookie, &query, &ANA, "local-test", |_| {}).await;
        assert_eq!(first.status(), StatusCode::SEE_OTHER, "{}", text(first).await);
        assert_eq!(location(&first), "/");
        assert!(set_cookies(&first).contains(&"konae_google=".to_owned()), "the callback clears the flow cookie");
        let user = fixture.session_user(APP, &first).await;
        assert_eq!(user["name"], ANA.email);
        assert_eq!(user["role"], "member");
        let again = fixture.sign_in(APP, &ANA).await;
        assert_eq!(fixture.session_user(APP, &again).await["userId"], user["userId"]);
        let app = fixture.deployment(APP).await;
        let (verified, hash): (Option<i64>, String) = fixture
            .identity(&app.id)
            .query_row("SELECT verified_at, password_hash FROM app_users", [], |row| Ok((row.get(0)?, row.get(1)?)))
            .unwrap();
        assert!(verified.is_some());
        assert!(hash.starts_with("pbkdf2-sha256$600000$") && hash != auth::NO_PASSWORD);
        assert_eq!(fixture.users(&fixture.deployment(OTHER).await.id), 0);
    }

    #[tokio::test]
    async fn the_redirect_uris_shown_to_the_owner_are_the_ones_sent_and_no_other_host_starts() {
        let fixture = fixture(SignupMode::Open).await;
        let app = fixture.deployment(APP).await;
        let shown = redirect_uris(&fixture.state, &app);
        assert_eq!(shown, vec![format!("http://{APP}{CALLBACK_PATH}")]);
        let (_, query) = fixture.start(APP).await;
        assert!(shown.contains(&query["redirect_uri"]));
        let record = domain::Record { hostname: "practice.example.com".into(), token: "t".into(), verified: true, verified_at: Some(1), created_at: 1 };
        std::fs::create_dir_all(crate::layout::private(&fixture.root, &app.id)).unwrap();
        std::fs::write(crate::layout::private(&fixture.root, &app.id).join(domain::RECORD_FILE), serde_json::to_vec(&record).unwrap()).unwrap();
        let shown = redirect_uris(&fixture.state, &app);
        assert_eq!(shown[1], format!("http://practice.example.com:8790{CALLBACK_PATH}"));
        let request = Request::builder().uri(START_PATH).header(header::HOST, "practice.localhost:9999").body(Body::empty()).unwrap();
        let refused = start_get(State(fixture.state.clone()), request).await;
        assert_eq!(refused.status(), StatusCode::BAD_REQUEST);
        assert!(text(refused).await.contains(&escape(FAILED)));
    }

    #[tokio::test]
    async fn a_path_address_signs_in_through_its_id_callback_and_the_home_offers_no_google() {
        use tower::ServiceExt;
        let fixture = fixture(SignupMode::Open).await;
        let app = fixture.deployment(APP).await;
        assert!(!redirect_uris(&fixture.state, &app).iter().any(|uri| uri.contains("/p/")));
        path::turn_on_for_test(&fixture.state, &app.id, Some("spring-practice")).await;
        let callback_uri = format!("{PATH_ORIGIN}/p/{}{CALLBACK_PATH}", app.id);
        assert_eq!(redirect_uris(&fixture.state, &app).last(), Some(&callback_uri));
        let router = |state: AppState| crate::stack(state, Router::new());
        let get = |uri: String, cookie: Option<String>| {
            let mut request = Request::builder().uri(uri).header(header::HOST, PATH_HOST);
            if let Some(cookie) = cookie {
                request = request.header(header::COOKIE, cookie);
            }
            request.body(Body::empty()).unwrap()
        };
        let started = router(fixture.state.clone()).oneshot(get("/p/spring-practice/_konae/auth/google/start".into(), None)).await.unwrap();
        assert_eq!(started.status(), StatusCode::SEE_OTHER);
        let query: HashMap<String, String> = url::Url::parse(&location(&started)).unwrap().query_pairs().into_owned().collect();
        assert_eq!(query["redirect_uri"], callback_uri);
        let flow_cookie = set_cookies(&started).into_iter().find(|c| c.starts_with(&format!("konae_google_{}=", app.id))).expect("a flow cookie named for the app");
        let now = auth::now_seconds();
        let claims = json!({"iss": fixture.base, "aud": APP_CLIENT, "azp": APP_CLIENT, "sub": ANA.subject, "email": ANA.email,
            "email_verified": true, "nonce": query["nonce"], "iat": now, "exp": now + 3600});
        fixture.fake.grants.lock().unwrap().insert("path-code".into(), Grant { claims, challenge: query["code_challenge"].clone(), redirect_uri: callback_uri.clone(), kid: "local-test" });
        let back = format!("/p/{}/_konae/auth/google/callback?code=path-code&state={}", app.id, query["state"]);
        let signed = router(fixture.state.clone()).oneshot(get(back, Some(flow_cookie))).await.unwrap();
        assert_eq!(signed.status(), StatusCode::SEE_OTHER, "{}", text(signed).await);
        assert_eq!(location(&signed), format!("/p/{}/", app.id), "the app opens under its prefix");
        assert!(set_cookies(&signed).iter().any(|c| c.starts_with(&format!("konae_app_session_{}=", app.id))), "the session is named for the app on the shared origin");
        assert_eq!(fixture.users(&app.id), 1);
        path::turn_on_for_test(&fixture.state, &app.id, Some(path::HOME_NAME)).await;
        let home = router(fixture.state.clone()).oneshot(get("/_konae/auth/google/start".into(), None)).await.unwrap();
        assert_eq!(home.status(), StatusCode::BAD_REQUEST);
        assert!(text(home).await.contains(&escape(NOT_ON_HOME)));
        let page = router(fixture.state.clone()).oneshot(get("/_konae/login".into(), None)).await.unwrap();
        assert!(!text(page).await.contains("Continue with Google"), "the home's sign-in page offers no Google");
        let page = router(fixture.state.clone()).oneshot(get(format!("/p/{}/_konae/login", app.id), None)).await.unwrap();
        assert!(text(page).await.contains("Continue with Google"), "the path address's sign-in page does");
    }

    #[tokio::test]
    async fn a_forged_expired_foreign_mismatched_or_unverified_token_is_refused() {
        let mut fixture = fixture(SignupMode::Open).await;
        let cases: Vec<(&str, &'static str, Box<dyn FnOnce(&mut Value)>)> = vec![
            ("unknown key", "someone-else", Box::new(|_| {})),
            ("expired", "local-test", Box::new(|c| c["exp"] = json!(auth::now_seconds() - 1))),
            ("another app's client", "local-test", Box::new(|c| { c["aud"] = json!(OTHER_CLIENT); c["azp"] = json!(OTHER_CLIENT); })),
            ("wrong issuer", "local-test", Box::new(|c| c["iss"] = json!("https://issuer.example"))),
            ("wrong nonce", "local-test", Box::new(|c| c["nonce"] = json!("not-the-nonce"))),
            ("unverified email", "local-test", Box::new(|c| c["email_verified"] = json!(false))),
        ];
        for (case, kid, edit) in cases {
            fixture.state.guards = Arc::new(limits::Guards::new(Vec::new()));
            let (cookie, query) = fixture.start(APP).await;
            let response = fixture.google(APP, &cookie, &query, &ANA, kid, edit).await;
            assert_eq!(response.status(), StatusCode::FORBIDDEN, "{case}");
            let body = text(response).await;
            let expected = if case == "unverified email" { UNVERIFIED } else { CHECKS };
            assert!(body.contains(&escape(expected)), "{case}: {body}");
        }
        let (_, query) = fixture.start(APP).await;
        let token = signed("local-test", &json!({"iss": fixture.base, "aud": APP_CLIENT, "sub": "1", "email": ANA.email, "email_verified": true, "nonce": query["nonce"], "iat": 0, "exp": i64::MAX}));
        let parts: Vec<&str> = token.split('.').collect();
        let forged = format!("{}.{}.{}", parts[0], encode(br#"{"iss":"x"}"#), parts[2]);
        let google = fixture.state.accounts.google.clone();
        assert_eq!(google.verify(&forged, APP_CLIENT, &query["nonce"], auth::now_seconds()).await, Err(CHECKS));
        assert!(google.verify(&token, APP_CLIENT, &query["nonce"], auth::now_seconds()).await.is_ok());
        assert_eq!(google.verify(&token, OTHER_CLIENT, &query["nonce"], auth::now_seconds()).await, Err(CHECKS));
        assert_eq!(fixture.fake.key_fetches.load(Ordering::SeqCst), 1);
        assert_eq!(fixture.users(&fixture.deployment(APP).await.id), 0);
    }

    #[tokio::test]
    async fn an_unknown_key_fetches_googles_keys_again_at_most_once_a_minute() {
        let fixture = fixture(SignupMode::Open).await;
        let google = fixture.state.accounts.google.clone();
        let fetches = || fixture.fake.key_fetches.load(Ordering::SeqCst);
        assert!(google.key("local-test").await.is_some());
        assert_eq!(fetches(), 1);
        for _ in 0..5 {
            assert!(google.key("rotated-in").await.is_none());
        }
        assert_eq!(fetches(), 1, "fresh flows naming an unknown key do not reach Google each time");
        assert!(google.key("local-test").await.is_some());
        let backdate = |google: &Google| {
            let mut cache = google.keys.lock().unwrap();
            let cache = cache.as_mut().unwrap();
            cache.fetched_at = Instant::now() - REFETCH_COOLDOWN - Duration::from_secs(1);
        };
        backdate(&google);
        assert!(google.key("rotated-in").await.is_none());
        assert!(google.key("rotated-in").await.is_none());
        assert_eq!(fetches(), 2);
        google.keys.lock().unwrap().as_mut().unwrap().fresh_until = Instant::now() - Duration::from_secs(1);
        assert!(google.key("local-test").await.is_some());
        assert_eq!(fetches(), 3);
    }

    #[tokio::test]
    async fn google_proves_only_an_address_it_manages() {
        let fixture = fixture(SignupMode::Open).await;
        let outside = fixture.sign_in(APP, &CARL).await;
        assert_eq!(outside.status(), StatusCode::FORBIDDEN);
        assert!(text(outside).await.contains(&escape(NOT_AUTHORITATIVE)));
        let (cookie, query) = fixture.start(APP).await;
        let foreign = fixture.google(APP, &cookie, &query, &BEA, "local-test", |c| c["hd"] = json!("other.example")).await;
        assert!(text(foreign).await.contains(&escape(NOT_AUTHORITATIVE)));
        assert_eq!(fixture.users(&fixture.deployment(APP).await.id), 0);
        let workspace = fixture.sign_in(APP, &BEA).await;
        assert_eq!(workspace.status(), StatusCode::SEE_OTHER, "{}", text(workspace).await);
        assert_eq!(fixture.session_user(APP, &workspace).await["name"], BEA.email);
        assert!(google_vouches_for("Ana@GMAIL.com", None) && !google_vouches_for("ana@googlemail.example", None));
    }

    #[tokio::test]
    async fn the_string_true_counts_as_a_verified_email() {
        let fixture = fixture(SignupMode::Open).await;
        let (cookie, query) = fixture.start(APP).await;
        let callback = fixture.google(APP, &cookie, &query, &ANA, "local-test", |c| c["email_verified"] = json!("true")).await;
        assert_eq!(callback.status(), StatusCode::SEE_OTHER);
    }

    #[tokio::test]
    async fn a_flow_works_once_only_on_its_deployment_origin_and_browser_and_only_until_it_expires() {
        let fixture = fixture(SignupMode::Open).await;
        let (cookie, query) = fixture.start(APP).await;
        let other = fixture.google(OTHER, &cookie, &query, &ANA, "local-test", |_| {}).await;
        assert_eq!(other.status(), StatusCode::GONE);
        assert!(text(other).await.contains(&escape(STALE)));
        let port = fixture.google("practice.localhost:9999", &cookie, &query, &ANA, "local-test", |_| {}).await;
        assert_eq!(port.status(), StatusCode::GONE);
        let stranger = fixture.google(APP, "konae_google=someone-else", &query, &ANA, "local-test", |_| {}).await;
        assert!(text(stranger).await.contains(&escape(OTHER_BROWSER)));
        assert_eq!(fixture.google(APP, &cookie, &query, &ANA, "local-test", |_| {}).await.status(), StatusCode::SEE_OTHER);
        let replay = fixture.google(APP, &cookie, &query, &ANA, "local-test", |_| {}).await;
        assert_eq!(replay.status(), StatusCode::GONE);
        let (cookie, query) = fixture.start(APP).await;
        open(&fixture.state).unwrap().execute("UPDATE google_flows SET expires_at = ?1", [auth::now_seconds() - 1]).unwrap();
        assert_eq!(fixture.google(APP, &cookie, &query, &ANA, "local-test", |_| {}).await.status(), StatusCode::GONE);
    }

    #[tokio::test]
    async fn each_signup_policy_admits_and_refuses_with_the_password_paths_words() {
        let open = fixture(SignupMode::Open).await;
        assert_eq!(open.sign_in(APP, &ANA).await.status(), StatusCode::SEE_OTHER);
        let list = fixture(SignupMode::Allowlist).await;
        assert_eq!(list.sign_in(APP, &BEA).await.status(), StatusCode::SEE_OTHER);
        for mode in [SignupMode::Allowlist, SignupMode::Closed, SignupMode::Invitation] {
            let fixture = fixture(mode).await;
            let refused = fixture.sign_in(APP, &ANA).await;
            assert_eq!(refused.status(), StatusCode::FORBIDDEN, "{mode:?}");
            assert!(text(refused).await.contains(SIGNUP_REFUSED), "{mode:?}");
        }
        let closed = fixture(SignupMode::Open).await;
        assert_eq!(closed.sign_in(APP, &ANA).await.status(), StatusCode::SEE_OTHER);
        for item in closed.state.deployments.write().await.values_mut() {
            item.signup_policy = SignupPolicy::from_input(SignupMode::Closed, &[]).unwrap();
        }
        assert_eq!(closed.sign_in(APP, &ANA).await.status(), StatusCode::SEE_OTHER);
    }

    #[tokio::test]
    async fn a_password_account_is_signed_in_by_google_with_the_same_email() {
        let fixture = fixture(SignupMode::Closed).await;
        let user_id = fixture.password_account(APP, "Ana@Gmail.com").await;
        let signed = fixture.sign_in(APP, &ANA).await;
        assert_eq!(signed.status(), StatusCode::SEE_OTHER, "{}", text(signed).await);
        assert_eq!(fixture.session_user(APP, &signed).await["userId"], user_id);
        assert_eq!(fixture.users(&fixture.deployment(APP).await.id), 1);
    }

    #[tokio::test]
    async fn a_package_moved_to_another_client_still_signs_the_same_person_in() {
        let fixture = fixture(SignupMode::Open).await;
        let first = fixture.sign_in(APP, &ANA).await;
        let user = fixture.session_user(APP, &first).await;
        let (app, other) = (fixture.deployment(APP).await, fixture.deployment(OTHER).await);
        let moved = crate::layout::identity(&fixture.root, &other.id);
        fixture.identity(&app.id).execute("VACUUM INTO ?1", [moved.to_string_lossy().as_ref()]).unwrap();
        for item in fixture.state.deployments.write().await.values_mut() {
            item.signup_policy = SignupPolicy::from_input(SignupMode::Closed, &[]).unwrap();
        }
        let (cookie, query) = fixture.start(OTHER).await;
        assert_eq!(query["client_id"], OTHER_CLIENT);
        let there = fixture.google(OTHER, &cookie, &query, &ANA, "local-test", |c| c["sub"] = json!("a-different-subject")).await;
        assert_eq!(there.status(), StatusCode::SEE_OTHER, "{}", text(there).await);
        assert_eq!(fixture.session_user(OTHER, &there).await["userId"], user["userId"]);
    }

    async fn invite(fixture: &Fixture, email: &str) -> String {
        let deployment = fixture.deployment(APP).await;
        let store = invitations::store(&fixture.state, &deployment).unwrap();
        let user_id = Uuid::new_v4().to_string();
        store
            .transaction(|tx| {
                tx.execute(
                    "INSERT INTO app_users (id, email, password_hash, created_at, state) VALUES (?1, ?2, ?3, 0, 'pending')",
                    params![user_id, email, auth::NO_PASSWORD],
                )?;
                let issued = store.issue_challenge(tx, &user_id, email, auth::Purpose::Invitation)?;
                tx.execute(
                    "INSERT INTO app_invitations (id, email, deployment, inviter, user_id, created_user, state, token_hash, created_at, expires_at)
                     VALUES (?1, ?2, ?3, 'owner', ?4, 1, 'pending', ?5, 0, ?6)",
                    params![Uuid::new_v4().to_string(), email, deployment.id, user_id, auth::hash_token(&issued.token), issued.expires_at],
                )?;
                Ok(issued.token)
            })
            .unwrap()
    }

    async fn accept_with_google(fixture: &Fixture, token: &str, person: &Person) -> Response {
        let request = Request::builder()
            .method("POST")
            .uri(START_PATH)
            .header(header::HOST, APP)
            .body(Body::from(json!({"invitation": token}).to_string()))
            .unwrap();
        let started = start_post(State(fixture.state.clone()), request).await;
        assert_eq!(started.status(), StatusCode::OK);
        let cookie = set_cookies(&started).into_iter().next().unwrap();
        let body: Value = serde_json::from_str(&text(started).await).unwrap();
        let url = url::Url::parse(body["result"]["location"].as_str().unwrap()).unwrap();
        let query: HashMap<String, String> = url.query_pairs().into_owned().collect();
        fixture.google(APP, &cookie, &query, person, "local-test", |_| {}).await
    }

    #[tokio::test]
    async fn an_invitation_accepted_with_google_needs_the_invited_email_and_activates_the_account() {
        let fixture = fixture(SignupMode::Invitation).await;
        let token = invite(&fixture, BEA.email).await;
        let wrong = accept_with_google(&fixture, &token, &ANA).await;
        assert_eq!(wrong.status(), StatusCode::FORBIDDEN);
        assert!(text(wrong).await.contains("This invitation is for another email."));
        let pending = fixture.sign_in(APP, &BEA).await;
        assert_eq!(pending.status(), StatusCode::FORBIDDEN);
        let accepted = accept_with_google(&fixture, &token, &BEA).await;
        assert_eq!(accepted.status(), StatusCode::SEE_OTHER, "{}", text(accepted).await);
        let app = fixture.deployment(APP).await;
        let (state, invitation): (String, String) = fixture
            .identity(&app.id)
            .query_row(
                "SELECT u.state, i.state FROM app_users u JOIN app_invitations i ON i.user_id = u.id WHERE u.email = ?1",
                [BEA.email],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .unwrap();
        assert_eq!((state.as_str(), invitation.as_str()), ("active", "accepted"));
        assert_eq!(accept_with_google(&fixture, &token, &BEA).await.status(), StatusCode::GONE);
        assert_eq!(fixture.sign_in(APP, &BEA).await.status(), StatusCode::SEE_OTHER);
    }

    #[tokio::test]
    async fn an_app_without_google_turned_on_or_without_its_client_offers_none() {
        let fixture = fixture(SignupMode::Open).await;
        let start = |state: AppState| async move {
            let request = Request::builder().uri(START_PATH).header(header::HOST, APP).body(Body::empty()).unwrap();
            start_get(State(state), request).await
        };
        for item in fixture.state.deployments.write().await.values_mut() {
            item.sign_in_methods = vec![SignInMethod::Password];
        }
        let response = start(fixture.state.clone()).await;
        assert_eq!(response.status(), StatusCode::NOT_FOUND);
        assert!(text(response).await.contains(&escape(NOT_ON)));
        for item in fixture.state.deployments.write().await.values_mut() {
            item.sign_in_methods = vec![SignInMethod::Password, SignInMethod::Google];
        }
        let app = fixture.deployment(APP).await;
        http::secrets_store(&fixture.state.data_root, &app.id).unwrap().execute("DELETE FROM secrets WHERE name = ?1", [CLIENT_SECRET]).unwrap();
        assert!(!offered(&fixture.state, &app));
        assert_eq!(client_set(&fixture.state, &app), ClientSet { id: true, secret: false });
        assert!(text(start(fixture.state.clone()).await).await.contains(&escape(NOT_ON)));
    }

    #[tokio::test]
    async fn test_mode_refuses_google_start_and_callback_without_contacting_google() {
        let mut fixture = fixture(SignupMode::Open).await;
        fixture.state.execution_mode = crate::execution::ExecutionMode::Test;
        let app = fixture.deployment(APP).await;
        assert!(!offered(&fixture.state, &app));
        let request = Request::builder().uri(START_PATH).header(header::HOST, APP).body(Body::empty()).unwrap();
        assert_eq!(start_get(State(fixture.state.clone()), request).await.status(), StatusCode::FORBIDDEN);
        let response = super::callback(State(fixture.state.clone()), headers(APP, None), Query(CallbackQuery {
            code: Some("code".into()), state: Some("state".into()), error: None,
        })).await;
        assert_eq!(response.status(), StatusCode::FORBIDDEN);
        assert_eq!(fixture.fake.key_fetches.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn the_test_issuer_needs_local_http() {
        assert!(local_http("http://localhost:8790") && local_http("http://127.0.0.1:9") && local_http("http://app.localhost"));
        assert!(!local_http("https://localhost") && !local_http("http://example.com") && !local_http("http://localhost.example.com"));
        assert_eq!(Google::real().endpoints.jwks, "https://www.googleapis.com/oauth2/v3/certs");
    }
}
