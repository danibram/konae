use super::*;
use crate::{
    functions::tests::{publish, release},
    functions_runtime::Runtime,
};
use konae_functions_executor::MemoryPolicy;
use rusqlite::Connection;
use tower::ServiceExt;

const HANDLER: &str = r#"
let calls=0;
export async function handle(request, context) {
  calls++;
  const path = new URL(request.url).pathname;
  if(path.endsWith('/spin')) { while(true) {} }
  if(path.endsWith('/catch')) { try { await context.actions.call('not.allowed', {}); } catch {} return Response.json({wrong:true}); }
  if(request.method === 'POST') {
    const input=await request.json();
    await context.actions.call('orders.update', {id:input.id, quantity:input.quantity});
    if(input.fail) throw Error('reject after write');
    await context.actions.call('audit.add',{quantity:input.quantity});
    if(input.disconnect) { while(true) {} }
    if(input.wait) {
      const until = Date.now()+200;
      while(Date.now()<until) {}
    }
  }
  const rows=await context.actions.call('orders.read',{});
  return Response.json({version:'A',calls,rows,cookie:request.headers.has('cookie'),authorization:request.headers.has('authorization')});
}
"#;

#[tokio::test]
async fn a_join_failure_reports_unknown_if_a_mutation_may_have_committed() {
    for (committed, expected) in [
        (false, StatusCode::INTERNAL_SERVER_ERROR),
        (true, StatusCode::CONFLICT),
    ] {
        let started = Instant::now();
        let budget = Budget::new(Duration::from_secs(1));
        let worker_budget = budget.clone();
        let join = tokio::task::spawn_blocking(move || {
            if committed {
                worker_budget.begin_commit().unwrap();
                worker_budget.committed();
            }
            panic!("fixture worker panic");
        })
        .await;
        assert!(join.unwrap_err().is_panic());
        let timed = interrupted(
            &budget,
            "function.executor-failed",
            started,
            &RunProgress::default(),
        );
        assert_eq!(timed.response.status(), expected);
        let body = axum::body::to_bytes(timed.response.into_body(), 1024)
            .await
            .unwrap();
        let value: Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(
            value["code"],
            if committed {
                "mutation_outcome_unknown"
            } else {
                "function.executor-failed"
            }
        );
    }
}

#[tokio::test]
async fn admission_includes_requests_waiting_for_publication_and_releases_on_drop() {
    let root = std::env::temp_dir().join(format!("konae-function-queue-{}", uuid::Uuid::new_v4()));
    std::fs::create_dir_all(&root).unwrap();
    let mut state = AppState::for_test(&root);
    state.functions = Arc::new(Runtime::configured(
        "/nonexistent/worker".into(),
        MemoryPolicy::DevelopmentPolling,
        Duration::from_secs(2),
        Duration::from_secs(1),
    ));
    let id = "function_queue";
    let deployed = publish(&state, &release(id, "export function handle() {}")).await;
    let lock = crate::named_lock(&state, &format!("publish:{id}"), true).await;
    let reservations = (0..63)
        .map(|_| {
            state
                .functions
                .admit(&Budget::new(Duration::from_secs(2)))
                .unwrap()
        })
        .collect::<Vec<_>>();
    let request = || {
        Request::builder()
            .uri("/api/orders")
            .header("host", &deployed.hostname)
            .body(Body::empty())
            .unwrap()
    };
    let service = crate::stack(state.clone(), axum::Router::new());
    let mut waiting = Box::pin(service.clone().oneshot(request()));
    assert!(
        tokio::time::timeout(Duration::from_millis(20), &mut waiting)
            .await
            .is_err()
    );
    let refused = tokio::time::timeout(Duration::from_millis(250), service.oneshot(request()))
        .await
        .unwrap()
        .unwrap();
    let body = axum::body::to_bytes(refused.into_body(), 1024)
        .await
        .unwrap();
    let value: Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(value["code"], "queue_full");
    drop(waiting);
    assert!(
        state
            .functions
            .admit(&Budget::new(Duration::from_secs(2)))
            .is_ok()
    );
    drop(reservations);
    let mut waiting = Box::pin(crate::stack(state.clone(), axum::Router::new()).oneshot(request()));
    assert!(
        tokio::time::timeout(Duration::from_millis(20), &mut waiting)
            .await
            .is_err()
    );
    crate::maintenance::pause_for_test(&root, id, true);
    drop(lock);
    let response = waiting.await.unwrap();
    assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    assert_eq!(response.headers()[header::RETRY_AFTER], "300");
    crate::usage::flush();
    std::fs::remove_dir_all(root).unwrap();
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
#[ignore = "requires KONAE_TEST_FUNCTION_WORKER pointing to the built external JavaScript worker"]
async fn real_functions_http_auth_transaction_publish_deadline_and_usage() {
    let executable =
        std::env::var_os("KONAE_TEST_FUNCTION_WORKER").expect("KONAE_TEST_FUNCTION_WORKER");
    let root = std::env::temp_dir().join(format!("konae-function-http-{}", uuid::Uuid::new_v4()));
    std::fs::create_dir_all(&root).unwrap();
    let mut state = AppState::for_test(&root);
    state.functions = Arc::new(Runtime::configured(
        executable.into(),
        MemoryPolicy::DevelopmentPolling,
        Duration::from_millis(1500),
        Duration::from_millis(500),
    ));
    let id = "http_functions";
    let mut payload = release(id, HANDLER);
    payload["initialModules"] =
        json!({"functions":{"on":true},"auth":{"on":true},"actions":{"on":true}});
    payload["initialSignupPolicy"] = json!({"mode":"open","allowlist":[]});
    payload["project"]["files"]["schema.sql"] = json!(
        "CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,owner_id TEXT NOT NULL,quantity INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,actor TEXT NOT NULL,quantity INTEGER NOT NULL);"
    );
    let actions = json!({"version":1,"actions":{
      "orders.read":{"kind":"query","access":"authenticated","statement":"SELECT id,quantity FROM orders WHERE owner_id=?1 LIMIT 10","bindings":[{"source":"actor","field":"id"}]},
      "orders.update":{"kind":"mutation","access":"authenticated","statement":"UPDATE orders SET quantity=?1 WHERE id=?2 AND owner_id=?3","guard":"Only the order owner can change it.","bindings":[{"source":"input","key":"quantity","type":"number"},{"source":"input","key":"id","type":"number"},{"source":"actor","field":"id"}]},
      "audit.add":{"kind":"mutation","access":"authenticated","statement":"INSERT INTO audit(actor,quantity) VALUES(?1,?2)","bindings":[{"source":"actor","field":"id"},{"source":"input","key":"quantity","type":"number"}]}
    }});
    payload["project"]["files"]["actions.json"] = json!(actions.to_string());
    payload["serverArtifact"]["manifest"]["functions"]["orders"]["access"] = json!("authenticated");
    payload["serverArtifact"]["manifest"]["functions"]["orders"]["actions"] =
        json!(["audit.add", "orders.read", "orders.update"]);
    payload["project"]["files"]["functions.json"] =
        json!(payload["serverArtifact"]["manifest"].to_string());
    let deployed = publish(&state, &payload).await;
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let serving = tokio::spawn(crate::serve(listener, state.clone(), axum::Router::new()));
    let client = reqwest::Client::new();
    let url = format!("http://{address}/api/orders");
    let mut accounts = Vec::new();
    for email in ["alice@example.test", "bob@example.test"] {
        let response = client
            .post(format!("http://{address}/_konae/auth/signup"))
            .header("host", &deployed.hostname)
            .json(&json!({"email":email,"password":"correct horse battery"}))
            .send()
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let cookie = response.headers()["set-cookie"]
            .to_str()
            .unwrap()
            .split(';')
            .next()
            .unwrap()
            .to_owned();
        let value: Value = response.json().await.unwrap();
        accounts.push((
            cookie,
            value["result"]["user"]["userId"]
                .as_str()
                .unwrap()
                .to_owned(),
        ));
    }
    let db = Connection::open(crate::layout::database(&root, id)).unwrap();
    db.execute(
        "INSERT INTO orders VALUES(1,?1,2),(2,?2,4)",
        rusqlite::params![accounts[0].1, accounts[1].1],
    )
    .unwrap();
    drop(db);
    assert_eq!(
        client
            .get(&url)
            .header("host", &deployed.hostname)
            .send()
            .await
            .unwrap()
            .status(),
        StatusCode::UNAUTHORIZED
    );
    let get = |suffix: &str, cookie: &str| {
        client
            .get(format!("{url}{suffix}"))
            .header("host", &deployed.hostname)
            .header("cookie", cookie)
    };
    let first = get("", &accounts[0].0).send().await.unwrap();
    let status = first.status();
    let first: Value = first.json().await.unwrap();
    assert_eq!(status, StatusCode::OK, "{first}");
    assert_eq!(first["version"], "A");
    assert_eq!(first["calls"], 1);
    assert_eq!(first["rows"][0]["id"], 1);
    assert_eq!(first["cookie"], false);
    assert_eq!(first["authorization"], false);
    let second: Value = get("", &accounts[1].0)
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(second["calls"], 2);
    assert_eq!(second["rows"][0]["id"], 2);
    let post = |key: &str, input: Value| {
        client
            .post(&url)
            .header("host", &deployed.hostname)
            .header("cookie", &accounts[0].0)
            .header("idempotency-key", key)
            .json(&input)
    };
    let changed = json!({"id":1,"quantity":7});
    let first = post("same", changed.clone()).send().await.unwrap();
    let status = first.status();
    let first: Value = first.json().await.unwrap();
    assert_eq!(status, StatusCode::OK, "{first}");
    let replay: Value = post("same", changed.clone())
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(replay, first);
    assert_eq!(
        post("same", json!({"id":1,"quantity":8}))
            .send()
            .await
            .unwrap()
            .status(),
        StatusCode::CONFLICT
    );
    assert_eq!(
        post("foreign", json!({"id":2,"quantity":8}))
            .send()
            .await
            .unwrap()
            .status(),
        StatusCode::FORBIDDEN
    );
    assert_eq!(
        post("rollback", json!({"id":1,"quantity":9,"fail":true}))
            .send()
            .await
            .unwrap()
            .status(),
        StatusCode::BAD_GATEWAY
    );
    let db = Connection::open(crate::layout::database(&root, id)).unwrap();
    assert_eq!(
        db.query_row("SELECT quantity FROM orders WHERE id=1", [], |r| r
            .get::<_, i64>(0))
            .unwrap(),
        7
    );
    assert_eq!(
        db.query_row("SELECT COUNT(*) FROM audit", [], |r| r.get::<_, i64>(0))
            .unwrap(),
        1
    );
    drop(db);
    let poisoned = get("/catch", &accounts[0].0).send().await.unwrap();
    assert_eq!(poisoned.status(), StatusCode::FORBIDDEN);
    let db = Connection::open(crate::layout::database(&root, id)).unwrap();
    db.execute_batch("BEGIN IMMEDIATE").unwrap();
    let blocked = post("native-deadline", json!({"id":1,"quantity":99}))
        .send()
        .await
        .unwrap();
    assert_eq!(blocked.status(), StatusCode::GATEWAY_TIMEOUT);
    db.execute_batch("ROLLBACK").unwrap();
    assert_eq!(
        db.query_row("SELECT quantity FROM orders WHERE id=1", [], |r| r
            .get::<_, i64>(0))
            .unwrap(),
        7
    );
    assert_eq!(
        db.query_row("SELECT COUNT(*) FROM audit", [], |r| r.get::<_, i64>(0))
            .unwrap(),
        1
    );
    assert_eq!(
        db.query_row("SELECT COUNT(*) FROM __konae_function_receipts", [], |r| {
            r.get::<_, i64>(0)
        })
        .unwrap(),
        1
    );
    drop(db);
    let request = Request::builder()
        .method("POST")
        .uri("/api/orders")
        .header("host", &deployed.hostname)
        .header("cookie", &accounts[0].0)
        .header("idempotency-key", "disconnect")
        .header("content-type", "application/json")
        .body(Body::from(
            json!({"id":1,"quantity":99,"disconnect":true}).to_string(),
        ))
        .unwrap();
    let db = Connection::open(crate::layout::database(&root, id)).unwrap();
    db.busy_timeout(Duration::ZERO).unwrap();
    let disconnect =
        tokio::spawn(crate::stack(state.clone(), axum::Router::new()).oneshot(request));
    tokio::time::timeout(Duration::from_secs(1), async {
        loop {
            match db.execute_batch("BEGIN IMMEDIATE; ROLLBACK;") {
                Err(rusqlite::Error::SqliteFailure(error, _))
                    if error.code == rusqlite::ErrorCode::DatabaseBusy =>
                {
                    break;
                }
                result => result.unwrap(),
            }
            tokio::time::sleep(Duration::from_millis(5)).await;
        }
    })
    .await
    .unwrap();
    disconnect.abort();
    assert!(disconnect.await.unwrap_err().is_cancelled());
    let guard = tokio::time::timeout(
        Duration::from_millis(700),
        crate::named_lock(&state, &format!("write:{id}"), true),
    )
    .await
    .unwrap();
    assert_eq!(
        db.query_row("SELECT quantity FROM orders WHERE id=1", [], |r| r
            .get::<_, i64>(0))
            .unwrap(),
        7
    );
    assert_eq!(
        db.query_row("SELECT COUNT(*) FROM audit", [], |r| r.get::<_, i64>(0))
            .unwrap(),
        1
    );
    assert_eq!(
        db.query_row("SELECT COUNT(*) FROM __konae_function_receipts", [], |r| {
            r.get::<_, i64>(0)
        })
        .unwrap(),
        1
    );
    drop(guard);
    drop(db);
    let pending = tokio::spawn(post("wait", json!({"id":1,"quantity":6,"wait":true})).send());
    let mut acquired = false;
    for _ in 0..100 {
        if tokio::time::timeout(
            Duration::from_millis(2),
            crate::named_lock(&state, &format!("write:{id}"), true),
        )
        .await
        .is_err()
        {
            acquired = true;
            break;
        }
        tokio::time::sleep(Duration::from_millis(2)).await;
    }
    assert!(
        acquired,
        "The A request must hold its native slot before publishing B"
    );
    payload.as_object_mut().unwrap().remove("initialModules");
    payload
        .as_object_mut()
        .unwrap()
        .remove("initialSignupPolicy");
    payload["serverArtifact"]["bundles"]["orders"] =
        json!(HANDLER.replace("version:'A'", "version:'B'"));
    let b = publish(&state, &payload).await;
    assert_ne!(b.artifact_version, deployed.artifact_version);
    let a_response = pending.await.unwrap().unwrap();
    let status = a_response.status();
    let a_response: Value = a_response.json().await.unwrap();
    assert_eq!(status, StatusCode::OK, "{a_response}");
    assert_eq!(a_response["version"], "A");
    let b_response: Value = get("", &accounts[0].0)
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(b_response["version"], "B");
    assert_eq!(b_response["calls"], 1);
    let replay: Value = post("same", changed)
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(replay, first);
    tokio::time::sleep(Duration::from_millis(1200)).await;
    let after_idle: Value = get("", &accounts[0].0)
        .send()
        .await
        .unwrap()
        .json()
        .await
        .unwrap();
    assert_eq!(after_idle["calls"], 1);
    let began = Instant::now();
    let deadline = get("/spin", &accounts[0].0).send().await.unwrap();
    assert_eq!(deadline.status(), StatusCode::GATEWAY_TIMEOUT);
    assert!(began.elapsed() < Duration::from_millis(1900));
    let recovered = get("", &accounts[0].0).send().await.unwrap();
    assert_eq!(recovered.status(), StatusCode::OK);
    let lock = crate::named_lock(&state, &format!("publish:{id}"), true).await;
    let waiting = get("", &accounts[0].0).send().await.unwrap();
    assert_eq!(waiting.status(), StatusCode::GATEWAY_TIMEOUT);
    drop(lock);
    let method = client
        .put(&url)
        .header("host", &deployed.hostname)
        .send()
        .await
        .unwrap();
    assert_eq!(method.status(), StatusCode::METHOD_NOT_ALLOWED);
    assert_eq!(method.headers()[header::ALLOW], "GET, POST");
    payload["serverArtifact"]["bundles"]["orders"] =
        json!("while (true) {} export function handle() {}");
    let c = publish(&state, &payload).await;
    let cold_timeout = get("", &accounts[0].0).send().await.unwrap();
    assert_eq!(cold_timeout.status(), StatusCode::GATEWAY_TIMEOUT);
    crate::usage::flush();
    let today = crate::usage::day(crate::now_ms());
    let summary = crate::usage::read_summary(&root, &b, &today, &today, true).unwrap();
    let latency = &summary["functionLatency"];
    let series = latency["series"].as_array().unwrap();
    assert_eq!(series.len(), 3, "{latency}");
    let a_series = series
        .iter()
        .find(|row| row["version"] == deployed.artifact_version)
        .unwrap();
    let b_series = series
        .iter()
        .find(|row| row["version"] == b.artifact_version)
        .unwrap();
    let c_series = series
        .iter()
        .find(|row| row["version"] == c.artifact_version)
        .unwrap();
    assert_eq!(a_series["samples"], 11, "{latency}");
    assert_eq!(a_series["timeouts"], 1, "{latency}");
    assert_eq!(a_series["replays"], 1, "{latency}");
    assert_eq!(b_series["samples"], 7, "{latency}");
    assert_eq!(b_series["timeouts"], 2, "{latency}");
    assert_eq!(b_series["coldStarts"], 3, "{latency}");
    assert_eq!(b_series["replays"], 1, "{latency}");
    assert_eq!(c_series["samples"], 1, "{latency}");
    assert_eq!(c_series["timeouts"], 1, "{latency}");
    assert_eq!(c_series["coldStarts"], 1, "{latency}");
    assert_eq!(c_series["execution"]["maxMs"], 0.0, "{latency}");
    assert!(
        c_series["initialization"]["maxMs"].as_f64().unwrap() >= 1400.0,
        "{latency}"
    );
    assert!(
        b_series["initialization"]["maxMs"].as_f64().unwrap() > 0.0,
        "{latency}"
    );
    assert!(
        b_series["execution"]["maxMs"].as_f64().unwrap() >= 1400.0,
        "{latency}"
    );
    assert!(
        b_series["queue"]["maxMs"].as_f64().unwrap() >= 1500.0,
        "{latency}"
    );
    serving.abort();
    drop(state);
    let _ = std::fs::remove_dir_all(root);
}
