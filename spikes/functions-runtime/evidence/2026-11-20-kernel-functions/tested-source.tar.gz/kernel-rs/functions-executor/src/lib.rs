pub mod budget;
mod containment;
pub mod protocol;
mod supervisor;

pub use budget::{Budget, BudgetError, MutationOutcomeState};
pub use containment::MemoryPolicy;
pub use protocol::{Input, Output, WorkerLimits};
use std::time::Instant;
pub use supervisor::{Worker, WorkerError, error_code};

pub trait ExecutionBudget {
    fn deadline(&self) -> Instant;
    fn is_cancelled(&self) -> bool;
}
