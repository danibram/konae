use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::io::{self, Read, Write};

pub const ABI: &str = "konae-functions/1";
pub const MAX_FRAME_BYTES: usize = 16 * 1024 * 1024;
pub const MAX_SOURCE_BYTES: usize = 8 * 1024 * 1024;
pub const MAX_HEADER_BYTES: usize = 16 * 1024;
pub const MAX_OPERATION_BYTES: usize = 64 * 1024;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WorkerLimits {
    pub heap_bytes: usize,
    pub response_bytes: usize,
    pub rss_bytes: usize,
    pub operation_limit: usize,
}
impl Default for WorkerLimits {
    fn default() -> Self {
        Self {
            heap_bytes: 64 * 1024 * 1024,
            response_bytes: 2 * 1024 * 1024,
            rss_bytes: 256 * 1024 * 1024,
            operation_limit: 64,
        }
    }
}
impl WorkerLimits {
    pub fn validate(&self) -> bool {
        self.heap_bytes >= 1024 * 1024
            && self.heap_bytes <= self.rss_bytes
            && self.response_bytes > 0
            && self.response_bytes <= 2 * 1024 * 1024
            && self.operation_limit > 0
            && self.operation_limit <= 4096
    }
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Input {
    pub url: String,
    pub method: String,
    pub headers: Vec<(String, String)>,
    pub body: Vec<u8>,
    pub actor: String,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Output {
    pub status: u16,
    pub headers: Vec<(String, String)>,
    pub body: String,
}
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Capability {
    pub generation: String,
    pub request: u64,
    pub token: String,
}
#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "kind", deny_unknown_fields)]
pub enum ParentMessage {
    Init {
        abi: String,
        function: String,
        source: String,
        generation: String,
        limits: WorkerLimits,
    },
    Invoke {
        capability: Capability,
        input: Input,
    },
    Spin {
        capability: Capability,
    },
    OperationResult {
        capability: Capability,
        sequence: u64,
        result: Result<Value, String>,
    },
    Cancel {
        capability: Capability,
    },
    Shutdown {
        grace_ms: u64,
    },
}
#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "kind", deny_unknown_fields)]
pub enum ChildMessage {
    Ready {
        abi: String,
        generation: String,
    },
    Operation {
        capability: Capability,
        sequence: u64,
        operation: String,
        args: Value,
    },
    Reply {
        capability: Capability,
        output: Output,
    },
    Failure {
        capability: Option<Capability>,
        code: String,
    },
    ShutdownComplete {
        invoked: bool,
        error: Option<String>,
    },
}

pub fn encode<T: Serialize>(message: &T) -> io::Result<Vec<u8>> {
    let data = serde_json::to_vec(message).map_err(io::Error::other)?;
    if data.is_empty() || data.len() > MAX_FRAME_BYTES {
        return Err(io::Error::other("frame_too_large"));
    }
    let mut frame = Vec::with_capacity(data.len() + 4);
    frame.extend_from_slice(&(data.len() as u32).to_be_bytes());
    frame.extend_from_slice(&data);
    Ok(frame)
}
pub fn read<R: Read, T: for<'de> Deserialize<'de>>(reader: &mut R) -> io::Result<T> {
    let mut prefix = [0; 4];
    reader.read_exact(&mut prefix)?;
    let len = u32::from_be_bytes(prefix) as usize;
    if len == 0 || len > MAX_FRAME_BYTES {
        return Err(io::Error::other("invalid_frame_length"));
    }
    let mut bytes = vec![0; len];
    reader.read_exact(&mut bytes)?;
    serde_json::from_slice(&bytes).map_err(io::Error::other)
}
pub fn write<W: Write, T: Serialize>(writer: &mut W, message: &T) -> io::Result<()> {
    writer.write_all(&encode(message)?)?;
    writer.flush()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    #[test]
    fn rejects_oversized_frame_before_reading_payload() {
        let bytes = (MAX_FRAME_BYTES as u32 + 1).to_be_bytes();
        let mut reader = Cursor::new(bytes);
        assert!(read::<_, ParentMessage>(&mut reader).is_err());
        assert_eq!(reader.position(), 4);
    }

    #[test]
    fn rejects_truncated_frame_and_unknown_fields() {
        let mut short = Cursor::new([0, 0, 0, 8, b'{']);
        assert!(read::<_, ParentMessage>(&mut short).is_err());
        let data = br#"{"kind":"Shutdown","grace_ms":10,"actor":"owner"}"#;
        let mut bytes = (data.len() as u32).to_be_bytes().to_vec();
        bytes.extend_from_slice(data);
        assert!(read::<_, ParentMessage>(&mut Cursor::new(bytes)).is_err());
    }

    #[test]
    fn preserves_operation_error_and_capability_on_roundtrip() {
        let capability = Capability {
            generation: "worker-1".into(),
            request: 2,
            token: "request-2".into(),
        };
        let message = ParentMessage::OperationResult {
            capability: capability.clone(),
            sequence: 3,
            result: Err("idempotency_conflict".into()),
        };
        let decoded: ParentMessage = read(&mut Cursor::new(encode(&message).unwrap())).unwrap();
        match decoded {
            ParentMessage::OperationResult {
                capability: actual,
                sequence,
                result,
            } => {
                assert_eq!(actual, capability);
                assert_eq!(sequence, 3);
                assert_eq!(result.unwrap_err(), "idempotency_conflict");
            }
            _ => panic!("unexpected frame"),
        }
    }
}
