use crate::WorkerError;
use anyhow::Result;
use std::path::PathBuf;

#[derive(Clone, Debug)]
pub enum MemoryPolicy {
    DevelopmentPolling,
    LinuxCgroup { delegated_root: PathBuf },
}

pub(crate) struct Containment {
    path: Option<PathBuf>,
}
impl Containment {
    pub(crate) fn prepare(policy: MemoryPolicy, bytes: usize, generation: &str) -> Result<Self> {
        match policy {
            MemoryPolicy::DevelopmentPolling => Ok(Self { path: None }),
            MemoryPolicy::LinuxCgroup { delegated_root } => {
                Self::cgroup(delegated_root, bytes, generation)
            }
        }
    }
    #[cfg(not(target_os = "linux"))]
    fn cgroup(_: PathBuf, _: usize, _: &str) -> Result<Self> {
        Err(WorkerError::new("containment_unavailable").into())
    }
    #[cfg(target_os = "linux")]
    fn cgroup(root: PathBuf, bytes: usize, generation: &str) -> Result<Self> {
        use std::fs;
        use std::os::unix::ffi::OsStrExt;
        let unavailable = || WorkerError::new("containment_unavailable");
        let root = root.canonicalize().map_err(|_| unavailable())?;
        let c_root =
            std::ffi::CString::new(root.as_os_str().as_bytes()).map_err(|_| unavailable())?;
        let mut filesystem = std::mem::MaybeUninit::<libc::statfs>::zeroed();
        if unsafe { libc::statfs(c_root.as_ptr(), filesystem.as_mut_ptr()) } != 0
            || unsafe { filesystem.assume_init().f_type as u64 } != libc::CGROUP2_SUPER_MAGIC as u64
        {
            return Err(unavailable().into());
        }
        let enabled =
            fs::read_to_string(root.join("cgroup.subtree_control")).map_err(|_| unavailable())?;
        if !["memory", "pids"]
            .iter()
            .all(|name| enabled.split_whitespace().any(|word| word == *name))
        {
            return Err(unavailable().into());
        }
        // Solo se escribe el subgrupo nuevo; la delegación pertenece al operador.
        let path = root.join(format!("konae-worker-{generation}"));
        fs::create_dir(&path).map_err(|_| unavailable())?;
        let group = Self {
            path: Some(path.clone()),
        };
        for (name, value) in [
            ("memory.max", bytes.to_string()),
            ("memory.swap.max", "0".into()),
            ("pids.max", "64".into()),
            ("memory.oom.group", "1".into()),
        ] {
            fs::write(path.join(name), &value).map_err(|_| unavailable())?;
            let observed = fs::read_to_string(path.join(name)).map_err(|_| unavailable())?;
            if observed.trim() != value {
                return Err(unavailable().into());
            }
        }
        if !path.join("cgroup.kill").is_file() {
            return Err(unavailable().into());
        }
        Ok(group)
    }
    pub(crate) fn attach(&self, pid: u32) -> Result<()> {
        if let Some(path) = &self.path {
            let unavailable = || WorkerError::new("containment_unavailable");
            let oom = format!("/proc/{pid}/oom_score_adj");
            std::fs::write(&oom, "0").map_err(|_| unavailable())?;
            if std::fs::read_to_string(&oom)
                .map_err(|_| unavailable())?
                .trim()
                != "0"
            {
                return Err(unavailable().into());
            }
            std::fs::write(path.join("cgroup.procs"), pid.to_string())
                .map_err(|_| unavailable())?;
            let processes =
                std::fs::read_to_string(path.join("cgroup.procs")).map_err(|_| unavailable())?;
            if !processes.lines().any(|line| line == pid.to_string()) {
                return Err(unavailable().into());
            }
        }
        Ok(())
    }
    pub(crate) fn kill(&self) {
        if let Some(path) = &self.path {
            let _ = std::fs::write(path.join("cgroup.kill"), "1");
        }
    }
    pub(crate) fn cleanup(&mut self) -> bool {
        let Some(path) = &self.path else {
            return true;
        };
        // Tras matar el grupo, la retirada de tareas del cgroup puede tardar un intervalo.
        for _ in 0..20 {
            match std::fs::remove_dir(path) {
                Ok(()) => {
                    self.path = None;
                    return true;
                }
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                    self.path = None;
                    return true;
                }
                Err(_) => std::thread::sleep(std::time::Duration::from_millis(5)),
            }
        }
        false
    }
}
impl Drop for Containment {
    fn drop(&mut self) {
        self.kill();
        let _ = self.cleanup();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strict_policy_refuses_missing_delegation_without_creating_it() {
        let root =
            std::env::temp_dir().join(format!("konae-missing-delegation-{}", std::process::id()));
        assert!(!root.exists());
        let result = Containment::prepare(
            MemoryPolicy::LinuxCgroup {
                delegated_root: root.clone(),
            },
            1024 * 1024,
            "test",
        );
        assert!(result.is_err());
        assert!(!root.exists());
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn ordinary_files_cannot_impersonate_cgroup_controls() {
        let root =
            std::env::temp_dir().join(format!("konae-fake-delegation-{}", std::process::id()));
        std::fs::create_dir(&root).unwrap();
        std::fs::write(root.join("cgroup.subtree_control"), "memory pids").unwrap();
        let result = Containment::prepare(
            MemoryPolicy::LinuxCgroup {
                delegated_root: root.clone(),
            },
            1024 * 1024,
            "test",
        );
        assert!(result.is_err());
        assert!(!root.join("konae-worker-test").exists());
        std::fs::remove_file(root.join("cgroup.subtree_control")).unwrap();
        std::fs::remove_dir(root).unwrap();
    }
}
