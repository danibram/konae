use crate::{
    ExecutionBudget, Input, MemoryPolicy, Output, WorkerLimits,
    containment::Containment,
    protocol::{self, Capability, ChildMessage, ParentMessage},
};
use anyhow::Result;
use serde_json::Value;
use std::{
    fmt, fs,
    io::{Read, Write},
    os::{fd::AsRawFd, unix::process::CommandExt},
    path::Path,
    process::{Child, ChildStdin, Command, Stdio},
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, Ordering},
        mpsc,
    },
    thread::{self, JoinHandle},
    time::{Duration, Instant},
};

#[derive(Debug)]
pub struct WorkerError {
    code: String,
}
impl WorkerError {
    pub fn new(code: impl Into<String>) -> Self {
        Self { code: code.into() }
    }
    pub fn code(&self) -> &str {
        &self.code
    }
}
impl fmt::Display for WorkerError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.code)
    }
}
impl std::error::Error for WorkerError {}
pub fn error_code(error: &anyhow::Error) -> &str {
    error
        .downcast_ref::<WorkerError>()
        .map_or("worker_failed", WorkerError::code)
}
fn fail(code: &str) -> anyhow::Error {
    WorkerError::new(code).into()
}
fn nonce() -> Result<String> {
    let mut bytes = [0u8; 32];
    getrandom::fill(&mut bytes).map_err(|_| fail("entropy_unavailable"))?;
    Ok(bytes.iter().map(|byte| format!("{byte:02x}")).collect())
}
fn remaining(budget: &impl ExecutionBudget) -> Result<Duration> {
    let left = budget.deadline().saturating_duration_since(Instant::now());
    if left.is_zero() {
        return Err(fail("deadline_exceeded"));
    }
    if budget.is_cancelled() {
        return Err(fail("cancelled"));
    }
    Ok(left)
}
struct Until(Instant);
impl ExecutionBudget for Until {
    fn deadline(&self) -> Instant {
        self.0
    }
    fn is_cancelled(&self) -> bool {
        false
    }
}

pub struct Worker {
    child: Option<Child>,
    input: Option<ChildStdin>,
    messages: mpsc::Receiver<ChildMessage>,
    reader: Option<JoinHandle<()>>,
    stderr_reader: Option<JoinHandle<()>>,
    reader_failed: Arc<AtomicBool>,
    stderr: Arc<Mutex<Vec<u8>>>,
    limits: WorkerLimits,
    generation: String,
    request: u64,
    busy: bool,
    shutdown_invoked: bool,
    containment: Containment,
}
impl Worker {
    pub fn spawn_with_policy(
        executable: &Path,
        function: &str,
        bundle_dir: &Path,
        budget: &impl ExecutionBudget,
        limits: WorkerLimits,
        policy: MemoryPolicy,
    ) -> Result<Self> {
        remaining(budget)?;
        if !limits.validate() {
            return Err(fail("invalid_worker_limits"));
        }
        if function.is_empty()
            || function.len() > 64
            || !function
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
        {
            return Err(fail("invalid_function_name"));
        }
        let primary = bundle_dir.join(format!("{function}.mjs"));
        let path = if primary.exists() {
            primary
        } else {
            bundle_dir.join(format!("{function}.js"))
        };
        let file = fs::File::open(&path)?;
        let metadata = file.metadata()?;
        if !metadata.is_file() || metadata.len() > protocol::MAX_SOURCE_BYTES as u64 {
            return Err(fail("bundle_too_large"));
        }
        let mut bytes = Vec::new();
        file.take(protocol::MAX_SOURCE_BYTES as u64 + 1)
            .read_to_end(&mut bytes)?;
        if bytes.len() > protocol::MAX_SOURCE_BYTES {
            return Err(fail("bundle_too_large"));
        }
        let source = String::from_utf8(bytes).map_err(|_| fail("bundle_invalid_utf8"))?;
        remaining(budget)?;
        let generation = nonce()?;
        let containment = Containment::prepare(policy, limits.rss_bytes, &generation)?;
        remaining(budget)?;
        let mut child = Command::new(executable)
            .arg("--function-worker")
            .env_clear()
            .current_dir("/")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .process_group(0)
            .spawn()?;
        if let Err(error) = containment.attach(child.id()) {
            let _ = child.kill();
            let _ = child.wait();
            return Err(error);
        }
        let input = child.stdin.take().unwrap();
        let mut stdout = child.stdout.take().unwrap();
        let mut stderr_pipe = child.stderr.take().unwrap();
        // El pipe no bloqueante permite aplicar el deadline también al envío.
        let flags = unsafe { libc::fcntl(input.as_raw_fd(), libc::F_GETFL) };
        if flags < 0
            || unsafe { libc::fcntl(input.as_raw_fd(), libc::F_SETFL, flags | libc::O_NONBLOCK) }
                < 0
        {
            let _ = child.kill();
            let _ = child.wait();
            return Err(fail("worker_pipe_failed"));
        }
        let (tx, messages) = mpsc::sync_channel(4);
        let reader_failed = Arc::new(AtomicBool::new(false));
        let failed = reader_failed.clone();
        let reader = thread::spawn(move || {
            loop {
                match protocol::read::<_, ChildMessage>(&mut stdout) {
                    Ok(message) => {
                        if tx.try_send(message).is_err() {
                            failed.store(true, Ordering::SeqCst);
                            break;
                        }
                    }
                    Err(_) => {
                        failed.store(true, Ordering::SeqCst);
                        break;
                    }
                }
            }
        });
        let stderr = Arc::new(Mutex::new(Vec::new()));
        let captured = stderr.clone();
        let stderr_reader = thread::spawn(move || {
            let mut chunk = [0u8; 4096];
            while let Ok(n) = stderr_pipe.read(&mut chunk) {
                if n == 0 {
                    break;
                }
                let mut tail = captured.lock().unwrap();
                tail.extend_from_slice(&chunk[..n]);
                if tail.len() > 65536 {
                    let excess = tail.len() - 65536;
                    tail.drain(..excess);
                }
            }
        });
        let mut worker = Self {
            child: Some(child),
            input: Some(input),
            messages,
            reader: Some(reader),
            stderr_reader: Some(stderr_reader),
            reader_failed,
            stderr,
            limits: limits.clone(),
            generation: generation.clone(),
            request: 0,
            busy: false,
            shutdown_invoked: false,
            containment,
        };
        let initialized = (|| {
            worker.send(
                &ParentMessage::Init {
                    abi: protocol::ABI.into(),
                    function: function.into(),
                    source,
                    generation,
                    limits,
                },
                budget,
            )?;
            match worker.receive(budget)? {
                ChildMessage::Ready { abi, generation }
                    if abi == protocol::ABI && generation == worker.generation =>
                {
                    Ok(())
                }
                _ => Err(fail("worker_initialization_failed")),
            }
        })();
        if let Err(error) = initialized {
            worker.stop();
            return Err(error);
        }
        Ok(worker)
    }
    pub fn pid(&self) -> Option<u32> {
        self.child.as_ref().map(Child::id)
    }
    pub fn diagnostics(&self) -> String {
        String::from_utf8_lossy(&self.stderr.lock().unwrap()).into_owned()
    }
    pub fn shutdown_invoked(&self) -> bool {
        self.shutdown_invoked
    }
    fn memory_check(&self) -> Result<()> {
        let pid = self.pid().ok_or_else(|| fail("worker_failed"))?;
        if let Some(rss) = resident_bytes(pid) {
            if rss > self.limits.rss_bytes {
                return Err(fail("worker_memory_limit"));
            }
        }
        Ok(())
    }
    fn send(&mut self, message: &ParentMessage, budget: &impl ExecutionBudget) -> Result<()> {
        let frame = protocol::encode(message).map_err(|_| fail("frame_too_large"))?;
        let mut offset = 0;
        while offset < frame.len() {
            remaining(budget)?;
            self.memory_check()?;
            match self
                .input
                .as_mut()
                .ok_or_else(|| fail("worker_failed"))?
                .write(&frame[offset..])
            {
                Ok(0) => return Err(fail("worker_failed")),
                Ok(n) => offset += n,
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    thread::sleep(Duration::from_millis(1))
                }
                Err(e) if e.kind() == std::io::ErrorKind::Interrupted => {}
                Err(_) => return Err(fail("worker_failed")),
            }
        }
        Ok(())
    }
    fn receive(&mut self, budget: &impl ExecutionBudget) -> Result<ChildMessage> {
        loop {
            let left = remaining(budget)?;
            self.memory_check()?;
            match self
                .messages
                .recv_timeout(left.min(Duration::from_millis(5)))
            {
                Ok(message) => return Ok(message),
                Err(mpsc::RecvTimeoutError::Disconnected) => return Err(fail("worker_failed")),
                Err(mpsc::RecvTimeoutError::Timeout) => {
                    if self.reader_failed.load(Ordering::SeqCst) {
                        return Err(fail("worker_failed"));
                    }
                }
            }
        }
    }
    fn capability(&mut self) -> Result<Capability> {
        self.request = self
            .request
            .checked_add(1)
            .filter(|x| *x < (1u64 << 53))
            .ok_or_else(|| fail("worker_generation_exhausted"))?;
        Ok(Capability {
            generation: self.generation.clone(),
            request: self.request,
            token: nonce()?,
        })
    }
    pub fn invoke_with(
        &mut self,
        input: Input,
        budget: &impl ExecutionBudget,
        callback: &mut dyn FnMut(&str, Value) -> std::result::Result<Value, String>,
    ) -> Result<Output> {
        if input.body.len() > 16384
            || header_bytes(&input.headers) > protocol::MAX_HEADER_BYTES
            || input.url.len() > 8192
            || input.actor.len() > 4096
        {
            return Err(fail("invalid_input"));
        }
        let capability = self.capability()?;
        let message = ParentMessage::Invoke {
            capability: capability.clone(),
            input,
        };
        self.execute(message, capability, budget, callback)
    }
    pub fn spin(&mut self, budget: &impl ExecutionBudget) -> Result<Output> {
        let capability = self.capability()?;
        self.execute(
            ParentMessage::Spin {
                capability: capability.clone(),
            },
            capability,
            budget,
            &mut |_, _| Err("forbidden".into()),
        )
    }
    fn execute(
        &mut self,
        message: ParentMessage,
        capability: Capability,
        budget: &impl ExecutionBudget,
        callback: &mut dyn FnMut(&str, Value) -> std::result::Result<Value, String>,
    ) -> Result<Output> {
        if self.busy {
            return Err(fail("worker_busy"));
        }
        self.busy = true;
        let result = (|| {
            self.send(&message, budget)?;
            let mut sequence = 0u64;
            let mut native_error: Option<String> = None;
            loop {
                match self.receive(budget)? {
                    ChildMessage::Operation {
                        capability: received,
                        sequence: seq,
                        operation,
                        args,
                    } => {
                        if received != capability || seq != sequence + 1 {
                            return Err(fail("capability_expired"));
                        }
                        sequence = seq;
                        if sequence > self.limits.operation_limit as u64 {
                            return Err(fail("operation_limit"));
                        }
                        if operation.len() > 128
                            || serde_json::to_vec(&args)?.len() > protocol::MAX_OPERATION_BYTES
                        {
                            return Err(fail("operation_too_large"));
                        }
                        remaining(budget)?;
                        let reply = if let Some(code) = &native_error {
                            Err(code.clone())
                        } else {
                            callback(&operation, args)
                        };
                        if let Err(code) = &reply {
                            native_error.get_or_insert_with(|| code.clone());
                        }
                        self.send(
                            &ParentMessage::OperationResult {
                                capability: capability.clone(),
                                sequence,
                                result: reply,
                            },
                            budget,
                        )?;
                    }
                    ChildMessage::Reply {
                        capability: received,
                        output,
                    } => {
                        if received != capability {
                            return Err(fail("capability_expired"));
                        }
                        if let Some(code) = native_error {
                            return Err(fail(&code));
                        }
                        remaining(budget)?;
                        validate_output(&output, &self.limits)?;
                        return Ok(output);
                    }
                    ChildMessage::Failure {
                        capability: Some(received),
                        code,
                    } if received == capability => {
                        return Err(fail(native_error.as_deref().unwrap_or(&code)));
                    }
                    _ => return Err(fail("worker_protocol_error")),
                }
            }
        })();
        self.busy = false;
        if result.is_err() {
            // La cooperación nunca amplía el deadline absoluto de la petición.
            let until = Until(
                budget
                    .deadline()
                    .min(Instant::now() + Duration::from_millis(10)),
            );
            let _ = self.send(&ParentMessage::Cancel { capability }, &until);
            if error_code(result.as_ref().err().unwrap()) == "cancelled" {
                let _ = self.receive(&until);
            }
            self.stop();
        }
        result
    }
    pub fn shutdown(&mut self, grace: Duration) -> Result<()> {
        if self.child.is_none() {
            return Ok(());
        }
        if self.busy {
            self.stop();
            return Err(fail("worker_busy"));
        }
        let grace = grace.min(Duration::from_secs(1));
        let budget = Until(Instant::now() + grace);
        let result = (|| {
            self.send(
                &ParentMessage::Shutdown {
                    grace_ms: grace.as_millis() as u64,
                },
                &budget,
            )?;
            match self.receive(&budget)? {
                ChildMessage::ShutdownComplete { invoked, error } => {
                    self.shutdown_invoked = invoked;
                    error.map_or(Ok(()), |code| Err(fail(&code)))
                }
                _ => Err(fail("worker_protocol_error")),
            }
        })();
        if !self.stop() && result.is_ok() {
            return Err(fail("containment_cleanup_failed"));
        }
        result
    }
    fn stop(&mut self) -> bool {
        self.containment.kill();
        if let Some(mut child) = self.child.take() {
            // El hijo pertenece al grupo que creó este supervisor.
            unsafe {
                libc::kill(-(child.id() as i32), libc::SIGKILL);
            }
            let _ = child.kill();
            let _ = child.wait();
        }
        self.input.take();
        if let Some(reader) = self.reader.take() {
            let _ = reader.join();
        }
        if let Some(reader) = self.stderr_reader.take() {
            let _ = reader.join();
        }
        self.containment.cleanup()
    }
}
impl Drop for Worker {
    fn drop(&mut self) {
        let _ = self.shutdown(Duration::from_millis(10));
    }
}
fn header_bytes(headers: &[(String, String)]) -> usize {
    headers.iter().fold(0usize, |sum, (k, v)| {
        sum.saturating_add(k.len()).saturating_add(v.len())
    })
}
fn validate_output(output: &Output, limits: &WorkerLimits) -> Result<()> {
    if output.body.len() > limits.response_bytes
        || header_bytes(&output.headers) > protocol::MAX_HEADER_BYTES
    {
        return Err(fail("response_too_large"));
    }
    if !(200..=599).contains(&output.status) || output.headers.len() > 128 {
        return Err(fail("invalid_response"));
    }
    for (name, value) in &output.headers {
        if name.is_empty()
            || !name
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b"!#$%&'*+-.^_`|~".contains(&b))
            || value.bytes().any(|b| b == b'\r' || b == b'\n' || b == 0)
            || matches!(
                name.to_ascii_lowercase().as_str(),
                "connection"
                    | "transfer-encoding"
                    | "content-length"
                    | "upgrade"
                    | "trailer"
                    | "keep-alive"
                    | "proxy-authenticate"
                    | "proxy-authorization"
                    | "te"
            )
        {
            return Err(fail("invalid_response"));
        }
    }
    Ok(())
}
#[cfg(target_os = "macos")]
fn resident_bytes(pid: u32) -> Option<usize> {
    let mut info = std::mem::MaybeUninit::<libc::proc_taskinfo>::zeroed();
    let size = std::mem::size_of::<libc::proc_taskinfo>();
    let read = unsafe {
        libc::proc_pidinfo(
            pid as i32,
            libc::PROC_PIDTASKINFO,
            0,
            info.as_mut_ptr().cast(),
            size as i32,
        )
    };
    (read == size as i32).then(|| unsafe { info.assume_init().pti_resident_size as usize })
}
#[cfg(target_os = "linux")]
fn resident_bytes(pid: u32) -> Option<usize> {
    let status = fs::read_to_string(format!("/proc/{pid}/status")).ok()?;
    status.lines().find_map(|line| {
        line.strip_prefix("VmRSS:")
            .and_then(|s| s.split_whitespace().next())
            .and_then(|s| s.parse::<usize>().ok())
            .map(|kib| kib.saturating_mul(1024))
    })
}
#[cfg(not(any(target_os = "linux", target_os = "macos")))]
fn resident_bytes(_: u32) -> Option<usize> {
    None
}
