

export type SdkArgument = {
  name: string;
  type: string;
  required: boolean;
  description: string;
};

export type SdkError = {
  message: string;
  when: string;
  source: "kernel" | "sdk";
  /** The HTTP status a route answers with, for refusals seen on an HTTP route. */
  status?: number;
  /** Exact messages; placeholders are written <key> and <name>. */
  preview?: readonly string[] | null;
};

export type SdkExample = {
  code: string;
  comment?: string;
};

export type SdkCall = {
  /** The property on the module, e.g. "call" for miniapp.actions.call. */
  name: string;
  signature: string;
  summary: string;
  /** Whether a visitor without a session may use it on a public Deployment. */
  signedOut: boolean;
  /** The runtime MCP tools the published SDK calls, in kernel-rs/kernel/src/runtime.rs runtime_tools(). */
  tools: string[];
  args: SdkArgument[];
  returns: string;
  errors: SdkError[];
  limits: string[];
  examples: SdkExample[];
  /** How the editor preview behaves differently, when it does. */
  preview?: string;
};

/**
 * A key a module adds to a Capsule file, for modules that are declared rather
 * than called. `errors` lists what publishing or the declared route refuses.
 */
export type SdkDeclaration = {
  file: string;
  key: string;
  summary: string;
  errors?: SdkError[];
  limits?: string[];
};

export type SdkModule = {
  name: string;
  title: string;
  summary: string;
  switch: boolean;
  options: SdkModuleOption[];
  permission: string;
  agentRule: "after-owner-confirms" | "never";
  requires: string[];
  uses: string[];
  calls: SdkCall[];
  declarations: SdkDeclaration[];
  notes: string[];
};

export type SdkModuleOption = {
  key: string;
  type: "boolean" | "enum" | "path" | "string" | "number" | "signup-policy" | "sign-in-methods";
  values?: string[];
  valueLabels?: Record<string, string>;
  defaultLabel?: string;
  valuesFrom?: "app-images";
  default: unknown;
  label: string;
  help: string;
};

export type SdkContract = {
  version: 1;
  global: "miniapp";
  endpoint: string;
  summary: string;
  /** Things an app may not rely on, stated so neither agent invents them. */
  absent: string[];
  /** Refusals any call that reaches the Kernel can return. */
  errors: SdkError[];
  modules: SdkModule[];
};

const uploadTransfer: SdkError[] = [
  { message: "Too many active transfers. Cancel completed transfers before starting another.", when: "the actor already holds 2 transfers, or the Deployment holds 32", source: "kernel", preview: null },
  { message: "Transfer not found or expired.", when: "a transfer outlived its 10 minutes", source: "kernel", preview: null },
  { message: "Upload size or SHA-256 mismatch.", when: "the bytes the Kernel received differ from the file's size or SHA-256", source: "kernel", preview: null },
  { message: "File upload failed.", when: "the Kernel refused the bytes without saying why", source: "sdk", preview: null },
];

const noFileId: SdkError = { message: "A file ID is required.", when: "fileId is not a non-empty string", source: "sdk" };
const badVisibility: SdkError = { message: "File visibility must be private or public.", when: "the visibility is unknown, or app-users was requested in an app without that policy", source: "kernel" };
const fixedVisibility: SdkError = { message: "File visibility is fixed to app-users by this app.", when: "the app requires app-users and the caller specifies private or public", source: "kernel" };
const notUploader: SdkError = { message: "Only the person who uploaded this file may change or delete it.", when: "the caller may read the file but did not upload it", source: "kernel" };
const unreadable: SdkError = { message: "File not found.", when: "the file does not exist, was deleted, or the caller may not read it", source: "kernel" };

const fileShape = "{ id, name, type, size, visibility, createdAt, ownerId, url }. ownerId is present only on files the caller uploaded. url is the path files.url returns for the file. The Kernel serves JavaScript, HTML, XML and SVG types as application/octet-stream";
const storedShape = "{ id, name, type, size, visibility, createdAt, ownerId, url }, where url is the path files.url returns for the new file";

export const sdkContract = {
  version: 1,
  global: "miniapp",
  endpoint: "/_konae/mcp",
  summary: "window.miniapp is the only host surface a Capsule has, in the editor preview and on every Deployment. Each module is a namespace on it. A published call is one or more MCP tool calls to the runtime endpoint, /_konae/mcp under the page's base path, on the host the page loaded from, the Deployment's generated hostname or its custom domain, with that host's app session cookie. The base path is /p/<id-or-name> when the page's address starts with /p/<segment>, and empty otherwise. On a Deployment the page's Content Security Policy refuses inline event handlers, fetches to other origins, WebAssembly, eval and new Function; the editor preview applies no policy.",
  absent: [
    "no fetch to other origins",
    "no localStorage contract",
    "no miniapp.db and no SQL from the browser",
    "no miniapp.track and no analytics call: a Signal is declared on a Server Action and recorded when miniapp.actions.call runs it",
  ],
  errors: [
    { message: "Sign in to use Konae MCP.", when: "the Deployment is private and the visitor has no session; actions.call then sends the browser to /_konae/login and auth.session returns the anonymous state instead", source: "kernel", preview: null },
    { message: "Deployment not found.", when: "the host name matches no Deployment", source: "kernel", preview: null },
    { message: "Cross-origin or unrecognized-host MCP request rejected.", when: "the request does not come from the origin of the host it is sent to, or that host is neither the Deployment's generated hostname nor its verified custom domain, such as a custom domain whose TXT record domain_set has not found yet", source: "kernel", preview: null },
    { message: "MCP request exceeds 200 KB.", when: "one request body is larger than 200,000 bytes", source: "kernel", preview: null },
    { message: "Invalid MCP response.", when: "the response does not answer the request the SDK sent", source: "sdk", preview: null },
  ],
  modules: [
    {
      name: "auth",
      title: "App accounts",
      summary: "Who is using the app. The Kernel owns accounts and sessions; the app only reads the current one.",
      switch: true, options: [
        { key: "signupPolicy", type: "signup-policy", values: ["open", "allowlist", "invitation", "closed"], valueLabels: { open: "Open", allowlist: "Allowlist", invitation: "Invitation only", closed: "Closed" }, default: null, label: "Who can create an account", help: "Choose who may create an app account. Allowlist entries stay as separate email addresses or domains." },
        { key: "signInMethods", type: "sign-in-methods", values: ["password", "google"], valueLabels: { password: "Email and password", google: "Continue with Google" }, default: ["password"], label: "Sign-in methods", help: "Password stays on. Google needs this app's Google client set as signing secrets." },
      ], permission: "manage_users", agentRule: "after-owner-confirms", requires: [], uses: ["private deployment", "app accounts or invitations", "authenticated actions", "actor bindings"],
      declarations: [],
      notes: [
        "Visibility decides who may open the app shell. It never grants data access on its own.",
        "An app account has no role the Kernel keeps. An app that needs an administrator keeps roles in its own table, keyed by the account ID that actor.id binds, and its owner names the first one with SQL in the editor's Data panel.",
        "The Deployment's Signup Policy decides who may create an account: Open, Invitation only, Closed or an Allowlist. Under Invitation only, the sign-in page offers no account creation; invited people accept from the link in their email, which opens /_konae/invitation. On an installation whose development transport sends no email, the owner's invitation call answers that link as acceptUrl, once, for the owner to hand over. A pending person who signs in with the right password, or with Google, is told that an invitation is waiting.",
        "The owner may add Continue with Google to the sign-in page in the Users view, once the app's own Google client ID and secret are set as signing secrets. A Google sign-in reaches the app account that holds the same email, with the same actor.id as the password, and the Signup Policy decides whether an email without an account gets one. Google proves only Gmail addresses and addresses of a Google Workspace domain; any other address signs in with email and password. Password sign-in stays on.",
      ],
      calls: [
        {
          name: "session",
          signature: "miniapp.auth.session()",
          summary: "Read the signed-in Runtime Actor, or the anonymous state so the app can show a sign-in button.",
          signedOut: true,
          tools: ["auth_session"],
          args: [],
          returns: "{ userId, name, role }. Signed in, name is the account email and role is \"member\". Signed out, { userId: \"anonymous\", name: \"Anonymous\", role: \"anonymous\" }",
          errors: [],
          limits: [],
          examples: [{ code: "const session = await miniapp.auth.session();", comment: "{ userId, name, role }; role is \"anonymous\" when signed out" }],
          preview: "Returns Alice or Bob, the preview's test accounts, with role \"member\", or the anonymous state.",
        },
        {
          name: "signIn",
          signature: "miniapp.auth.signIn()",
          summary: "Send the visitor to the Deployment's login page at /_konae/login, under the page's base path.",
          signedOut: true,
          tools: [],
          args: [],
          returns: "nothing; the page navigates away",
          errors: [],
          limits: [],
          examples: [{ code: "await miniapp.auth.signIn();", comment: "published login page, preview selects Alice" }],
          preview: "Signs in as Alice without leaving the page and returns her session.",
        },
        {
          name: "signInWithGoogle",
          signature: "miniapp.auth.signInWithGoogle()",
          summary: "Send the visitor to Google through /_konae/auth/google/start. It is a navigation, so connect-src does not apply; Google returns the person to the app signed in, or to a page that says why not.",
          signedOut: true,
          tools: [],
          args: [],
          returns: "nothing; the page navigates away",
          errors: [
            { message: "Google sign-in is not turned on for this app.", when: "the owner has not turned Google on, or the app's Google client is not set on this installation; the start page says so", source: "kernel", preview: ["The editor preview has no Google sign-in."] },
            { message: "This app is not accepting new accounts for this email address.", when: "the Google email has no account here and the Signup Policy does not admit it", source: "kernel", preview: null },
            { message: "This Google account uses an email address Google does not manage, so it cannot sign in here. Sign in with email and password.", when: "the address is neither a gmail.com address nor one of the Google Workspace domain the token names", source: "kernel", preview: null },
          ],
          limits: ["Shares the sign-in rate limit of the Deployment."],
          examples: [{ code: "miniapp.auth.signInWithGoogle();", comment: "Continue with Google" }],
          preview: "Refuses with \"The editor preview has no Google sign-in.\" Try it on a published Deployment.",
        },
        {
          name: "signOut",
          signature: "miniapp.auth.signOut()",
          summary: "Revoke this app session and clear its cookie.",
          signedOut: false,
          tools: ["auth_logout"],
          args: [],
          returns: "{ ok: true }",
          errors: [
            { message: "authentication-required", when: "no one is signed in", source: "kernel", preview: null },
          ],
          limits: [],
          examples: [{ code: "await miniapp.auth.signOut();", comment: "revoke this app session" }],
          preview: "Switches to the signed-out state and returns the anonymous session.",
        },
      ],
    },
    {
      name: "actions",
      title: "Data and actions",
      summary: "The only door to the database. A call names a Server Action declared in actions.json and passes its input; the Kernel authorizes the caller, binds the input and runs the action's one SQL statement, or records its Signal.",
      switch: true, options: [], permission: "publish", agentRule: "after-owner-confirms", requires: [], uses: ["actions.json", "schema.sql", "miniapp.actions"],
      declarations: [
        {
          file: "actions.json",
          key: "page",
          summary: "{ path, file, list? } on an anonymous query. The Kernel binds path parameters to the query's input bindings, serves the named file with the row's title and card, and exposes parameters as miniapp.page.params. list names an anonymous query with no inputs for the sitemap.",
          errors: [
            { message: "Action <name> declares a page path, so it must be an anonymous query.", when: "page is set on any other action or an authenticated query", source: "kernel" },
            { message: "Action <name> declares page parameters that do not match its input bindings.", when: "the named parameters and input binding keys differ", source: "kernel" },
            { message: "Actions <name> and <name> both bind page path <key>.", when: "two page declarations have the same literal and parameter pattern", source: "kernel" },
            { message: "Action <name> names <key> as its page file, but the Build Artifact does not contain it.", when: "the named file is absent from the Build Artifact at release", source: "kernel" },
            { message: "Action <name> has a page query that does not return a title column.", when: "the query does not select a column named title", source: "kernel" },
            { message: "Action <name> names <key> as its page list, whose columns must match the page parameters and optional updated.", when: "the list query's selected columns differ", source: "kernel" },
          ],
          limits: ["The first path segment is literal.", "The page query returns at most one row.", "The list query returns at most 1000 rows."],
        },
        {
          file: "actions.json",
          key: "kind",
          summary: "Each kind takes its own top-level keys. A query takes kind, access, statement, bindings and http. A mutation takes kind, access, statement, bindings, http, signal, guard, notify and schedule. A signal action takes kind, access, bindings, signal and an empty statement. A call takes kind, access, bindings, url, method, body, headers, auth, then and an empty statement. Any other key is refused, so a misspelled or misplaced key cannot pass and do nothing. A key set to null counts as absent. A key with its own refusal, such as a guard on a query, gets that refusal instead. The Validation Gate and the Kernel refuse the same declarations with the same messages.",
          errors: [
            { message: "Action <name> has a key <key> that a <kind> action does not take.", when: "the action declares a top-level key its kind does not take; with several, the first in sorted order", source: "kernel" },
          ],
        },
        {
          file: "actions.json",
          key: "signal",
          summary: "{ \"name\": \"order.placed\", \"properties\"?: [\"input binding keys\", \"actor\"] } on a mutation, or on an action of \"kind\": \"signal\" that has access and bindings but no statement. When the action succeeds, and for a mutation only when it changed at least one row, the Kernel records the Signal with the named inputs as its properties, in the Deployment's Usage store. The property actor records the caller's ID: the user's, the API key's, or null for a visitor or a signed request. A signal action runs no SQL and returns { recorded: true }. The owner reads Signals with signals_read; the app cannot. The Validation Gate and the Kernel refuse the same declarations with the same messages.",
          errors: [
            { message: "Action <name> is a query, so it cannot declare a signal. Declare it on a mutation or on a \"kind\": \"signal\" action.", when: "the action is a query", source: "kernel" },
            { message: "Action <name> names signal property <key>, which is not one of its input bindings.", when: "a property is not the key of an input binding; actor, kernel and literal bindings have no key", source: "kernel" },
            { message: "Action <name> names signal property <key> twice.", when: "properties lists a key twice", source: "kernel" },
            { message: "Action <name> names signal property actor, which records the caller's ID, and also has an input named actor. Rename the input.", when: "properties lists actor and an input binding's key is actor", source: "kernel" },
            { message: "Action <name> names more than 8 signal properties.", when: "properties lists more than 8 keys", source: "kernel" },
            { message: "Action <name> names an invalid signal. Use dot-separated lowercase words, such as \"order.placed\", up to 64 characters.", when: "the name has one word, a capital, a space, an empty part or more than 64 characters", source: "kernel" },
            { message: "Action <name> has an invalid signal declaration.", when: "signal is not an object, has a key other than name and properties, has no name, or properties is not a list of strings", source: "kernel" },
            { message: "Action <name> is a signal action, so it must declare a signal.", when: "the kind is signal and there is no signal key", source: "kernel" },
            { message: "Action <name> is a signal action, so it runs no SQL and cannot declare a statement.", when: "the kind is signal and the action has a statement", source: "kernel" },
          ],
          limits: [
            "8 properties per Signal; a string property keeps its first 128 bytes",
            "a signal action counts toward the action limit like any other action",
            "a signal action cannot declare http",
            "a mutation that changed no row records no Signal",
            "the Kernel keeps the newest 50,000 Signals per Deployment and drops the oldest",
          ],
        },
        {
          file: "actions.json",
          key: "guard",
          summary: "\"guard\": \"<message>\" on a mutation. When its statement changes no row, the Kernel refuses the call with that message instead of answering { changes: 0, lastInsertId: 0 }: a tool error for miniapp.actions.call, 403 on an HTTP route. Usage counts the call under refused, and no Signal is recorded. Write the app's rule into the statement's WHERE, such as \"the caller is an organizer\" or \"the slot is free\", and the guard is what the person sees when the rule says no. Without a guard, a mutation that changes no row answers { changes: 0, lastInsertId: 0 }. The Validation Gate and the Kernel refuse the same declarations with the same messages.",
          errors: [
            { message: "Action <name> is a query, so it cannot declare a guard. Declare it on a mutation.", when: "the action is a query", source: "kernel" },
            { message: "Action <name> is a signal action, so it cannot declare a guard. Declare it on a mutation.", when: "the action is a signal action", source: "kernel" },
            { message: "Action <name> has an invalid guard. Use a message of 1 to 200 characters on one line.", when: "guard is not a string, is empty or blank, is longer than 200 characters, or holds a line break or another control character", source: "kernel" },
          ],
          limits: [
            "a guard is 1 to 200 characters on one line",
          ],
        },
        {
          file: "actions.json",
          key: "notify",
          summary: "\"notify\": { \"to\": \"owner\" or \"actor\" or { \"column\": \"<name>\" }, \"changes\": [\"<column>\", ...], \"subject\": \"<template>\", \"body\": \"<template>\" } on a mutation; \"changes\" is optional. When its statement changes a row, the Kernel queues email: to the app's contact email in konae.json, which the owner sets in App settings or with contact_email_set and a first publish from Konae fills with the owner's email when Konae knows it, to the calling account's email when that account proved it by answering a verification, invitation or recovery link, or, with to: { column }, one email to each such account of this app whose ID a changed row holds in that column, listing only that account's rows. It never sends to an address from the input or from a row: a column value is an account ID, and a value that is not a verified account of this Deployment sends nothing. The templates may use {input.<key>} for one of the action's input bindings, {actor.id}, {kernel.now} (the time of the call or run, as 2026-11-08 07:00 UTC), {changes.count} (rows changed, or the recipient's own rows with to: { column }) and, in the body only, {changes}: one line per changed row with the \"changes\" columns joined by \" · \", at most 50 lines and then \"- and <n> more\". The Kernel reads the rows back by appending its own RETURNING to the statement, so the columns belong to the table the statement changes; the author still writes no RETURNING, and the answer stays changes and lastInsertId. A value loses its line breaks, keeps 200 characters and is escaped in the HTML part. The mutation answers as it would without notify, and an email that cannot be sent never fails it: Usage counts every notice under notify as \"<action>: queued\" or \"<action>: <reason>\", and the owner reads the queue with mail_status. Scheduled runs and a call's then mutation also process notify when they change rows. They have no caller, so to owner and to { column } work and to actor records no-account. The editor preview sends no email. The Validation Gate and the Kernel refuse the same declarations with the same messages.",
          errors: [
            { message: "Action <name> is a query, so it cannot declare notify. Declare it on a mutation.", when: "the action is a query", source: "kernel" },
            { message: "Action <name> is a signal action, so it cannot declare notify. Declare it on a mutation.", when: "the action is a signal action", source: "kernel" },
            { message: "Action <name> has an invalid notify declaration. Give \"to\", \"subject\", \"body\" and, to list changed rows, \"changes\", and nothing else.", when: "notify is not an object, has another key, or subject or body is missing or not a string", source: "kernel" },
            { message: "Action <name> has an invalid notify recipient. Use \"owner\", \"actor\" or {\"column\": \"<name>\"} for a column of account IDs.", when: "to is missing, an object other than { column } with a column name, or anything else, such as an address or an input", source: "kernel" },
            { message: "Action <name> has an invalid notify changes list. Name 1 to 8 columns of the changed table, each once, in letters, digits and underscores.", when: "changes is not a list, is empty, has more than 8 items, names a column twice, or holds something other than a column name", source: "kernel" },
            { message: "Action <name> has an invalid notify subject. Use 1 to 120 characters on one line.", when: "the subject is blank, longer than 120 characters, or holds a line break or another control character", source: "kernel" },
            { message: "Action <name> has an invalid notify body. Use 1 to 2000 characters, with line breaks and no other control characters.", when: "the body is blank, longer than 2000 characters, or holds a control character other than a line break", source: "kernel" },
            { message: "Action <name> names an unknown placeholder {<key>} in its notify <field>. Use {input.<key>} for one of its input bindings, {actor.id}, {kernel.now}, {changes} or {changes.count}.", when: "a placeholder is not {actor.id} or {input.<key>} for one of the action's input bindings, such as {actor.email} or {input.email} with no email input", source: "kernel" },
            { message: "Action <name> has an unclosed placeholder in its notify <field>. Close it with \"}\".", when: "a { has no } after it", source: "kernel" },
            { message: "Action <name> puts {changes} in its notify subject. Put {changes} in the body, and {changes.count} in the subject.", when: "the subject holds {changes}", source: "kernel" },
            { message: "Action <name> uses {changes} in its notify body without a changes list. Name the columns to show in notify \"changes\".", when: "the body holds {changes} and notify has no changes list", source: "kernel" },
            { message: "Action <name> names a notify column its statement cannot return. Name columns of the table the statement changes.", when: "a changes column or the to column is not a column of the table the statement changes, checked against the schema at the Gate and at publish", source: "kernel" },
          ],
          limits: [
            "a subject template is 1 to 120 characters on one line; a body template is 1 to 2000 characters",
            "a placeholder's value keeps 200 characters on one line; a rendered subject keeps 200 characters and a body 5,000",
            "notices count apart from account email: 200 a day per app, 500 a day per owner and 50 a day per recipient from one app, and every email counts toward the installation's 1,000 a day",
            "nothing is sent while the installation's sender preflight is not ready; the notice is recorded as failed with sender-not-ready",
            "a notice not sent within a day fails as notice-expired",
            "changes names 1 to 8 columns; {changes} lists at most 50 rows per notice",
            "one run reads back at most 1,000 changed rows and writes to at most 50 accounts through to: { column }, in account ID order; each account past the 50th counts under notify as recipient-cap",
          ],
        },
        {
          file: "actions.json",
          key: "schedule",
          summary: "\"schedule\": { \"every\": \"15m\" } or { \"every\": \"6h\" } or { \"daily\": \"02:00\" } on a mutation that takes no input. The Kernel's own timer runs it once in each period, or once a day at that UTC time, with no caller: an actor binding is null, kernel.now is the time of the run, and literals bind as written. Use it for work that must happen when nobody asks, such as releasing a hold that lapsed or closing a day. A run that changes no row had nothing to do, so the guard does not apply; a run that changed a row records the action's Signal with actor null. A changed run also processes notify through the notice queue. Use to owner, or to { column } to reach the accounts the changed rows name; to actor records no-account because the timer has no caller. A run queues one notice per recipient, and {changes} lists the rows it changed, so a digest can say what is due. The owner reads each run, with its outcome and changes, under scheduled with usage_summary. Only the timer runs it: a call through miniapp.actions.call or actions_invoke is refused with \"Action <name> runs only on its schedule.\", unless the action also declares an http route, which answers as its callers say. The Validation Gate and the Kernel refuse the same declarations with the same messages. The editor preview runs no schedule; konae dev and a Deployment do.",
          errors: [
            { message: "Action <name> is a query, so it cannot declare a schedule. Declare it on a mutation.", when: "the action is a query", source: "kernel" },
            { message: "Action <name> is a signal action, so it cannot declare a schedule. Declare it on a mutation.", when: "the action is a signal action", source: "kernel" },
            { message: "Action <name> declares a schedule, so it cannot take input. A scheduled run has no caller to supply it; bind only actor, kernel and literal values.", when: "a binding has source input", source: "kernel" },
            { message: "Action <name> has an invalid schedule. Declare \"every\" with minutes or hours, such as \"15m\" or \"6h\", or \"daily\" with a UTC time, such as \"02:00\".", when: "schedule is not an object with exactly one of every and daily, or every is not a whole number of 1 to 5 digits followed by m or h, such as a cron expression", source: "kernel" },
            { message: "Action <name> runs every <key>, more often than every 5 minutes. Use \"5m\" or longer.", when: "every is shorter than 5 minutes", source: "kernel" },
            { message: "Action <name> runs every <key>, less often than once a day. Use \"daily\" or a period of 24 hours or less.", when: "every is longer than 24 hours", source: "kernel" },
            { message: "Action <name> has an invalid daily time. Use HH:MM in UTC, from 00:00 to 23:59.", when: "daily is not two digits, a colon and two digits naming a time of day", source: "kernel" },
            { message: "Action <name> declares subscribe, but the Kernel pushes no updates to a page. Poll a query that reads rows after a cursor instead.", when: "any action has a subscribe key", source: "kernel" },
          ],
          limits: [
            "every runs from 5 minutes to 24 hours; periods count from 1970-01-01 00:00 UTC, so a period that divides the day, such as every 15m, runs at :00, :15, :30 and :45",
            "one run per period: a Kernel that was down for several periods runs the action once when it is back, and a restart does not run it again in the same period",
            "publishing never runs it; the first run is at the next period",
            "a run takes the app's data lock and has the 2-second statement budget",
            "a run that fails is retried at the next tick, once a minute, and the Deployment's runs never overlap",
            "an app in maintenance runs nothing, and runs once when it leaves it",
            "the Kernel keeps the newest 10,000 runs per Deployment; usage_summary returns the newest 500 in its range",
          ],
        },
      ],
      notes: [
        "A binding passes who calls: { \"source\": \"actor\", \"field\": \"id\" } is the signed-in person's ID or the API key's ID, and refuses a caller without one. It cannot come from the input. Roles are rows in the app's own tables, checked in SQL against that ID.",
        "A query action returns the rows of its SELECT. Column names are exactly the ones the SELECT projects, so alias any expression the app reads.",
        "A mutation action returns { changes, lastInsertId }. Read changed rows with a separate query. A mutation that declares a guard and changes no row is refused with the guard instead.",
        "The Action Contract, action-contract.json, lists every action with its inputs, the columns it returns, its errors and limits. It is written from actions.json and schema.sql by konae contract and carried in the export; an expression the SELECT returns without AS has no name in it, and the Validation Gate warns.",
        "To record that something happened, such as a signup to a newsletter or a finished lesson, declare a signal on the mutation that does it, or add an action of kind signal and call it with miniapp.actions.call. There is no other tracking call.",
        "A call the Kernel refuses records no Signal and counts in no Usage total, except a guard's refusal, which Usage counts under refused.",
        "To email someone when something happens, such as a booking or an alert, declare notify on the mutation that does it. It reaches the owner, the person who called the action, or the verified accounts a column of the changed rows names, nobody else.",
      ],
      calls: [
        {
          name: "call",
          signature: "miniapp.actions.call(name, input = {})",
          summary: "Invoke one declared Server Action as the current Runtime Actor.",
          signedOut: true,
          tools: ["actions_invoke"],
          args: [
            { name: "name", type: "string", required: true, description: "A Server Action name declared in actions.json, e.g. tasks.list" },
            { name: "input", type: "object", required: false, description: "One value per input binding of the action, keyed by the binding's key. Defaults to {}" },
          ],
          returns: "an array of row objects for a query action, { changes, lastInsertId } for a mutation action, { recorded: true } for a signal action, { callId, queued: true } for a call action",
          errors: [
            { message: "Server action not declared.", when: "actions.json declares no action with that name", source: "kernel" },
            { message: "authentication-required", when: "the action is not declared anonymous and no one is signed in; the published SDK also sends the browser to the login page under the base path", source: "kernel" },
            { message: "rate-limited", when: "more than 30 calls in 10 seconds from one signed-out client address on one Deployment, 120 from one signed-in user, or four statements of the Deployment already running and no slot free within 2 seconds", source: "kernel", preview: null },
            { message: "Arguments must be an object.", when: "input is not an object, e.g. null", source: "kernel" },
            { message: "Expected a string.", when: "name is not a string", source: "kernel" },
            { message: "Unexpected action input: <key>", when: "input has a key no input binding declares", source: "kernel" },
            { message: "This action requires an authenticated actor.", when: "an anonymous action binds the actor id and no one is signed in", source: "kernel" },
            { message: "Action <name> answers only on its HTTP route, <key>.", when: "the action's route does not answer anyone: it declares a signature or callers, or it has no signature on a private Deployment. The preview refuses the first two only, since it has no visibility", source: "kernel" },
            { message: "Missing action input: <key>", when: "a required input is omitted", source: "kernel" },
            { message: "<key> must be a non-empty string.", when: "a string input is not a string, or is empty or only whitespace", source: "kernel" },
            { message: "<key> is too long.", when: "a string input is longer than its maxLength in UTF-16 code units", source: "kernel" },
            { message: "<key> must be a number.", when: "a number input is not a JSON number", source: "kernel" },
            { message: "<key> must be a boolean.", when: "a boolean input is not true or false", source: "kernel" },
            { message: "Query result exceeds 2 MiB or 1000 rows.", when: "a query produces more than 1000 rows or more than 2 MiB of JSON", source: "kernel" },
            { message: "This app reached its limit of calls in the last minute. Try again in a minute.", when: "the action is a call and the app queued 20 calls in the last 60 seconds, or the number the installation set", source: "kernel", preview: null },
            { message: "Action <name> runs only after the call <key> answers.", when: "the action is the then mutation of a call, which only the Kernel runs", source: "kernel" },
            { message: "Action <name> runs only on its schedule.", when: "the action is a mutation with a schedule and no http route, which only the Kernel's timer runs", source: "kernel" },
          ],
          limits: [
            "30 calls per 10 seconds per signed-out client address and Deployment; 120 per 10 seconds per signed-in user",
            "4 action statements at once per Deployment; a call waits up to 2 seconds for a slot",
            "1000 rows and 2 MiB per query result",
            "2 seconds per statement; SQLite's own error text is returned when a statement fails or runs out of time",
            "string inputs default to a maxLength of 10,000 UTF-16 code units",
            "256 MiB per app database",
          ],
          examples: [
            { code: "const rows = await miniapp.actions.call(\"tasks.list\");", comment: "array of row objects" },
            { code: "await miniapp.actions.call(\"tasks.create\", { title });", comment: "{ changes, lastInsertId }" },
            { code: "await miniapp.actions.call(\"lesson.finish\", { lesson });", comment: "a signal action: { recorded: true }" },
          ],
          preview: "Ignores the Deployment's visibility and rate limits, and keeps its database in the browser with a 10 MiB cap. A signal action returns { recorded: true } and records nothing; Signals exist only on a Deployment or on konae dev. A call action returns { callId, queued: true } and sends nothing; only a Kernel sends calls.",
        },
      ],
    },
    {
      name: "page",
      title: "Page address values",
      summary: "Values from the page address. The Kernel fills params when a declared page path answers.",
      switch: false, options: [], permission: "publish", agentRule: "never", requires: ["actions"], uses: ["actions.json"],
      declarations: [],
      calls: [
        { name: "params", signature: "miniapp.page.params", summary: "Read the values captured by the page path, or an empty object on a file page.", signedOut: true, tools: [], args: [], returns: "An object keyed by page path parameter, such as { slug: \"hello\" }", errors: [], limits: [], examples: [{ code: "const { slug } = miniapp.page.params;" }], preview: "Always returns an empty object because the editor preview has no page URL." },
        { name: "url", signature: "miniapp.page.url(path)", summary: "Build an app link that keeps the current hostname or path address.", signedOut: true, tools: [], args: [{ name: "path", type: "string", required: true, description: "An app path starting with one slash, such as /posts/hello." }], returns: "The path with the current /p/<name> prefix when the app uses a path address.", errors: [{ message: "An app page path must start with one slash.", when: "path does not start with one slash", source: "sdk" }], limits: [], examples: [{ code: "link.href = miniapp.page.url(`/posts/${encodeURIComponent(slug)}`);" }], preview: "Returns the app path unchanged." },
      ],
      notes: [],
    },
    {
      name: "files",
      title: "File storage",
      summary: "Small files stored by the Kernel for one Deployment. The module option can require an app session to read every file.",
      switch: true, options: [{ key: "fileAccess", type: "enum", values: ["app-users"], valueLabels: { "app-users": "All signed-in users" }, defaultLabel: "Only the uploader", default: null, label: "Who can read every file", help: "Let every signed-in user read all files in this app." }], permission: "publish", agentRule: "never", requires: ["auth"], uses: ["miniapp.files"],
      declarations: [{ key: "fileAccess", file: "module", summary: 'Set "fileAccess": "app-users" to let every signed-in user of this app read its files, including earlier uploads. The same rule applies to file listings and direct file URLs. IDs stay valid. The uploader keeps deletion rights. This option takes effect as soon as the owner sets it.' }],
      notes: [
        "By default, only the uploader can list or read a private file.",
        "On a public Deployment a signed-out visitor can list and read public files. On a private Deployment any signed-in user can.",
        "files.list returns metadata and the same-origin file path without reading file bytes. files.upload sends the file's bytes in one request and returns its path as url. The Kernel checks access on every file request, including conditional requests.",
        "The uploader alone changes a file's visibility with files.update or deletes it with files.delete. A deleted file stops counting against the Deployment's file quota and its ID answers File not found from then on, through every door.",
        "The operator of the installation sets the per-file limit and the Deployment's file quota. The defaults are 2 MiB per file and 20 MiB per Deployment, and a refusal names the limits in force. Do not promise the defaults in an app's text.",
        "A visitor without a session on a private Deployment is asked to sign in before any file is looked up: 401 authentication-required. On a public Deployment, a file the visitor may not read answers 404 File not found, the same as a missing one. A signed-in user who may not read a file also gets 404.",
      ],
      calls: [
        {
          name: "list",
          signature: "miniapp.files.list()",
          summary: "List metadata and same-origin URLs for files the current actor may read.",
          signedOut: true,
          tools: ["files_list"],
          args: [],
          returns: `an array of ${fileShape}`,
          errors: [],
          limits: [],
          examples: [{ code: "const files = await miniapp.files.list();", comment: "files visible to the current visitor or app user" }],
          preview: "Returns metadata and browser-storage data URLs. The editor preview has no Kernel file route.",
        },
        {
          name: "upload",
          signature: "miniapp.files.upload(file, options)",
          summary: "Store a File or Blob for the signed-in user and return it as files.list would.",
          signedOut: false,
          tools: ["transfer_begin", "files_upload", "transfer_cancel"],
          args: [
            { name: "file", type: "File | Blob", required: true, description: "The bytes to store, with its name and type" },
            { name: "options.visibility", type: "\"private\" | \"public\" | \"app-users\"", required: false, description: "Omit to use the app policy. Without fileAccess, the default is private to the uploader and public allows sharing. When fileAccess is app-users, only that visibility is accepted" },
          ],
          returns: storedShape,
          errors: [
            { message: "authentication-required", when: "no one is signed in", source: "kernel" },
            badVisibility,
            fixedVisibility,
            { message: "Files must be between 1 byte and <limit>.", when: "the file is empty or larger than the installation's per-file limit, which the message names", source: "kernel" },
            { message: "This deployment has reached its <limit> file quota.", when: "the Deployment's files would exceed the installation's file quota together, which the message names", source: "kernel", preview: null },
            ...uploadTransfer,
          ],
          limits: [
            "1 byte up to the installation's per-file limit",
            "the installation's file quota for all files of the Deployment together",
            "2 transfers at a time per user and 32 per Deployment; each expires after 10 minutes",
            "the bytes go in one PUT to <base>/_konae/transfers/<transferId>",
            "the name is cut to 180 characters with / and \\ replaced by -; a type of 128 characters or more, or with a character other than a letter, a digit or one of !#$&^_.+-/, becomes application/octet-stream",
          ],
          examples: [
            { code: "const stored = await miniapp.files.upload(file);", comment: "uses the app's file policy" },
            { code: "const shared = await miniapp.files.upload(file, { visibility: \"public\" });" },
          ],
          preview: "Stores the file in browser storage as a data URL.",
        },
        {
          name: "url",
          signature: "miniapp.files.url(fileId)",
          summary: "The address of a stored file on the app's own origin, for an img src, a link or a fetch.",
          signedOut: true,
          tools: [],
          args: [{ name: "fileId", type: "string", required: true, description: "The id of a file from files.list or files.upload, or one an action returned" }],
          returns: "a Promise of the path \"<base>/_konae/files/<id>\", where <base> is the page's base path: empty, or /p/<id-or-name> on a path address. Reading it answers the file's bytes with its own type when the caller may read it, 404 File not found when the file is missing, deleted or access is denied, and 401 authentication-required to a visitor of a private Deployment",
          errors: [
            noFileId,
            { ...unreadable, when: "reading the path, when the file does not exist, was deleted, or the caller may not read it (404)", status: 404 },
            { message: "authentication-required", when: "reading the path on a private Deployment without a session (401)", source: "kernel", status: 401, preview: null },
          ],
          limits: [
            "the path answers with Cross-Origin-Resource-Policy: same-origin, so another site cannot embed it",
            "the bytes answer with an ETag and Cache-Control: private, no-cache. The browser may keep them and asks before each use; the Kernel answers 304 without the bytes while the caller may still read the file, and 404 once the file is deleted or the caller loses access. A refusal answers with private, no-store",
            "PNG, JPEG, GIF, WebP and AVIF answer inline; every other type downloads as an attachment",
          ],
          examples: [
            { code: "image.src = await miniapp.files.url(photo.file_id);", comment: "\"/_konae/files/<id>\", with the base path in front on a path address" },
            { code: "const text = await (await fetch(await miniapp.files.url(note.id))).text();" },
          ],
          preview: "Returns the file's data URL from browser storage, and refuses at the call with File not found when the preview actor may not read the file.",
        },
        {
          name: "update",
          signature: "miniapp.files.update(fileId, { visibility })",
          summary: "Make a file the signed-in user uploaded public or private. Publishing a draft keeps its ID, so no second copy counts against the quota.",
          signedOut: false,
          tools: ["files_update"],
          args: [
            { name: "fileId", type: "string", required: true, description: "The id of a file the signed-in user uploaded" },
            { name: "visibility", type: "\"private\" | \"public\" | \"app-users\"", required: true, description: "\"public\" lets every signed-in user, and every visitor of a public app, read the file; \"private\" keeps it to the uploader. An app that fixes fileAccess accepts only \"app-users\"" },
          ],
          returns: "{ id, name, type, size, visibility, createdAt, ownerId } with the new visibility. There is no url; the ID and its files.url path stay the same",
          errors: [
            { message: "authentication-required", when: "no one is signed in", source: "kernel" },
            noFileId,
            badVisibility,
            fixedVisibility,
            unreadable,
            notUploader,
          ],
          limits: [],
          examples: [{ code: "await miniapp.files.update(draft.id, { visibility: \"public\" });", comment: "the draft is now published under the same ID" }],
        },
        {
          name: "delete",
          signature: "miniapp.files.delete(fileId)",
          summary: "Delete a file the signed-in user uploaded. Its bytes are gone and its size stops counting against the Deployment's quota.",
          signedOut: false,
          tools: ["files_delete"],
          args: [{ name: "fileId", type: "string", required: true, description: "The id of a file the signed-in user uploaded" }],
          returns: "{ id, deleted: true }",
          errors: [
            { message: "authentication-required", when: "no one is signed in", source: "kernel" },
            noFileId,
            { ...unreadable, when: "the file does not exist, was already deleted, or the caller may not read it" },
            notUploader,
          ],
          limits: ["a row that still names the file ID keeps it; the app removes that row with its own action"],
          examples: [{ code: "await miniapp.files.delete(note.file_id);", comment: "{ id, deleted: true }" }],
        },
      ],
    },
    {
      name: "calls",
      title: "Outgoing calls",
      summary: "Calls from this app to another app or an outside service, made by the Kernel from its own process, never from the browser. There is no browser call: the page invokes the call action with miniapp.actions.call, which answers { callId, queued: true }, and the Kernel sends the request, retries it and runs the then mutation with the answer.",
      switch: true, options: [], permission: "publish", agentRule: "after-owner-confirms", requires: ["actions"], uses: ["actions.json kind=call"],
      calls: [],
      declarations: [
        {
          file: "actions.json",
          key: "kind: call",
          summary: "{ \"kind\": \"call\", \"access\", \"bindings\": [input bindings only], \"method\": \"GET\" | \"POST\", \"url\": \"https://inbox-2.apps.example.org/hooks/events\", \"body\"?: { \"<body key>\": \"<input key>\" | { \"value\": <constant> } }, \"headers\"?: { \"Idempotency-Key\": \"<input key>\" | { \"value\": <constant> } }, \"auth\"?: { \"secret\": \"<name>\", \"header\"?: \"X-Inbox-Signature\" } | { \"key\": \"<name>\" }, \"then\"?: { \"action\": \"<mutation>\", \"inputs\": { \"<input key>\": \"<JSON pointer>\" } } }. A POST sends the body keys as a JSON object and a GET as query parameters after the URL's own; a null or missing input leaves its key out, and a constant, a string of at most 1000 characters, a number, a boolean or null, is sent as actions.json writes it, so the caller cannot change it. On POST, a body key with dotted segments such as line_items.0.price expands into nested JSON, so a Checkout Session can name line items without a free-form object. headers may set only Idempotency-Key, from an input or a constant, for providers that require it. auth.secret signs the request with Konae's route scheme in the header, X-Konae-Signature unless header names another; auth.key sends the secret's value, an API key, as Authorization: Bearer. The secret's value stays in the Kernel; it never reaches the browser, the artifact or an export. When the call ends, delivered or failed, the then mutation runs once with no actor, its inputs read by JSON pointers from { ok, status, error, body, input }: ok is true for a 2xx answer, status the HTTP status or null, error the Kernel's error kind or null, body the answer parsed as JSON or null, and input the call's own inputs. A then mutation runs only after its call. A URL whose host is an app of this installation goes through that app's route code in the Kernel's process, with the same callers check, signature check, guard, Usage and Signal. The owner reads every call with calls_read. The Validation Gate and the Kernel refuse the same declarations with the same messages, except the three marked as the Kernel's alone.",
          errors: [
            { message: "Action <name> is a call, so it runs no SQL and cannot declare a statement, a signal, a guard or an http route.", when: "a call declares a statement, signal, guard or http", source: "kernel" },
            { message: "Action <name> is a <key>, so it cannot declare url, method, body, headers, auth or then. Those keys belong to an action of \"kind\": \"call\".", when: "a query, mutation or signal action declares a call's keys", source: "kernel" },
            { message: "Action <name> is a call, so its bindings may only be inputs.", when: "a call binds the actor, the time or a literal; the Kernel adds no identity or clock to a request that leaves the app", source: "kernel" },
            { message: "Action <name> must call with \"method\": \"GET\" or \"POST\".", when: "method is missing, lowercase or another verb", source: "kernel" },
            { message: "Action <name> has an invalid url. Use an absolute https:// URL without credentials or a fragment, up to 2048 characters.", when: "url is missing, relative, not http or https, carries a user or password, a fragment, a space or a control character, or is longer than 2048 characters", source: "kernel" },
            { message: "Action <name> calls the IP address <key>. Name a host instead.", when: "the host is an IPv4 or IPv6 address, in any notation", source: "kernel" },
            { message: "Action <name> calls <key>, which names this machine or a cloud metadata service.", when: "the host is localhost, metadata, instance-data or a name under .internal", source: "kernel" },
            { message: "Action <name> calls a path under /_konae, /oauth, /.well-known or /mcp, which belong to the Kernel.", when: "the URL's first path segment is reserved, in any letter case", source: "kernel" },
            { message: "Action <name> has an invalid body. Map each body key to one of the call's input keys or to a constant written as an object with \"value\", at most 32.", when: "body is not an object, has more than 32 keys, a key that is not a dotted path of letters, digits, _ and -, or a value that is neither a string nor { \"value\": <string of at most 1000 characters, number, boolean or null> }", source: "kernel" },
            { message: "Action <name> sends body key <key> with a path. Nested body keys belong on POST.", when: "a GET call names a body key that contains a dot", source: "kernel" },
            { message: "Action <name> has body keys <key> and <key>, which overlap. Use one path or the other.", when: "one body key is a dotted prefix of another", source: "kernel" },
            { message: "Action <name> sends body key <key> from <name>, which is not one of its input bindings.", when: "a body value names no input binding of the call", source: "kernel" },
            { message: "Action <name> has an invalid headers. Map Idempotency-Key to an input or a constant, at most 8.", when: "headers is not an object, is empty, has more than 8 keys, or a value that is neither a string nor a string, number or boolean constant", source: "kernel" },
            { message: "Action <name> sets header <key>, which is not allowed. Only Idempotency-Key is allowed.", when: "headers names a header other than Idempotency-Key", source: "kernel" },
            { message: "Action <name> sends header <key> from <name>, which is not one of its input bindings.", when: "a header value names no input binding of the call", source: "kernel" },
            { message: "Action <name> has an invalid auth. Name a secret with \"secret\" to sign the request, or with \"key\" to send the API key it holds.", when: "auth is not an object, names both or neither, or has another key; header goes only with secret", source: "kernel" },
            { message: "Action <name> names an invalid auth secret. Use lowercase letters, digits and \"_\", starting with a letter.", when: "the secret is not a secret name", source: "kernel" },
            { message: "Action <name> has an invalid then. Name a mutation and map its input keys to JSON pointers into the answer.", when: "then is not an object, has no action, has another key, or its inputs are not an object of strings", source: "kernel" },
            { message: "Action <name> reads <key> for then, which is not a JSON pointer into /ok, /status, /error, /body or /input.", when: "a pointer does not start with one of those, has a ~ not followed by 0 or 1, or is longer than 200 characters", source: "kernel" },
            { message: "Action <name> reads <key> for then, but <key> is not one of its input bindings.", when: "a pointer under /input names an input the call does not have", source: "kernel" },
            { message: "Action <name> names <name> as its then, which is not declared.", when: "the then action is not in actions.json", source: "kernel" },
            { message: "Action <name> names <name> as its then, which is not a mutation.", when: "the then action is a query, a signal action or a call", source: "kernel" },
            { message: "Action <name> names <name> as its then, which answers on an HTTP route. A then mutation runs only after its call.", when: "the then mutation declares http", source: "kernel" },
            { message: "Action <name> names <name> as its then, which binds the actor. A then mutation runs with no caller.", when: "the then mutation has an actor binding", source: "kernel" },
            { message: "Action <name> fills <key>, which is not an input of <name>.", when: "then.inputs names a key the mutation has no input binding for", source: "kernel" },
            { message: "Action <name> leaves <key> of <name> unfilled. Fill it from the answer or make the input nullable.", when: "a required input of the then mutation has no pointer", source: "kernel" },
            { message: "Action <name> calls http://<key>, which is not an app of this installation. Use https.", when: "publishing an http URL whose host is not under the installation's host suffix; the Kernel refuses this at publish, and the editor refuses it before Deploy once it has read the installation's hosts", source: "kernel", preview: null },
            { message: "Action <name> calls <key>, the editor's host. A call reaches an app or an outside service, never the editor.", when: "publishing a URL on the installation's own host or its MCP host; the Kernel refuses this at publish, and the editor before Deploy once it has read the installation's hosts", source: "kernel", preview: null },
            { message: "Action <name> calls with the secret <name>, which is not set for this project. Set it with secret_set before publishing.", when: "publishing, and the owner has not set the secret auth names; the Kernel refuses this at publish, and the editor before Deploy from the project's secret names", source: "kernel", preview: null },
            { message: "Action <name> signs its route with the secret <name>, which is set for calls only. Set a route secret with a value of its own.", when: "publishing a route whose signature names a secret set with use call", source: "kernel", preview: null },
          ],
          limits: [
            "20 calls queued per app in any 60 seconds, unless the installation sets KONAE_CALLS_PER_MINUTE",
            "10 seconds per attempt, from connecting to the last byte of the answer",
            "64 KiB per answer; a larger one ends the call as failed with answer-too-large",
            "5 attempts for a network failure, a timeout, 408, 425, 429 or a 5xx, waiting 30 seconds, then 1, 2 and 4 minutes; any other answer is final",
            "no redirect is followed: a 3xx is the answer",
            "the outbox keeps the newest 1000 finished calls per app and the first 1 KiB of each answer",
          ],
        },
        {
          file: "manifest",
          key: "connects",
          summary: "\"connects\": [\"https://api.example.com\"] in the project manifest, or manifest.connects in konae.json. Each origin is added to the page's connect-src, so the page may fetch it directly: another app's public GET route, which answers with Access-Control-Allow-Origin: *, or an outside API that allows the app's origin. Nothing else is loosened. A key or a secret never goes to the browser: a request that needs one is a call action, which the Kernel sends.",
          errors: [
            { message: "connects must be a list of at most 10 origins, such as [\"https://api.example.com\"].", when: "connects is not a list of strings or lists more than 10", source: "kernel" },
            { message: "connects lists <key>, which is not an origin. Write it as https://host or https://host:port, with no path; http only for a host under localhost.", when: "an entry is not exactly an origin: http to a host outside localhost, a path or trailing slash, a wildcard, capitals, or the default port written out", source: "kernel" },
            { message: "connects lists <key> twice.", when: "an origin appears twice", source: "kernel" },
          ],
          limits: [
            "10 origins",
          ],
        },
      ],
      notes: [
        "The Kernel resolves an outside host once per attempt and refuses it when any address it resolves to is loopback, private, link-local (where cloud metadata answers), shared, documentation, benchmarking, multicast, reserved, unspecified, unique-local, or an IPv4 address carried in IPv6. It then connects to the address it checked, so a second DNS answer cannot redirect the request.",
        "http is allowed only to an app of this installation, which the Kernel reaches in its own process. Every other URL must be https.",
        "Each attempt of a signed call signs again with a new nonce, so a retry is never refused as a replay.",
        "An app in maintenance sends no call and runs no then mutation until maintenance ends.",
        "Usage counts each queued call under call, by action. The then mutation counts as an action, or under refused when its guard refuses, and records its Signal with actor null.",
        "The editor preview answers { callId, queued: true } and sends nothing. Run calls on konae dev, or on a Deployment.",
      ],
    },
    {
      name: "http",
      title: "Incoming routes",
      summary: "Routes on the Deployment's own host for programs and other services: a JSON endpoint, a webhook, a file a program fetches. There is no browser call; the app's own pages keep using miniapp.actions.call, and may use a file's route as an img src.",
      switch: true, options: [], permission: "publish", agentRule: "after-owner-confirms", requires: ["actions"], uses: ["actions.json http"],
      calls: [],
      declarations: [
        {
          file: "actions.json",
          key: "http",
          summary: "{ \"method\": \"GET\" | \"POST\", \"path\": \"/api/items\", \"signature\"?: { \"scheme\"?: \"konae\" | \"hmac-body\" | \"timestamped\" | \"svix\", \"header\": \"X-Signature\", \"secret\": \"items_webhook\", ... }, \"callers\"?: [\"signature\" | \"key\" | \"session\"], \"fields\"?: { \"<input key>\": \"$.data.object.id\" } } on an action declared anonymous. GET binds a query and maps the query string onto its input bindings by type; POST binds a mutation and reads a JSON object body. A signature's scheme is konae by default; hmac-body, timestamped and svix verify a provider's own webhook, such as GitHub's, Shopify's, Stripe's or Resend's. fields reads each named input from a JSON path into the body, and with it the route leaves out body keys no input names. callers names who may call the route; without it a signed route takes the signature or an API key, an unsigned route on a private Deployment an API key or a session, and an unsigned route on a public Deployment anyone. An action whose route does not answer anyone answers only on that route, never through miniapp.actions.call. The route answers { result } with the rows or { changes, lastInsertId }, and { error } with a status code. The Validation Gate and the Kernel refuse the same declarations with the same messages.",
          errors: [
            { message: "Action <name> is a signal action, so it takes no route. To record a signal from an HTTP route, declare the signal on a mutation with a POST route.", when: "a signal action declares http", source: "kernel" },
            { message: "Action <name> must bind GET for a query and POST for a mutation.", when: "the method does not match the action's kind, or is neither GET nor POST", source: "kernel" },
            { message: "Action <name> is authenticated, so it cannot declare http. Only anonymous actions answer on an HTTP route.", when: "the action's access is authenticated", source: "kernel" },
            { message: "Action <name> has an invalid http path. Use a leading \"/\" and segments of letters, digits, \".\", \"_\", \"~\" or \"-\", up to 200 characters.", when: "the path is \"/\", ends with \"/\", climbs with \"..\", or carries a query string", source: "kernel" },
            { message: "Action <name> binds the reserved path <key>. Paths under /_konae, /oauth, /.well-known and /mcp belong to the Kernel.", when: "the first segment is reserved, in any letter case", source: "kernel" },
            { message: "Actions <name> and <name> both bind <key>.", when: "two actions declare the same method and path", source: "kernel" },
            { message: "Action <name> has an invalid signature header.", when: "the header is not 1 to 64 letters, digits and -, or is Authorization, Cookie, Host, Content-Type or Content-Length", source: "kernel" },
            { message: "Action <name> names an invalid signature secret. Use lowercase letters, digits and \"_\", starting with a letter.", when: "the secret is not a secret name", source: "kernel" },
            { message: "Action <name> has an invalid http binding.", when: "http is not an object, has another key, or its signature has a key other than header and secret", source: "kernel" },
            { message: "Action <name> names an unknown signature scheme. Use \"konae\", \"hmac-body\", \"timestamped\" or \"svix\".", when: "the signature's scheme is another word, or not text", source: "kernel" },
            { message: "Action <name> has an invalid <key> signature. It takes <names>.", when: "the signature has a key its scheme does not take, such as a header on a svix signature or a window on an hmac-body one", source: "kernel" },
            { message: "Action <name> binds GET, so its signature must use the konae scheme. A provider's scheme signs a POST body.", when: "a query's route declares hmac-body, timestamped or svix", source: "kernel" },
            { message: "Action <name> names an unknown signature provider. Use <names>.", when: "the signature's provider is not text or not a row of the preset table, in that letter case; <names> is the table's rows, \"github\", \"shopify\", \"stripe\" or \"svix\"", source: "kernel" },
            { message: "Action <name> names the signature provider \"<key>\", so its signature takes only \"provider\" and \"secret\". Remove <names>.", when: "a preset has a long-form key beside it, such as header or scheme; the refusal names every such key in sorted order", source: "kernel" },
            { message: "Action <name> has an invalid signature algorithm. Use \"sha256\" or \"sha1\".", when: "an hmac-body signature names no algorithm or another one", source: "kernel" },
            { message: "Action <name> has an invalid signature encoding. Use \"hex\" or \"base64\".", when: "an hmac-body signature names no encoding or another one", source: "kernel" },
            { message: "Action <name> has an invalid signature prefix. Use 1 to 32 letters, digits, \"=\", \"-\", \"_\", \".\" or \":\", such as \"sha256=\".", when: "an hmac-body signature's prefix has another character or is longer", source: "kernel" },
            { message: "Action <name> has an invalid timestamp prefix. Use the field's name and \"=\", such as \"t=\".", when: "a timestamped signature has no prefix, or one that is not a name and =", source: "kernel" },
            { message: "Action <name> has an invalid signature tag. Use the field's name and \"=\", such as \"v1=\", other than the timestamp's.", when: "a timestamped signature has no tag, one that is not a name and =, or the timestamp's", source: "kernel" },
            { message: "Action <name> has an invalid signature window. Use a whole number of seconds from 1 to 3600.", when: "a timestamped signature has no window, or one that is not a whole number from 1 to 3600", source: "kernel" },
            { message: "Action <name> binds GET, so it cannot declare fields. Fields read a POST body.", when: "a query's route declares fields", source: "kernel" },
            { message: "Action <name> has an invalid fields map. Map 1 to 32 input keys to JSON paths, such as \"$.data.object.id\".", when: "fields is not an object, is empty or has more than 32 keys", source: "kernel" },
            { message: "Action <name> maps <key>, which is not one of its input bindings.", when: "fields names a key that no input binding declares; the first such key in sorted order", source: "kernel" },
            { message: "Action <name> maps <key> to an invalid JSON path. Use \"$\" and then \".name\" or \"[index]\" steps, such as \"$.data.object.id\".", when: "a path is not text, lacks the $, is $ alone, has more than 16 steps or 200 characters, or a step that is not .name or [index]", source: "kernel" },
            { message: "Action <name> has an invalid callers list. List one or more of \"signature\", \"key\" and \"session\", each once.", when: "callers is not a list, is empty, repeats a caller or names another one", source: "kernel" },
            { message: "Action <name> lists \"signature\" among its callers but declares no signature.", when: "callers names signature and the binding has no signature", source: "kernel" },
            { message: "Action <name> declares a signature, so its callers must include \"signature\".", when: "the binding has a signature and callers leaves it out", source: "kernel" },
            { message: "Action <name> signs with the secret <name>, which is not set for this project. Set it with secret_set before publishing.", when: "publishing, and the owner has not set the secret; the Kernel refuses this at publish, and the editor before Deploy from the project's secret names, never their values", source: "kernel", preview: null },
            { message: "Actions <names> sign with the secret <name>, which is not set for this project. Set it with secret_set before publishing.", when: "publishing, and several actions sign with one secret the owner has not set", source: "kernel", preview: null },
            { message: "Actions <names> sign with the secrets <names>, which are not set for this project. Set each with secret_set before publishing.", when: "publishing, and more than one secret is unset; one refusal names every action and every secret", source: "kernel", preview: null },
            { message: "Action <name> verifies svix signatures with the secret <key>, which is not a whsec_ signing secret. Set it to the value the provider shows, starting with whsec_.", when: "publishing a svix route whose secret's value is not whsec_ and base64; the Kernel refuses this at publish, and the editor before Deploy from svixKey in secrets_list, never the value", source: "kernel", preview: null },
            { message: "invalid-signature", when: "a signed route gets no signature, a malformed one, one without its declared prefix, or one whose MAC does not match (401)", source: "kernel", status: 401, preview: null },
            { message: "stale-timestamp", when: "a signature's t is more than 300 seconds from the Kernel's clock, or a timestamped one's outside its window; checked before the MAC, so it says nothing about the secret (401)", source: "kernel", status: 401, preview: null },
            { message: "authentication-required", when: "a route that takes an API key or a session, and no signature, gets neither (401)", source: "kernel", status: 401, preview: null },
            { message: "This route does not accept API keys.", when: "the route's callers leave out key and the request carries one (403)", source: "kernel", status: 403, preview: null },
            { message: "An API key works only on the app's HTTP routes and its file read path. The runtime endpoint takes an app session.", when: "a request to the runtime endpoint carries an API key (403)", source: "kernel", status: 403, preview: null },
            { message: "replayed-signature", when: "the same signature arrives a second time, or a svix id again within 72 hours; a retry signs again with a new nonce, and a provider's delivery whose action failed is not remembered (409)", source: "kernel", status: 409, preview: null },
            { message: "invalid-api-key", when: "Authorization carries an lbk_ key that is unknown or revoked (401)", source: "kernel", status: 401, preview: null },
            { message: "This API key may not call <name>.", when: "the key does not name the route's action (403)", source: "kernel", status: 403, preview: null },
            { message: "No route accepts POST on this path.", when: "a POST reaches a path no action binds (405)", source: "kernel", status: 405, preview: null },
            { message: "A route does not answer HEAD. Send GET.", when: "a HEAD reaches a path a query binds; it is refused before any SQL, with Allow: GET (405)", source: "kernel", status: 405, preview: null },
            { message: "The request body exceeds 64 KiB.", when: "a POST body is larger (413)", source: "kernel", status: 413, preview: null },
            { message: "The request body must be a JSON object.", when: "a POST body does not parse as JSON (400)", source: "kernel", status: 400, preview: null },
            { message: "Repeated query parameter: <key>", when: "a GET names one input twice (400)", source: "kernel", status: 400, preview: null },
            { message: "rate-limited", when: "a caller exceeds the action limits of the runtime endpoint, or its address sent 10 unknown or revoked API keys to the Deployment in a minute (429, with Retry-After)", source: "kernel", status: 429, preview: null },
          ],
          limits: [
            "a POST body of 64 KiB",
            "a signature's t within 300 seconds of the Kernel's clock, a nonce of 1 to 64 letters, digits, - and _, and each signature accepted once",
            "a provider's scheme: an hmac-body MAC accepted once in 72 hours, a timestamped t within its window of 1 to 3600 seconds, a svix timestamp within 300 seconds and its id accepted once in 72 hours, and at most 4 signature values in a header",
            "fields: 1 to 32 inputs, each path $ and 1 to 16 .name or [index] steps, up to 200 characters",
            "the runtime endpoint's action rate limits: 30 per 10 seconds per client address without a key or session, 120 per 10 seconds per user or key",
            "50 live API keys per Deployment",
          ],
        },
      ],
      notes: [
        "Only an action declared anonymous may bind a route. A route has three kinds of caller: a service that signs the request (signature), a program that sends Authorization: Bearer with an API key the owner issued (key), and a person signed in to the app, from the app's own origin (session). An actor binding yields the key's ID or the user's ID; a signed request has no actor.",
        "Without callers, a signed route takes the signature or a key, an unsigned route on a private app a key or a session, and an unsigned route on a public app anyone. A person whose session the route does not take must sign like any sender.",
        "An action whose route does not answer anyone answers only on that route: miniapp.actions.call refuses it. The app's own page calls such a route with fetch, which sends the session cookie.",
        "A signed route reads the declared header as t=<unix seconds>,n=<nonce>,v1=<hex HMAC-SHA256>. The MAC is keyed with the secret and covers t, the nonce, the method, the path, the canonical query string and the raw body, joined by newlines. The canonical query string is the pairs sorted by key, then value, written as application/x-www-form-urlencoded.",
        "A provider's scheme. hmac-body: the header carries the prefix, if declared, then the HMAC of the raw body with the declared algorithm, in hex or base64 (GitHub: X-Hub-Signature-256, sha256, hex, prefix sha256=; Shopify: X-Shopify-Hmac-Sha256, sha256, base64). timestamped: the header carries comma-separated fields, the timestamp after prefix and the hex HMAC-SHA256 of <t>.<body> after tag (Stripe: Stripe-Signature, t=, v1=, window 300). svix: svix-id, svix-timestamp and svix-signature, the base64 HMAC-SHA256 of <id>.<t>.<body> keyed with the base64 after whsec_ (Resend, Svix). A provider's delivery is accepted once; one whose action fails is forgotten, so the provider's retry runs. A long form with several wrong keys is refused once, with one sentence per key in the order the parse checks them: keys the scheme does not take, the header, the secret, then the scheme's settings.",
        "A provider's preset. { \"provider\": \"github\" | \"shopify\" | \"stripe\" | \"svix\", \"secret\": \"<name>\" } stands for that provider's long form: github for hmac-body over X-Hub-Signature-256 with sha256, hex and prefix sha256=; shopify for hmac-body over X-Shopify-Hmac-Sha256 with sha256 and base64; stripe for timestamped over Stripe-Signature with t=, v1= and window 300; svix for svix, which Resend also uses. A preset takes no other key, so a route has one spelling. Both doors read the table from kernel-rs/kernel/src/signature-presets.json, and each row verifies a published or provider-form vector. Any other sender uses the long form.",
        "fields maps an input key to a JSON path into the POST body, such as { \"id\": \"$.data.object.id\" }. Each input fields does not name is read from the body's key of that name, and every other key of the body is left out, so a provider's payload needs no adapter. A path that is missing leaves its input out: a required one is refused as missing, a nullable one binds NULL.",
        "The owner sets the secret with the secret_set owner tool before publishing. It never appears in actions.json, the Build Artifact or an export.",
        "GET /_konae/files/<id>, the path miniapp.files.url returns under the page's base path, answers a file the caller may read, with its own type. A person reads by the usual file rules, a visitor reads public files of a public app, and an API key reads the visibilities the owner named on it. A visitor without a session on a private app gets 401 authentication-required before any file is looked up; every other caller who may not read the file gets 404 File not found, the same as for a missing or deleted one.",
        "The editor preview serves no routes. Run them on konae dev, or on a Deployment.",
      ],
    },
    {
      name: "seo",
      title: "Search listing",
      summary: "Canonical addresses and page cards for HTML pages, robots.txt and a sitemap when the owner turns search listing on.",
      switch: true,
      options: [
        { key: "canonical", type: "enum", values: ["domain", "hostname", "path"], valueLabels: { domain: "Custom domain", hostname: "Generated hostname", path: "Path address" }, defaultLabel: "Use the default address", default: null, label: "Canonical address", help: "Choose the address search engines and link previews should use." },
        { key: "image", type: "path", valuesFrom: "app-images", default: null, label: "Card image", help: "Choose an image path from the app's published files." },
      ],
      permission: "publish",
      agentRule: "after-owner-confirms",
      requires: [],
      uses: ["HTML pages with a title"],
      calls: [],
      declarations: [],
      notes: [],
    },
    {
      name: "functions",
      title: "Server functions",
      summary: "Run bundled JavaScript handlers on the Kernel with verified identity and named Server Actions.",
      switch: true, options: [], permission: "publish", agentRule: "after-owner-confirms", requires: [],
      uses: ["functions.json"], calls: [],
      declarations: [{ file: "functions.json", key: "functions", limits: ["32 functions per app", "1 to 1048576 UTF-8 bytes per bundle; 8388608 UTF-8 bytes for all bundles", "GET and POST methods; mounts own their exact path and descendants", "ESM bundles contain their dependencies and export handle; the request resolves no npm package"], errors: [
        { message: "Declared functions require a Server Artifact.", when: "a release declares functions but supplies no serverArtifact", source: "kernel" },
        { message: "Server Artifact requires version 1 and ABI konae-functions/1.", when: "the artifact names a different version or ABI", source: "kernel" },
        { message: "Server Artifact manifest does not match functions.json.", when: "the built declaration differs from the release declaration", source: "kernel" },
        { message: "Idempotency-Key is required for this function.", when: "a POST function with an action allowlist has no idempotency key", source: "kernel" },
        { message: "Idempotency-Key was already used with a different request.", when: "the same actor reuses a function key for another request", source: "kernel" },
      ], summary: "Version 1 maps names to entry, mount, methods, access and allowed actions. Access defaults to authenticated. Bundles export handle(request, context) and use ABI konae-functions/1. context.actions.call(name, input) invokes an allowed action with the actor fixed by the Kernel. Request.signal reports cancellation." }],
      notes: ["Functions start off. Authenticated functions require auth; an action allowlist requires actions. The Kernel checks identity and action access on each invocation. The handler receives no session cookie, owner credential or SQL connection.", "The action allowlist accepts queries and mutations without external effects. It refuses notify, signal, schedule, subscribe, HTTP routes, grants, granted access and targets of outgoing calls.", "For POST functions with allowed actions, send Idempotency-Key with 1 to 128 visible ASCII bytes. Keep the same key when retrying the same request. The Kernel scopes it to the actor and function; a changed request with that key is refused.", "For Hono, export const handle = (request, context) => app.fetch(request, context). A handler without Hono exports handle(request, context) and returns a Response whose body is valid UTF-8. The current ABI refuses binary response bodies and provides no outbound network fetch. context.actions.call returns a Promise; use await and validate request input before calling it.", "The editor preview does not execute server functions. The experimental runtime requires an operator-configured function runner. Try konae dev or a published Deployment only where that runner is configured.", "Server bundles travel in server/, separate from the public dist/.", "An optional shutdown(signal) can release resources. It grants no request operations and may not run after a crash, memory exhaustion or a blocked loop."],
    },
  ],
} as const satisfies SdkContract;

/** Every call as "module.call", in contract order. */
export function contractCalls(contract: SdkContract = sdkContract): string[] {
  return contract.modules.flatMap((module) => module.calls.map((call) => `${module.name}.${call.name}`));
}
