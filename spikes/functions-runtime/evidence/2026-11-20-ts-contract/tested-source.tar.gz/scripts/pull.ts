import { cp, mkdir, mkdtemp, readFile, readdir, rename as fsRename, rm, stat, writeFile } from "node:fs/promises";
import { createHash, randomUUID } from "node:crypto";
import { tmpdir } from "node:os";
import path from "node:path";
import type { McpClient, Transfer } from "../src/mcp/client";
import { checkPackageManifest, packageComponentFiles, type PackageComponentName, type PackageManifest } from "../src/lib/portable-package";
import { dataEntries, SETTINGS_FILE } from "../src/lib/app-folder";
import { downloadToFile } from "./package-files";
import { verifyServerFolder } from "../src/kernel/functions";
import { readTar } from "../src/lib/tar";
import { sourceDigest } from "../src/deployments/source-digest";
import { sourceFilesFrom } from "../src/lib/source-files";
import { settingsDigest, settingsMatchAfterLocalModuleDecision } from "./settings-digest";
import { matchesSourceRevisionScope, sourceRevisionScope } from "./source-revision";

export const PULL_DIRECTORY = ".konae/pull";
const RECORD = "pull.json";

export type Pulled = { manifest: PackageManifest; from: string; at: number; snapshotId?: string; dataOnly?: boolean; sourceBaseline?: { packageId: string; sourceDigest?: string; sourcesRevision?: number; capturedAt: number }; sourcesRevision?: number; sourceDigest?: string; sourcesInstalled?: boolean };

export const NEEDS_EXPORT_DATA = "Downloading live data needs a credential with the export_data permission. Run login with --export-data, or create a token with export_data for this project.";

export async function downloadPackage(client: McpClient, deploymentId: string, directory: string, includeFolder = true) {
  let exported: { manifest: unknown; downloads: Record<string, Transfer>; folder?: Transfer };
  try {
    exported = await client.call("project_export", { projectId: deploymentId });
  } catch (error) {
    if (error instanceof Error && error.message.includes("Unknown tool")) throw Error(NEEDS_EXPORT_DATA);
    throw error;
  }
  try {
    const manifest = checkPackageManifest(exported.manifest);
    const files: { name: string; file: string; size: number }[] = [];
    for (const content of manifest.contents) {
      const transfer = exported.downloads[content.name];
      if (!transfer || transfer.size !== content.size || transfer.sha256 !== content.sha256) throw Error(`The ${content.name} download does not match the export's manifest.`);
      const file = path.join(directory, packageComponentFiles[content.name]);
      await downloadToFile(client, transfer, file);
      files.push({ name: content.name, file, size: content.size });
    }
    let folderFile: string | undefined;
    if (includeFolder && exported.folder) {
      folderFile = path.join(directory, "folder.tar");
      if (!Number.isSafeInteger(exported.folder.size) || exported.folder.size < 0) throw new McpError("Invalid app folder download size.");
      await downloadToFile(client, exported.folder, folderFile);
    }
    return { manifest, files, folderFile };
  } finally {
    for (const transfer of [...Object.values(exported.downloads), ...(exported.folder ? [exported.folder] : [])]) await client.cancel(transfer.transferId).catch(() => {});
  }
}

export async function downloadData(client: McpClient, deploymentId: string, folder: string) {
  const scratch = await mkdtemp(path.join(tmpdir(), "konae-data-"));
  try {
    const { manifest, files } = await downloadPackage(client, deploymentId, scratch, false);
    for (const { name, file } of files) {
      for (const entry of dataEntries(name as PackageComponentName, new Uint8Array(await readFile(file)))) {
        const target = path.resolve(folder, entry.path);
        if (!target.startsWith(path.resolve(folder) + path.sep)) throw Error(`Invalid folder path ${entry.path}.`);
        await mkdir(path.dirname(target), { recursive: true });
        await writeFile(target, entry.contents);
      }
    }
    return manifest;
  } finally {
    await rm(scratch, { recursive: true, force: true });
  }
}

export async function pullLocal(root: string, client: McpClient, from: string, projectId: string, options: { rename?: typeof fsRename; dataOnly?: boolean } = {}): Promise<Pulled> {
  const operations = { rename: options.rename ?? fsRename };
  if (options.dataOnly) return pullDataOnly(root, client, from, projectId, operations);
  const remote = await client.call<{ deployment?: { id: string } | null }>("project_inspect", { projectId });
  if (!remote.deployment) throw Error("This project has no Deployment to pull from. Publish it first.");
  await mkdir(path.join(root, ".konae"), { recursive: true });
  const scratch = await mkdtemp(path.join(root, ".konae/pull-"));
  try {
    const downloaded = await downloadPackage(client, remote.deployment.id, scratch);
    const manifest = downloaded.manifest;
    if (!downloaded.folderFile) throw new Error("The export has no app folder download.");
    const sourceMetadata = await client.call<{ revision: number; project?: { id: string; name: string; slug: string; manifest: Record<string, unknown> } | null }>("project_sources_read", { projectId, metadataOnly: true });
    if (manifest.sourcesRevision != null && sourceMetadata.revision !== manifest.sourcesRevision) throw new Error("Sources changed during pull. Run konae pull again.");
    if (sourceMetadata.project && sourceMetadata.project.id !== projectId) throw new Error("The exported sources do not match this project.");
    const folderEntries = readTar(new Uint8Array(await readFile(downloaded.folderFile)));
    const settingsEntries = folderEntries.filter((entry) => entry.path === SETTINGS_FILE);
    if (settingsEntries.length !== 1) throw new Error("The export must contain one " + SETTINGS_FILE + ".");
    let remoteSettings = JSON.parse(new TextDecoder().decode(settingsEntries[0]!.contents)) as Record<string, unknown>;
    if (sourceMetadata.project) {
      const sourceManifest = { ...sourceMetadata.project.manifest };
      const visibility = sourceManifest.visibility;
      delete sourceManifest.visibility;
      delete sourceManifest.signupPolicy;
      remoteSettings.name = sourceMetadata.project.name;
      remoteSettings.slug = sourceMetadata.project.slug;
      if (visibility === "private" || visibility === "public") remoteSettings.visibility = visibility;
      remoteSettings.manifest = sourceManifest;
    }
    const remoteSettingsBytes = new TextEncoder().encode(JSON.stringify(remoteSettings, null, 2) + "\n");
    const remoteSettingsDigest = settingsDigest(remoteSettings);
    await writeFile(path.join(scratch, SETTINGS_FILE), remoteSettingsBytes);
    const sourceEntries = folderEntries
      .filter((entry) => entry.path.startsWith("app/"))
      .map((entry) => ({ path: entry.path.slice(4), contents: entry.contents }));
    const artifactEntries = folderEntries
      .filter((entry) => entry.path.startsWith("dist/"))
      .map((entry) => ({ path: entry.path.slice(5), contents: entry.contents }));
    const serverEntries = folderEntries.filter((entry) => entry.path.startsWith("server/")).map((entry) => ({ path: entry.path.slice(7), contents: entry.contents }));
    await verifyServerFolder(Object.fromEntries(serverEntries.map((entry) => [entry.path, entry.contents])));
    for (const entry of serverEntries) {
      const target = path.resolve(scratch, "server", entry.path);
      if (!target.startsWith(path.resolve(scratch, "server") + path.sep)) throw Error(`Invalid server folder path ${entry.path}.`);
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, entry.contents);
    }
    const stagedApp = path.join(scratch, "app");
    await mkdir(stagedApp, { recursive: true });
    for (const entry of sourceEntries) {
      const target = path.resolve(stagedApp, entry.path);
      if (!target.startsWith(path.resolve(stagedApp) + path.sep)) throw new Error(`Invalid app folder path ${entry.path}.`);
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, entry.contents);
    }
    const stagedDist = path.join(scratch, "dist");
    await mkdir(stagedDist, { recursive: true });
    for (const entry of artifactEntries) {
      const target = path.resolve(stagedDist, entry.path);
      if (!target.startsWith(path.resolve(stagedDist) + path.sep)) throw new Error(`Invalid dist folder path ${entry.path}.`);
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, entry.contents);
    }
    for (const { name, file } of downloaded.files) {
      for (const entry of dataEntries(name as PackageComponentName, new Uint8Array(await readFile(file)))) {
        const target = path.resolve(scratch, entry.path);
        if (!target.startsWith(path.resolve(scratch) + path.sep)) throw Error(`Invalid folder path ${entry.path}.`);
        await mkdir(path.dirname(target), { recursive: true });
        await writeFile(target, entry.contents);
      }
    }
    const source = sourceFilesFrom(await listFiles(stagedApp));
    const digest = await sourceDigest(source);
    const pulled: Pulled = { manifest, from, at: Date.now(), snapshotId: randomUUID(), sourcesRevision: manifest.sourcesRevision ?? 0, sourceDigest: digest };
    const target = path.join(root, PULL_DIRECTORY);
    const currentApp = path.join(root, "app");
    const markerPath = path.join(root, ".konae/source-revision.json");
    let marker: { sourceDigest?: string; settingsDigest?: string; installation?: string; projectId?: string } | undefined;
    try { marker = JSON.parse(await readFile(markerPath, "utf8")) as typeof marker; } catch { marker = undefined; }
    if (!matchesSourceRevisionScope(marker, from, projectId)) marker = undefined;
    let localAppDigest: string | undefined;
    try { localAppDigest = await sourceDigest(sourceFilesFrom(await listFiles(currentApp))); } catch { localAppDigest = undefined; }
    let localSettingsDigest: string | undefined;
    try { localSettingsDigest = settingsDigest(JSON.parse(await readFile(path.join(root, SETTINGS_FILE), "utf8"))); } catch { localSettingsDigest = undefined; }
    const incomingDigest = pulled.sourceDigest;
    const cleanApp = localAppDigest !== undefined && (localAppDigest === marker?.sourceDigest || localAppDigest === incomingDigest);
    let localSettings: unknown;
    try { localSettings = JSON.parse(await readFile(path.join(root, SETTINGS_FILE), "utf8")); } catch { localSettings = undefined; }
    const localModuleDecision = settingsMatchAfterLocalModuleDecision(localSettings, remoteSettings);
    const cleanSettings = localSettingsDigest !== undefined && (localSettingsDigest === marker?.settingsDigest || localSettingsDigest === remoteSettingsDigest || localModuleDecision);
    const cleanToReplace = cleanApp && cleanSettings;
    pulled.sourcesInstalled = cleanToReplace;
    await writeFile(path.join(scratch, RECORD), JSON.stringify(pulled, null, 2), { mode: 0o600 });
    const nonce = randomUUID();
    const retiredApp = path.join(root, `.app-pull-retired-${nonce}`);
    const retiredSettings = path.join(root, `.settings-pull-retired-${nonce}`);
    const retiredPull = path.join(root, `.konae-pull-retired-${nonce}`);
    const retiredMarker = path.join(root, `.source-revision-retired-${nonce}`);
    const stagedMarker = path.join(root, `.source-revision-staged-${nonce}`);
    const stagedSettings = path.join(root, `.settings-pull-staged-${nonce}`);
    let movedApp = false; let installedApp = false; let movedSettings = false; let installedSettings = false; let movedPull = false; let installedPull = false; let movedMarker = false; let installedMarker = false;
    if (cleanToReplace) {
      await writeFile(stagedMarker, JSON.stringify({ ...sourceRevisionScope(from, projectId), sourcesRevision: pulled.sourcesRevision, sourceDigest: pulled.sourceDigest, settingsDigest: remoteSettingsDigest }, null, 2), { mode: 0o600 });
      await writeFile(stagedSettings, remoteSettingsBytes, { mode: 0o600 });
    }
    try {
      if (cleanToReplace) {
        if (await exists(currentApp)) { await operations.rename(currentApp, retiredApp); movedApp = true; }
        await operations.rename(stagedApp, currentApp); installedApp = true;
        if (await exists(path.join(root, SETTINGS_FILE))) { await operations.rename(path.join(root, SETTINGS_FILE), retiredSettings); movedSettings = true; }
        await operations.rename(stagedSettings, path.join(root, SETTINGS_FILE)); installedSettings = true;
      }
      if (await exists(target)) { await operations.rename(target, retiredPull); movedPull = true; }
      await operations.rename(scratch, target);
      installedPull = true;
      if (cleanToReplace) {
        if (await exists(markerPath)) { await operations.rename(markerPath, retiredMarker); movedMarker = true; }
        await operations.rename(stagedMarker, markerPath);
        installedMarker = true;
      }
    } catch (error) {
      if (installedMarker) await rm(markerPath, { force: true });
      if (movedMarker && await exists(retiredMarker)) await operations.rename(retiredMarker, markerPath);
      if (installedPull && await exists(target)) await rm(target, { recursive: true, force: true });
      if (movedPull && await exists(retiredPull)) await operations.rename(retiredPull, target);
      if (installedSettings) await rm(path.join(root, SETTINGS_FILE), { force: true });
      if (movedSettings && await exists(retiredSettings)) await operations.rename(retiredSettings, path.join(root, SETTINGS_FILE));
      if (installedApp) await rm(currentApp, { recursive: true, force: true });
      if (movedApp && await exists(retiredApp)) await operations.rename(retiredApp, currentApp);
      throw error;
    } finally {
      await rm(stagedMarker, { force: true });
      await rm(stagedSettings, { force: true });
    }
    await rm(retiredPull, { recursive: true, force: true });
    await rm(retiredApp, { recursive: true, force: true });
    await rm(retiredSettings, { force: true });
    await rm(retiredMarker, { force: true });
    return pulled;
  } catch (error) {
    await rm(scratch, { recursive: true, force: true });
    throw error;
  }
}

async function pullDataOnly(root: string, client: McpClient, from: string, projectId: string, operations: { rename: typeof fsRename }): Promise<Pulled> {
  const remote = await client.call<{ deployment?: { id: string } | null }>("project_inspect", { projectId });
  if (!remote.deployment) throw Error("This project has no Deployment to pull from. Publish it first.");
  await mkdir(path.join(root, ".konae"), { recursive: true });
  const scratch = await mkdtemp(path.join(root, ".konae/pull-data-"));
  try {
    const { manifest, files } = await downloadPackage(client, remote.deployment.id, scratch, false);
    await mkdir(path.join(scratch, "data"), { recursive: true });
    for (const { name, file } of files) {
      for (const entry of dataEntries(name as PackageComponentName, new Uint8Array(await readFile(file)))) {
        const target = path.resolve(scratch, entry.path);
        if (!target.startsWith(path.resolve(scratch) + path.sep)) throw Error(`Invalid folder path ${entry.path}.`);
        await mkdir(path.dirname(target), { recursive: true });
        await writeFile(target, entry.contents);
      }
    }
    const previous = await readPulled(root);
    const sourceBaseline = previous?.sourceBaseline ?? (previous ? {
      packageId: previous.manifest.packageId,
      sourcesRevision: previous.sourcesRevision ?? previous.manifest.sourcesRevision ?? undefined,
      sourceDigest: previous.sourceDigest,
      capturedAt: previous.at,
    } : undefined);
    const pulled: Pulled = { manifest, from, at: Date.now(), snapshotId: randomUUID(), dataOnly: true, ...(sourceBaseline ? { sourceBaseline } : {}) };
    const target = path.join(root, PULL_DIRECTORY);
    const merged = path.join(root, `.konae-pull-data-staged-${randomUUID()}`);
    const retired = path.join(root, `.konae-pull-data-retired-${randomUUID()}`);
    const record = path.join(scratch, RECORD);
    await writeFile(record, JSON.stringify(pulled, null, 2), { mode: 0o600 });
    try {
      if (await exists(target)) await cp(target, merged, { recursive: true, errorOnExist: true });
      await rm(path.join(merged, "data"), { recursive: true, force: true });
      await renameDirectory(path.join(scratch, "data"), path.join(merged, "data"));
      for (const file of Object.values(packageComponentFiles)) await rm(path.join(merged, file), { force: true });
      for (const { name, file } of files) await cp(file, path.join(merged, packageComponentFiles[name as PackageComponentName]));
      const stagedFolder = path.join(merged, "folder.tar");
      const oldBaseline = path.join(merged, "folder-baseline.tar");
      if (await exists(stagedFolder)) {
        if (!await exists(oldBaseline)) await fsRename(stagedFolder, oldBaseline);
        else await rm(stagedFolder, { force: true });
      }
      await cp(record, path.join(merged, RECORD));
      if (await exists(target)) await operations.rename(target, retired);
      try { await operations.rename(merged, target); }
      catch (error) {
        if (await exists(retired)) await operations.rename(retired, target);
        throw error;
      }
      await rm(retired, { recursive: true, force: true });
    } finally {
      await rm(merged, { recursive: true, force: true });
    }
    return pulled;
  } finally {
    await rm(scratch, { recursive: true, force: true });
  }
}

async function renameDirectory(from: string, to: string) {
  await mkdir(path.dirname(to), { recursive: true });
  await fsRename(from, to);
}

async function exists(file: string) { try { await stat(file); return true; } catch { return false; } }

async function listFiles(directory: string): Promise<[string, Uint8Array][]> {
  const files: [string, Uint8Array][] = [];
  const pending = [directory];
  while (pending.length) {
    const current = pending.pop()!;
    for (const entry of await readdir(current, { withFileTypes: true })) {
      if (entry.name.startsWith(".") || entry.name === "node_modules") continue;
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) pending.push(full);
      else if (entry.isFile()) files.push([path.relative(directory, full).split(path.sep).join("/"), new Uint8Array(await readFile(full))]);
    }
  }
  return files;
}

export async function readPulled(root: string): Promise<Pulled | undefined> {
  let text: string;
  try { text = await readFile(path.join(root, PULL_DIRECTORY, RECORD), "utf8"); }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined; throw error; }
  const pulled = JSON.parse(text) as Pulled;
  return { ...pulled, manifest: checkPackageManifest(pulled.manifest) };
}

export async function extractVerifiedPulledData(root: string, target: string, pulled: Pulled): Promise<void> {
  const manifest = checkPackageManifest(pulled.manifest);
  await mkdir(target, { recursive: true });
  const pull = path.join(root, PULL_DIRECTORY);
  for (const component of manifest.contents) {
    const raw = path.join(pull, packageComponentFiles[component.name]);
    let bytes: Uint8Array;
    try { bytes = new Uint8Array(await readFile(raw)); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") throw Error(`The raw ${component.name} component for snapshot ${manifest.packageId} is missing. Run konae pull again.`);
      throw error;
    }
    const digest = createHash("sha256").update(bytes).digest("hex");
    if (bytes.byteLength !== component.size || digest !== component.sha256) {
      throw Error(`The raw ${component.name} component no longer matches snapshot ${manifest.packageId}. Run konae pull again.`);
    }
    for (const entry of dataEntries(component.name, bytes)) {
      const destination = path.resolve(target, entry.path);
      if (!destination.startsWith(path.resolve(target) + path.sep)) throw Error(`Invalid snapshot path ${entry.path}.`);
      await mkdir(path.dirname(destination), { recursive: true });
      await writeFile(destination, entry.contents);
    }
  }
}

export function describePulled(pulled: Pulled) {
  const size = (bytes: number) => bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KiB` : `${(bytes / 1024 / 1024).toFixed(1)} MiB`;
  const parts = pulled.manifest.contents.map((content) => `${content.name} ${size(content.size)}`).join(", ");
  return `that ${new URL(pulled.from).host} held at ${new Date(pulled.at).toISOString().replace(/\.\d+Z$/, "Z")} (${parts})`;
}
