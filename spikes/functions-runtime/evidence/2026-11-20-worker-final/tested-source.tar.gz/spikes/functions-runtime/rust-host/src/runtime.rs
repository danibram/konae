use crate::worker::ChildBridge;
use anyhow::{Result, anyhow};
use deno_core::{JsRuntime, OpState, RuntimeOptions, op2, v8};
use deno_error::JsErrorBox;
use konae_functions_executor::protocol::{Capability, WorkerLimits};
pub use konae_functions_executor::{Input, Output};
use std::{
    sync::Arc,
    time::{Duration, Instant},
};

#[op2]
#[serde]
fn op_worker_call(
    state: &mut OpState,
    #[serde] capability: Capability,
    #[string] operation: String,
    #[serde] args: serde_json::Value,
) -> Result<serde_json::Value, JsErrorBox> {
    state
        .borrow::<Arc<ChildBridge>>()
        .call(capability, operation, args)
        .map_err(JsErrorBox::generic)
}
#[op2(fast)]
fn op_worker_failure(state: &mut OpState, #[string] code: String) {
    state.borrow::<Arc<ChildBridge>>().record_error(&code);
}
deno_core::extension!(spike_bridge, ops = [op_worker_call, op_worker_failure]);

pub struct Runtime {
    js: JsRuntime,
    invoke: v8::Global<v8::Function>,
    cancel: v8::Global<v8::Function>,
    shutdown: v8::Global<v8::Function>,
    handler: v8::Global<v8::Value>,
    shutdown_handler: v8::Global<v8::Value>,
    pub has_shutdown: bool,
    bridge: Arc<ChildBridge>,
    response_bytes: usize,
}
impl Runtime {
    pub async fn new(
        function: &str,
        source: String,
        limits: &WorkerLimits,
        bridge: Arc<ChildBridge>,
    ) -> Result<Self> {
        let mut js = JsRuntime::new(RuntimeOptions {
            create_params: Some(v8::CreateParams::default().heap_limits(0, limits.heap_bytes)),
            extensions: vec![
                deno_webidl::deno_webidl::init(),
                deno_web::deno_web::init(
                    Arc::new(deno_web::BlobStore::default()),
                    None,
                    false,
                    Default::default(),
                ),
                deno_net::deno_net::init(None, None),
                deno_fetch::deno_fetch::init(Default::default()),
                spike_bridge::init(),
            ],
            ..Default::default()
        });
        js.op_state()
            .borrow_mut()
            .put(deno_permissions::PermissionsContainer::new(
                Arc::new(deno_permissions::RuntimePermissionDescriptorParser::new(
                    sys_traits::impls::RealSys,
                )),
                deno_permissions::Permissions::none_without_prompt(),
            ));
        js.op_state().borrow_mut().put(bridge.clone());
        let bootstrap = js.execute_script("worker:bootstrap", include_str!("bootstrap.js"))?;
        let (invoke, cancel, shutdown) = {
            deno_core::scope!(scope, js);
            let object = v8::Local::new(scope, bootstrap)
                .to_object(scope)
                .ok_or_else(|| anyhow!("bootstrap_invalid"))?;
            let function = |name: &str| -> Result<v8::Global<v8::Function>> {
                let key = v8::String::new(scope, name).unwrap();
                let value = object
                    .get(scope, key.into())
                    .ok_or_else(|| anyhow!("bootstrap_invalid"))?;
                let callback = v8::Local::<v8::Function>::try_from(value)
                    .map_err(|_| anyhow!("bootstrap_invalid"))?;
                Ok(v8::Global::new(scope, callback))
            };
            (
                function("invoke")?,
                function("cancel")?,
                function("shutdown")?,
            )
        };
        let specifier =
            deno_core::ModuleSpecifier::parse(&format!("file:///function/{function}.mjs"))?;
        let id = js.load_main_es_module_from_code(&specifier, source).await?;
        let evaluation = js.mod_evaluate(id);
        js.run_event_loop(Default::default()).await?;
        evaluation.await?;
        let namespace = js.get_module_namespace(id)?;
        let (handler, shutdown_handler, has_shutdown) = {
            deno_core::scope!(scope, js);
            let object = v8::Local::new(scope, namespace);
            let key = v8::String::new(scope, "handle").unwrap();
            let handler = object
                .get(scope, key.into())
                .ok_or_else(|| anyhow!("handler_missing"))?;
            if !handler.is_function() {
                return Err(anyhow!("handler_missing"));
            }
            let key = v8::String::new(scope, "shutdown").unwrap();
            let shutdown = object
                .get(scope, key.into())
                .ok_or_else(|| anyhow!("shutdown_invalid"))?;
            let has_shutdown = shutdown.is_function();
            (
                v8::Global::new(scope, handler),
                v8::Global::new(scope, shutdown),
                has_shutdown,
            )
        };
        Ok(Self {
            js,
            invoke,
            cancel,
            shutdown,
            handler,
            shutdown_handler,
            has_shutdown,
            bridge,
            response_bytes: limits.response_bytes,
        })
    }
    pub async fn invoke(&mut self, input: Input, capability: Capability) -> Result<Output> {
        self.bridge.begin(capability.clone());
        let args = {
            deno_core::scope!(scope, self.js);
            let input = deno_core::serde_v8::to_v8(scope, input)?;
            let input = v8::Global::new(scope, input);
            let capability = deno_core::serde_v8::to_v8(scope, capability)?;
            let capability = v8::Global::new(scope, capability);
            let limit: v8::Local<v8::Value> =
                v8::Number::new(scope, self.response_bytes as f64).into();
            vec![
                self.handler.clone(),
                input,
                capability,
                v8::Global::new(scope, limit),
            ]
        };
        let invoke = self.invoke.clone();
        let result = self.run(&invoke, args, None).await;
        self.bridge.end();
        let pending = self
            .js
            .runtime_activity_stats_factory()
            .capture(&deno_core::stats::RuntimeActivityStatsFilter::all())
            .dump();
        if !pending.active.is_empty() {
            self.bridge.record_error("pending_work");
            return Err(anyhow!("pending_work"));
        }
        let text = result?;
        serde_json::from_str(&text).map_err(Into::into)
    }
    pub async fn spin(&mut self, capability: Capability) -> Result<Output> {
        self.bridge.begin(capability);
        let result = self
            .js
            .execute_script("worker:loop", "while (true) {}".to_owned());
        self.bridge.end();
        result?;
        Err(anyhow!("loop_returned"))
    }
    pub async fn shutdown(&mut self, grace: Duration) -> Result<()> {
        self.bridge.end();
        self.bridge.clear_error();
        let callback = self.shutdown.clone();
        let args = vec![self.shutdown_handler.clone()];
        self.run(
            &callback,
            args,
            Some(Instant::now() + grace.saturating_sub(Duration::from_millis(5))),
        )
        .await?;
        Ok(())
    }
    async fn run(
        &mut self,
        callback: &v8::Global<v8::Function>,
        args: Vec<v8::Global<v8::Value>>,
        abort_at: Option<Instant>,
    ) -> Result<String> {
        let pending = self.js.call_with_args(callback, &args);
        tokio::pin!(pending);
        let mut aborted = false;
        let value = loop {
            let step = tokio::select! {
                result = self.js.with_event_loop_future(&mut pending, Default::default()) => Some(result),
                _ = tokio::time::sleep(Duration::from_millis(2)) => None,
            };
            if let Some(result) = step {
                break result?;
            }
            if !aborted
                && (self.bridge.cancelled()
                    || abort_at.is_some_and(|deadline| Instant::now() >= deadline))
            {
                aborted = true;
                let abort = self.js.call_with_args(&self.cancel, &[]);
                self.js
                    .with_event_loop_future(abort, Default::default())
                    .await?;
            }
        };
        if let Some(error) = self.bridge.error() {
            return Err(anyhow!(error));
        }
        deno_core::scope!(scope, self.js);
        let value = v8::Local::new(scope, value);
        deno_core::serde_v8::from_v8(scope, value).map_err(Into::into)
    }
}
