use crate::{
    data::Database,
    runtime::{Input, Output, Runtime},
};
use anyhow::{Result, anyhow};
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    path::PathBuf,
    sync::{
        Arc, Mutex,
        atomic::{AtomicU64, AtomicUsize, Ordering},
        mpsc,
    },
    time::{Duration, Instant},
};
use tokio::sync::oneshot;

#[derive(Clone, Hash, Eq, PartialEq)]
struct Key {
    app: String,
    function: String,
    version: String,
}
#[derive(Default)]
struct Counters {
    attempts: AtomicU64,
    created: AtomicU64,
    live: AtomicUsize,
    hits: AtomicU64,
    evictions: AtomicU64,
    timeouts: AtomicU64,
}
struct Activity {
    created: AtomicU64,
    busy: AtomicUsize,
    requests: AtomicU64,
    last: Mutex<Instant>,
}
enum Job {
    Request(Input),
    Spin,
}
struct Command {
    job: Job,
    reply: oneshot::Sender<Result<Output>>,
}
struct Instance {
    sender: Option<mpsc::SyncSender<Command>>,
    thread: Option<std::thread::JoinHandle<()>>,
    activity: Arc<Activity>,
}

impl Drop for Instance {
    fn drop(&mut self) {
        self.sender.take();
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}

pub struct Cache {
    entries: HashMap<Key, Instance>,
    versions: HashMap<(String, String), String>,
    counters: Arc<Counters>,
    capacity: usize,
    ttl: Duration,
    timeout: Duration,
    bundles: PathBuf,
}
impl Cache {
    pub fn new(capacity: usize, ttl: Duration, timeout: Duration, bundles: PathBuf) -> Self {
        Self {
            entries: HashMap::new(),
            versions: HashMap::new(),
            counters: Arc::default(),
            capacity,
            ttl,
            timeout,
            bundles,
        }
    }
    pub fn reap(&mut self) {
        let ttl = self.ttl;
        let before = self.entries.len();
        self.entries.retain(|_, i| {
            i.activity.busy.load(Ordering::SeqCst) != 0
                || i.activity.last.lock().unwrap().elapsed() < ttl
        });
        self.counters
            .evictions
            .fetch_add((before - self.entries.len()) as u64, Ordering::SeqCst);
    }
    pub fn evict_all(&mut self) -> usize {
        let before = self.entries.len();
        self.entries
            .retain(|_, i| i.activity.busy.load(Ordering::SeqCst) != 0);
        let count = before - self.entries.len();
        self.counters
            .evictions
            .fetch_add(count as u64, Ordering::SeqCst);
        count
    }
    pub fn version(&mut self, app: &str, function: &str, version: &str) -> Result<()> {
        if self.entries.iter().any(|(k, i)| {
            k.app == app && k.function == function && i.activity.busy.load(Ordering::SeqCst) > 0
        }) {
            return Err(anyhow!("busy"));
        }
        let before = self.entries.len();
        self.entries
            .retain(|k, _| k.app != app || k.function != function);
        self.counters
            .evictions
            .fetch_add((before - self.entries.len()) as u64, Ordering::SeqCst);
        self.versions
            .insert((app.to_owned(), function.to_owned()), version.to_owned());
        Ok(())
    }
    pub fn dispatch(
        &mut self,
        app: &str,
        function: &str,
        db: Database,
        input: Option<Input>,
    ) -> Result<oneshot::Receiver<Result<Output>>> {
        self.reap();
        let version = self
            .versions
            .get(&(app.to_owned(), function.to_owned()))
            .cloned()
            .unwrap_or_else(|| "v1".into());
        let key = Key {
            app: app.into(),
            function: function.into(),
            version,
        };
        if self.entries.contains_key(&key) {
            self.counters.hits.fetch_add(1, Ordering::SeqCst);
        } else {
            if self.entries.len() >= self.capacity {
                let oldest = self
                    .entries
                    .iter()
                    .filter(|(_, i)| i.activity.busy.load(Ordering::SeqCst) == 0)
                    .min_by_key(|(_, i)| *i.activity.last.lock().unwrap())
                    .map(|(k, _)| k.clone());
                let Some(oldest) = oldest else {
                    return Err(anyhow!("cache_busy"));
                };
                self.entries.remove(&oldest);
                self.counters.evictions.fetch_add(1, Ordering::SeqCst);
            }
            let (sender, receiver) = mpsc::sync_channel::<Command>(64);
            let activity = Arc::new(Activity {
                created: AtomicU64::new(0),
                busy: AtomicUsize::new(0),
                requests: AtomicU64::new(0),
                last: Mutex::new(Instant::now()),
            });
            let work = activity.clone();
            let counters = self.counters.clone();
            let bundles = self.bundles.clone();
            let function = function.to_owned();
            let timeout = self.timeout;
            let thread = std::thread::Builder::new()
                .name(format!("fn-{}-{}", app, function))
                .spawn(move || {
                    let executor = tokio::runtime::Builder::new_current_thread()
                        .enable_all()
                        .build()
                        .unwrap();
                    counters.attempts.fetch_add(1, Ordering::SeqCst);
                    let mut runtime = match executor.block_on(Runtime::new(
                        db.clone(),
                        &function,
                        &bundles,
                        timeout,
                    )) {
                        Ok(runtime) => {
                            counters.created.fetch_add(1, Ordering::SeqCst);
                            work.created.fetch_add(1, Ordering::SeqCst);
                            counters.live.fetch_add(1, Ordering::SeqCst);
                            Some(runtime)
                        }
                        Err(e) => {
                            eprintln!("runtime init: {e:#}");
                            None
                        }
                    };
                    while let Ok(command) = receiver.recv() {
                        if runtime.is_none() {
                            counters.attempts.fetch_add(1, Ordering::SeqCst);
                            match executor.block_on(Runtime::new(
                                db.clone(),
                                &function,
                                &bundles,
                                timeout,
                            )) {
                                Ok(r) => {
                                    counters.created.fetch_add(1, Ordering::SeqCst);
                                    work.created.fetch_add(1, Ordering::SeqCst);
                                    counters.live.fetch_add(1, Ordering::SeqCst);
                                    runtime = Some(r);
                                }
                                Err(e) => {
                                    work.busy.fetch_sub(1, Ordering::SeqCst);
                                    let _ = command.reply.send(Err(e));
                                    continue;
                                }
                            }
                        }
                        let r = runtime.as_mut().unwrap();
                        let (result, timed_out) = match command.job {
                            Job::Request(input) => executor.block_on(r.invoke(input)),
                            Job::Spin => executor.block_on(r.spin()),
                        };
                        if timed_out {
                            counters.timeouts.fetch_add(1, Ordering::SeqCst);
                            runtime.take();
                            counters.live.fetch_sub(1, Ordering::SeqCst);
                        }
                        work.requests.fetch_add(1, Ordering::SeqCst);
                        *work.last.lock().unwrap() = Instant::now();
                        work.busy.fetch_sub(1, Ordering::SeqCst);
                        if let Err(error) = &result {
                            eprintln!("function error: {error:#}");
                        }
                        let _ = command.reply.send(result);
                    }
                    if runtime.take().is_some() {
                        counters.live.fetch_sub(1, Ordering::SeqCst);
                    }
                })?;
            self.entries.insert(
                key.clone(),
                Instance {
                    sender: Some(sender),
                    thread: Some(thread),
                    activity,
                },
            );
        }
        let instance = self.entries.get(&key).unwrap();
        let (reply, receive) = oneshot::channel();
        instance.activity.busy.fetch_add(1, Ordering::SeqCst);
        if let Err(send_error) = instance.sender.as_ref().unwrap().try_send(Command {
            job: input.map(Job::Request).unwrap_or(Job::Spin),
            reply,
        }) {
            instance.activity.busy.fetch_sub(1, Ordering::SeqCst);
            match send_error {
                mpsc::TrySendError::Full(_) => return Err(anyhow!("queue_full")),
                mpsc::TrySendError::Disconnected(_) => {
                    self.entries.remove(&key);
                    return Err(anyhow!("runtime_stopped"));
                }
            }
        }
        Ok(receive)
    }
    pub fn stats(&self, mode: &str, enabled: bool) -> Value {
        let c = &self.counters;
        json!({
            "mode": mode, "functionsEnabled": enabled, "engineInitialized": c.attempts.load(Ordering::SeqCst) > 0, "initializationAttempts": c.attempts.load(Ordering::SeqCst), "queueCapacity": 64,
            "runtimesCreated": c.created.load(Ordering::SeqCst), "runtimesLive": c.live.load(Ordering::SeqCst),
            "cacheHits": c.hits.load(Ordering::SeqCst), "evictions": c.evictions.load(Ordering::SeqCst),
            "timeouts": c.timeouts.load(Ordering::SeqCst), "capacity": self.capacity, "ttlMs": self.ttl.as_millis(),
            "instances": self.entries.iter().map(|(k,i)| json!({"app": k.app, "function": k.function, "version": k.version,
                "runtimesCreated": i.activity.created.load(Ordering::SeqCst), "requests": i.activity.requests.load(Ordering::SeqCst), "busy": i.activity.busy.load(Ordering::SeqCst),
                "idleMs": i.activity.last.lock().unwrap().elapsed().as_millis()})).collect::<Vec<_>>()
        })
    }
}
