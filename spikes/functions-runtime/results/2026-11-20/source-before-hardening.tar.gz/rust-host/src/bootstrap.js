(() => {
const { core } = __bootstrap;
for (const [path, names] of [
  ['ext:deno_web/01_dom_exception.js', ['DOMException']],
  ['ext:deno_web/02_event.js', ['Event', 'EventTarget', 'CustomEvent']],
  ['ext:deno_web/00_url.js', ['URL', 'URLSearchParams']],
  ['ext:deno_web/08_text_encoding.js', ['TextEncoder', 'TextDecoder']],
  ['ext:deno_web/06_streams.js', ['ReadableStream', 'WritableStream', 'TransformStream']],
  ['ext:deno_web/03_abort_signal.js', ['AbortController', 'AbortSignal']],
  ['ext:deno_web/09_file.js', ['Blob', 'File']],
  ['ext:deno_fetch/20_headers.js', ['Headers']],
  ['ext:deno_fetch/21_formdata.js', ['FormData']],
  ['ext:deno_fetch/23_request.js', ['Request']],
  ['ext:deno_fetch/23_response.js', ['Response']],
]) {
  const exports = core.loadExtScript(path);
  for (const name of names) globalThis[name] = exports[name];
}
const readOrder = core.ops.op_order_read;
const updateOrder = core.ops.op_order_update;
globalThis.__invoke = async (input) => {
  const request = new Request(input.url, {
    method: input.method,
    headers: input.headers,
    ...(input.method === 'POST' ? { body: new Uint8Array(input.body) } : {}),
  });
  const response = await globalThis.__handle(request, {
    actor: { userId: input.actor },
    data: { readOrder, updateOrder },
  });
  return JSON.stringify({ status: response.status, headers: [...response.headers], body: await response.text() });
};
delete globalThis.Deno;
delete globalThis.__bootstrap;
})();
