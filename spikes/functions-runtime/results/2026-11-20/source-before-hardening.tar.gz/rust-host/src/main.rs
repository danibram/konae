mod cache;
mod data;
mod runtime;

use axum::{
    Router,
    body::{Body, to_bytes},
    extract::{Request, State},
    http::StatusCode,
    response::{IntoResponse, Response},
};
use serde::Deserialize;
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    path::PathBuf,
    sync::{Arc, Mutex},
    time::Duration,
};

struct AppState {
    mode: String,
    enabled: bool,
    dbs: HashMap<String, data::Database>,
    cache: Mutex<cache::Cache>,
}
fn response(status: u16, body: Value) -> Response {
    (StatusCode::from_u16(status).unwrap(), axum::Json(body)).into_response()
}
fn error(status: u16, message: &str) -> Response {
    response(status, json!({"error": message}))
}
fn cookie(headers: &axum::http::HeaderMap, name: &str) -> Option<String> {
    headers
        .get_all("cookie")
        .iter()
        .filter_map(|v| v.to_str().ok())
        .flat_map(|s| s.split(';'))
        .filter_map(|pair| pair.trim().split_once('='))
        .find(|(key, _)| *key == name)
        .map(|(_, value)| value.to_owned())
}
fn env_number(name: &str, default: u64) -> u64 {
    std::env::var(name)
        .ok()
        .map(|s| s.parse().expect("invalid numeric configuration"))
        .unwrap_or(default)
}

#[tokio::main(flavor = "multi_thread", worker_threads = 2)]
async fn main() -> anyhow::Result<()> {
    let mode = std::env::var("MODE").unwrap_or_else(|_| "native".into());
    anyhow::ensure!(
        ["native", "deno"].contains(&mode.as_str()),
        "MODE must be native or deno"
    );
    let enabled = std::env::var("FUNCTIONS_ENABLED").unwrap_or_else(|_| "1".into()) != "0";
    let port = env_number("PORT", if mode == "native" { 43101 } else { 43102 });
    anyhow::ensure!(port <= u16::MAX as u64, "invalid port");
    let dir = PathBuf::from(
        std::env::var("DATA_DIR").unwrap_or_else(|_| format!("/tmp/konae-functions-{mode}")),
    );
    std::fs::create_dir_all(&dir)?;
    let mut dbs = HashMap::new();
    for app in ["a", "b"] {
        dbs.insert(app.to_owned(), data::open(&dir, app)?);
    }
    let capacity = env_number("CACHE_CAPACITY", 4) as usize;
    anyhow::ensure!(capacity > 0, "CACHE_CAPACITY must be positive");
    let bundles = std::env::var_os("APP_BUNDLE_DIR")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../app/dist"));
    let state = Arc::new(AppState {
        mode: mode.clone(),
        enabled,
        dbs,
        cache: Mutex::new(cache::Cache::new(
            capacity,
            Duration::from_millis(env_number("CACHE_TTL_MS", 60_000)),
            Duration::from_millis(env_number("JS_TIMEOUT_MS", 100)),
            bundles,
        )),
    });
    if mode == "deno" && enabled {
        let reaper = state.clone();
        tokio::spawn(async move {
            let mut tick = tokio::time::interval(Duration::from_millis(100));
            loop {
                tick.tick().await;
                reaper.cache.lock().unwrap().reap();
            }
        });
    }
    let listener =
        tokio::net::TcpListener::bind((std::net::Ipv4Addr::LOCALHOST, port as u16)).await?;
    eprintln!(
        "mode={mode} port={port} pid={} data={}",
        std::process::id(),
        dir.display()
    );
    axum::serve(listener, Router::new().fallback(route).with_state(state)).await?;
    Ok(())
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Version {
    app: String,
    function: String,
    version: String,
}

async fn route(State(state): State<Arc<AppState>>, request: Request) -> Response {
    let (parts, body) = request.into_parts();
    let path = parts.uri.path();
    let method = parts.method.as_str();
    if path == "/health" && method == "GET" {
        return response(200, json!({"ok": true}));
    }
    if path == "/__stats" && method == "GET" {
        return response(
            200,
            state
                .cache
                .lock()
                .unwrap()
                .stats(&state.mode, state.enabled),
        );
    }
    if path == "/__control/evict" && method == "POST" {
        let count = state.cache.lock().unwrap().evict_all();
        return response(200, json!({"evicted": count}));
    }
    if path == "/__control/version" && method == "POST" {
        let Ok(bytes) = to_bytes(body, 16384).await else {
            return error(413, "body_too_large");
        };
        let Ok(v) = serde_json::from_slice::<Version>(&bytes) else {
            return error(400, "invalid_input");
        };
        if !["a", "b"].contains(&v.app.as_str())
            || !["orders", "preferences"].contains(&v.function.as_str())
            || v.version.is_empty()
            || v.version.len() > 64
        {
            return error(400, "invalid_input");
        }
        return match state
            .cache
            .lock()
            .unwrap()
            .version(&v.app, &v.function, &v.version)
        {
            Ok(()) => response(200, json!({"ok": true})),
            Err(_) => error(409, "busy"),
        };
    }
    if path == "/__control/loop" && method == "GET" {
        if state.mode != "deno" || !state.enabled {
            return error(404, "not_found");
        }
        let receive =
            state
                .cache
                .lock()
                .unwrap()
                .dispatch("a", "orders", state.dbs["a"].clone(), None);
        return receive_response(receive).await;
    }
    let segments: Vec<&str> = path.split('/').collect();
    let (app, function, id) = match segments.as_slice() {
        ["", app, "orders", id] if !id.is_empty() && (method == "GET" || method == "POST") => {
            (*app, "orders", Some(*id))
        }
        ["", app, "preferences"] if method == "GET" => (*app, "preferences", None),
        _ => return error(404, "not_found"),
    };
    let Some(db) = state.dbs.get(app) else {
        return error(404, "not_found");
    };
    if state.mode == "deno" && !state.enabled {
        return error(404, "not_found");
    }
    let token = cookie(&parts.headers, "session").unwrap_or_default();
    let actor = match data::authenticate(db, &token) {
        Ok(Some(actor)) => actor,
        Ok(None) => return error(401, "unauthorized"),
        Err(_) => return error(500, "internal_error"),
    };
    let Ok(bytes) = to_bytes(body, 16384).await else {
        return error(413, "body_too_large");
    };
    if state.mode == "deno" {
        let input = runtime::Input {
            url: format!("http://localhost{}", parts.uri),
            method: method.to_owned(),
            headers: parts
                .headers
                .iter()
                .filter_map(|(k, v)| v.to_str().ok().map(|v| (k.to_string(), v.to_owned())))
                .collect(),
            body: bytes.to_vec(),
            actor,
        };
        let receive = state
            .cache
            .lock()
            .unwrap()
            .dispatch(app, function, db.clone(), Some(input));
        return receive_response(receive).await;
    }
    if function == "preferences" {
        let theme = cookie(&parts.headers, "theme").unwrap_or_else(|| "system".into());
        let theme = percent_encoding::percent_decode_str(&theme)
            .decode_utf8()
            .map(|s| s.into_owned())
            .unwrap_or(theme);
        let mut out = response(
            200,
            json!({"theme": theme, "language": parts.headers.get("accept-language").and_then(|v| v.to_str().ok()), "userId": actor}),
        );
        out.headers_mut().insert(
            "set-cookie",
            "seen=1; Path=/; HttpOnly; SameSite=Lax".parse().unwrap(),
        );
        return out;
    }
    let raw = percent_encoding::percent_decode_str(id.unwrap()).decode_utf8_lossy();
    if raw.is_empty() || raw.len() > 9 || !raw.bytes().all(|c| c.is_ascii_digit()) {
        return error(400, "invalid_input");
    }
    let id: i64 = raw.parse().unwrap();
    if id < 1 {
        return error(400, "invalid_input");
    }
    let result = if method == "GET" {
        data::read(db, &actor, id)
    } else {
        let quantity = serde_json::from_slice::<Value>(&bytes).ok().and_then(|v| {
            let obj = v.as_object()?;
            if obj.len() != 1 {
                return None;
            }
            let n = obj.get("quantity")?.as_f64()?;
            if n.fract() != 0.0 || !(1.0..=10.0).contains(&n) {
                return None;
            }
            Some(n as i64)
        });
        let Some(quantity) = quantity else {
            return error(400, "invalid_input");
        };
        data::update(db, &actor, id, quantity)
    };
    match result {
        Ok(Some(order)) => response(200, json!(order)),
        Ok(None) => error(404, "not_found"),
        Err(_) => error(500, "internal_error"),
    }
}

async fn receive_response(
    receive: anyhow::Result<tokio::sync::oneshot::Receiver<anyhow::Result<runtime::Output>>>,
) -> Response {
    let output = match receive {
        Ok(rx) => match rx.await {
            Ok(Ok(out)) => out,
            _ => return error(500, "internal_error"),
        },
        Err(_) => return error(500, "internal_error"),
    };
    let mut builder = Response::builder().status(output.status);
    for (name, value) in output.headers {
        builder = builder.header(name, value);
    }
    builder
        .body(Body::from(output.body))
        .unwrap_or_else(|_| error(500, "internal_error"))
}
