use crate::data::{self, Database, Order};
use anyhow::Result;
use deno_core::{JsRuntime, OpState, RuntimeOptions, op2};
use deno_error::JsErrorBox;
use serde::{Deserialize, Serialize};
use std::{
    path::Path,
    sync::{Arc, Condvar, Mutex},
    time::{Duration, Instant},
};

struct RequestState {
    db: Database,
    actor: Option<String>,
    function: String,
}

#[op2]
#[serde]
fn op_order_read(state: &mut OpState, #[number] id: i64) -> Result<Option<Order>, JsErrorBox> {
    let s = state.borrow::<RequestState>();
    if s.function != "orders" {
        return Err(JsErrorBox::generic("forbidden"));
    }
    let actor = s
        .actor
        .as_deref()
        .ok_or_else(|| JsErrorBox::generic("unauthorized"))?;
    data::read(&s.db, actor, id).map_err(|e| JsErrorBox::generic(e.to_string()))
}
#[op2]
#[serde]
fn op_order_update(
    state: &mut OpState,
    #[number] id: i64,
    #[number] quantity: i64,
) -> Result<Option<Order>, JsErrorBox> {
    let s = state.borrow::<RequestState>();
    if s.function != "orders" {
        return Err(JsErrorBox::generic("forbidden"));
    }
    let actor = s
        .actor
        .as_deref()
        .ok_or_else(|| JsErrorBox::generic("unauthorized"))?;
    data::update(&s.db, actor, id, quantity).map_err(|e| JsErrorBox::generic(e.to_string()))
}

deno_core::extension!(spike_data, ops = [op_order_read, op_order_update]);

#[derive(Serialize)]
pub struct Input {
    pub url: String,
    pub method: String,
    pub headers: Vec<(String, String)>,
    pub body: Vec<u8>,
    pub actor: String,
}
#[derive(Deserialize)]
pub struct Output {
    pub status: u16,
    pub headers: Vec<(String, String)>,
    pub body: String,
}

pub struct Runtime {
    watchdog: Watchdog,
    js: JsRuntime,
    timeout: Duration,
}
impl Runtime {
    pub async fn new(
        db: Database,
        function: &str,
        bundle_dir: &Path,
        timeout: Duration,
    ) -> Result<Self> {
        let mut js = JsRuntime::new(RuntimeOptions {
            extensions: vec![
                deno_webidl::deno_webidl::init(),
                deno_web::deno_web::init(
                    Arc::new(deno_web::BlobStore::default()),
                    None,
                    false,
                    Default::default(),
                ),
                deno_net::deno_net::init(None, None),
                deno_fetch::deno_fetch::init(Default::default()),
                spike_data::init(),
            ],
            ..Default::default()
        });
        js.op_state()
            .borrow_mut()
            .put(deno_permissions::PermissionsContainer::new(
                Arc::new(deno_permissions::RuntimePermissionDescriptorParser::new(
                    sys_traits::impls::RealSys,
                )),
                deno_permissions::Permissions::none_without_prompt(),
            ));
        js.op_state().borrow_mut().put(RequestState {
            db,
            actor: None,
            function: function.to_owned(),
        });
        js.execute_script("spike:bootstrap", include_str!("bootstrap.js"))?;
        let source = std::fs::read_to_string(bundle_dir.join(format!("{function}.js")))?;
        let source = format!("{source}\nglobalThis.__handle = handle;");
        let specifier = deno_core::ModuleSpecifier::parse(&format!("file:///spike/{function}.js"))?;
        let id = js.load_main_es_module_from_code(&specifier, source).await?;
        let evaluation = js.mod_evaluate(id);
        js.run_event_loop(Default::default()).await?;
        evaluation.await?;
        let watchdog = Watchdog::new(js.v8_isolate().thread_safe_handle());
        Ok(Self {
            js,
            timeout,
            watchdog,
        })
    }

    pub async fn invoke(&mut self, input: Input) -> (Result<Output>, bool) {
        self.js
            .op_state()
            .borrow_mut()
            .borrow_mut::<RequestState>()
            .actor = Some(input.actor.clone());
        let script = format!(
            "globalThis.__invoke({})",
            serde_json::to_string(&input).unwrap()
        );
        let result = self.run(script).await;
        self.js
            .op_state()
            .borrow_mut()
            .borrow_mut::<RequestState>()
            .actor = None;
        result
    }

    pub async fn spin(&mut self) -> (Result<Output>, bool) {
        self.run("while (true) {}".to_owned()).await
    }

    async fn run(&mut self, script: String) -> (Result<Output>, bool) {
        self.watchdog.arm(self.timeout);
        let result = async {
            let value = self.js.execute_script("spike:request", script)?;
            let promise = self.js.resolve(value);
            let value = self
                .js
                .with_event_loop_promise(promise, Default::default())
                .await?;
            deno_core::scope!(scope, self.js);
            let local = deno_core::v8::Local::new(scope, value);
            let text: String = deno_core::serde_v8::from_v8(scope, local)?;
            Ok(serde_json::from_str(&text)?)
        }
        .await;
        let fired = self.watchdog.disarm();
        (result, fired)
    }
}

struct WatchState {
    deadline: Option<Instant>,
    fired: bool,
    stop: bool,
}
struct Watchdog {
    state: Arc<(Mutex<WatchState>, Condvar)>,
    thread: Option<std::thread::JoinHandle<()>>,
}
impl Watchdog {
    fn new(handle: deno_core::v8::IsolateHandle) -> Self {
        let state = Arc::new((
            Mutex::new(WatchState {
                deadline: None,
                fired: false,
                stop: false,
            }),
            Condvar::new(),
        ));
        let worker = state.clone();
        let thread = std::thread::spawn(move || {
            let (lock, wake) = &*worker;
            let mut state = lock.lock().unwrap();
            loop {
                if state.stop {
                    break;
                }
                match state.deadline {
                    None => state = wake.wait(state).unwrap(),
                    Some(deadline) => {
                        let remaining = deadline.saturating_duration_since(Instant::now());
                        if remaining.is_zero() {
                            state.fired = true;
                            state.deadline = None;
                            handle.terminate_execution();
                        } else {
                            state = wake.wait_timeout(state, remaining).unwrap().0;
                        }
                    }
                }
            }
        });
        Self {
            state,
            thread: Some(thread),
        }
    }
    fn arm(&self, timeout: Duration) {
        let mut state = self.state.0.lock().unwrap();
        state.fired = false;
        state.deadline = Some(Instant::now() + timeout);
        self.state.1.notify_one();
    }
    fn disarm(&self) -> bool {
        let mut state = self.state.0.lock().unwrap();
        state.deadline = None;
        self.state.1.notify_one();
        state.fired
    }
}
impl Drop for Watchdog {
    fn drop(&mut self) {
        self.state.0.lock().unwrap().stop = true;
        self.state.1.notify_one();
        if let Some(thread) = self.thread.take() {
            let _ = thread.join();
        }
    }
}
