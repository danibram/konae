use anyhow::Result;
use rusqlite::{Connection, OptionalExtension, TransactionBehavior, params};
use serde::{Deserialize, Serialize};
use std::{
    path::Path,
    sync::{Arc, Mutex},
    time::{SystemTime, UNIX_EPOCH},
};

pub type Database = Arc<Mutex<Connection>>;
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Order {
    pub id: i64,
    pub owner_id: String,
    pub quantity: i64,
}

pub fn open(dir: &Path, app: &str) -> Result<Database> {
    let conn = Connection::open(dir.join(format!("{app}.sqlite")))?;
    conn.busy_timeout(std::time::Duration::from_secs(5))?;
    conn.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
      CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, owner_id TEXT NOT NULL, quantity INTEGER NOT NULL CHECK (quantity BETWEEN 1 AND 10));
      CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL, actor_id TEXT NOT NULL, quantity INTEGER NOT NULL);
      INSERT OR IGNORE INTO orders VALUES (1,'alice',2),(2,'bob',4);")?;
    for user in ["alice", "bob"] {
        conn.execute(
            "INSERT OR IGNORE INTO sessions VALUES (?1,?2,4102444800)",
            params![format!("{app}-{user}"), user],
        )?;
    }
    conn.execute(
        "INSERT OR IGNORE INTO sessions VALUES (?1,'alice',1)",
        [format!("{app}-expired")],
    )?;
    Ok(Arc::new(Mutex::new(conn)))
}

pub fn authenticate(db: &Database, token: &str) -> Result<Option<String>> {
    let now = SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs();
    let conn = db.lock().unwrap();
    Ok(conn
        .prepare_cached("SELECT user_id FROM sessions WHERE token=?1 AND expires_at>?2 LIMIT 1")?
        .query_row(params![token, now], |r| r.get(0))
        .optional()?)
}

pub fn read(db: &Database, actor: &str, id: i64) -> Result<Option<Order>> {
    anyhow::ensure!((1..=999_999_999).contains(&id), "invalid_input");
    let conn = db.lock().unwrap();
    Ok(conn
        .prepare_cached(
            "SELECT id,owner_id,quantity FROM orders WHERE id=?1 AND owner_id=?2 LIMIT 1",
        )?
        .query_row(params![id, actor], row_order)
        .optional()?)
}

pub fn update(db: &Database, actor: &str, id: i64, quantity: i64) -> Result<Option<Order>> {
    anyhow::ensure!(
        (1..=999_999_999).contains(&id) && (1..=10).contains(&quantity),
        "invalid_input"
    );
    let mut conn = db.lock().unwrap();
    let tx = conn.transaction_with_behavior(TransactionBehavior::Immediate)?;
    let order = tx.prepare_cached("UPDATE orders SET quantity=?1 WHERE id=?2 AND owner_id=?3 RETURNING id,owner_id,quantity")?
        .query_row(params![quantity, id, actor], row_order).optional()?;
    if order.is_some() {
        tx.prepare_cached("INSERT INTO audit (order_id,actor_id,quantity) VALUES (?1,?2,?3)")?
            .execute(params![id, actor, quantity])?;
    }
    tx.commit()?;
    Ok(order)
}

fn row_order(row: &rusqlite::Row<'_>) -> rusqlite::Result<Order> {
    Ok(Order {
        id: row.get(0)?,
        owner_id: row.get(1)?,
        quantity: row.get(2)?,
    })
}
